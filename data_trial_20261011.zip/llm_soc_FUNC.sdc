#####################################################################
# NPU SDC
# Target frequency : 200 MHz
# Clock period     : 5.000 ns
#
# Top-level design : llm_soc
#####################################################################

#####################################################################
# 1. PRIMARY CLOCK
#####################################################################

create_clock \
    -name clk \
    -period 5.000 \
    -waveform {0.000 2.500} \
    [get_ports clk]


#####################################################################
# 2. CLOCK UNCERTAINTY
#####################################################################

# Pre-CTS / initial STA assumptions
# Setup uncertainty = jitter + margin
set_clock_uncertainty \
    -setup 0.10 \
    [get_clocks clk]

# Hold uncertainty
set_clock_uncertainty \
    -hold 0.05 \
    [get_clocks clk]


#####################################################################
# 3. CLOCK TRANSITION
#####################################################################

# Initial clock slew assumption
set_clock_transition 0.10 [get_clocks clk]


#####################################################################
# 4. INPUT DELAY
#####################################################################

# ---------------------------------------------------------------
# Host interface
# ---------------------------------------------------------------
#
# Assumption:
# External master launches data on clk.
# Maximum arrival = 0.50 ns
# Minimum arrival = 0.10 ns
#
# Adjust these values when the real interface timing is known.
#

set_input_delay \
    -clock clk \
    -max 0.50 \
    [get_ports {
        host_en
        host_we
        host_addr
        host_wdata
    }]

set_input_delay \
    -clock clk \
    -min 0.10 \
    [get_ports {
        host_en
        host_we
        host_addr
        host_wdata
    }]


#####################################################################
# 5. OUTPUT DELAY
#####################################################################

# ---------------------------------------------------------------
# Host / status outputs
# ---------------------------------------------------------------

set_output_delay \
    -clock clk \
    -max 0.50 \
    [get_ports {
        host_rdata
        host_ready
        running
        ready
        error
        overflow_out
        pc_debug
        instr_debug
    }]

set_output_delay \
    -clock clk \
    -min 0.10 \
    [get_ports {
        host_rdata
        host_ready
        running
        ready
        error
        overflow_out
        pc_debug
        instr_debug
    }]


#####################################################################
# 6. ASYNCHRONOUS RESET
#####################################################################

# rst_n is asynchronous reset.
# Do not time reset -> functional data paths.
#
# This should NOT be interpreted as "reset has zero delay".
# It means normal functional timing analysis does not constrain
# asynchronous reset assertion paths.

set_false_path \
    -from [get_ports rst_n]


#####################################################################
# 7. GENERATED CLOCK
#####################################################################
#
# IMPORTANT:
#
# Do NOT blindly enable this section unless the synthesized design
# actually contains a clock divider / PLL / clock-generation block.
#
# Example for a /2 clock divider:
#
# create_generated_clock \
#     -name clk_div2 \
#     -source [get_ports clk] \
#     -divide_by 2 \
#     [get_pins u_clk_div/clk_out]
#
# The generated clock would then have:
#
#       T = 5 ns * 2 = 10 ns
#       F = 100 MHz
#
#####################################################################

# create_generated_clock \
#     -name clk_div2 \
#     -source [get_ports clk] \
#     -divide_by 2 \
#     [get_pins u_clk_div/clk_out]


#####################################################################
# 8. FALSE PATHS
#####################################################################

# ---------------------------------------------------------------
# Asynchronous reset
# ---------------------------------------------------------------

set_false_path \
    -from [get_ports rst_n]


# ---------------------------------------------------------------
# Optional debug paths
# ---------------------------------------------------------------
#
# DO NOT enable automatically.
#
# Debug signals should normally remain timed because they are
# synchronous outputs unless they are intentionally excluded from
# the functional timing requirement.
#
# Example:
#
# set_false_path \
#     -from [get_cells u_debug/*] \
#     -to   [get_ports pc_debug]


#####################################################################
# 9. MULTI-CYCLE PATHS
#####################################################################
#
# IMPORTANT:
#
# No multicycle path should be declared globally just because an
# operation takes several RTL cycles.
#
# A path is multicycle only when the DESTINATION register is
# functionally allowed to capture the result after multiple clock
# edges.
#
# Example: a real 2-cycle path
#
# ---------------------------------------------------------------
#
# set_multicycle_path 2 \
#     -setup \
#     -from [get_cells u_source_reg] \
#     -to   [get_cells u_dest_reg]
#
# set_multicycle_path 1 \
#     -hold \
#     -from [get_cells u_source_reg] \
#     -to   [get_cells u_dest_reg]
#
#####################################################################


#####################################################################
# 10. OPTIONAL DESIGN-RULE CONSTRAINTS
#####################################################################

# Input transition
set_input_transition 0.10 \
    [get_ports {
        host_en
        host_we
        host_addr
        host_wdata
    }]

# Output load
set_load 0.05 \
    [get_ports {
        host_rdata
        host_ready
        running
        ready
        error
        overflow_out
        pc_debug
        instr_debug
    }]
######################################################################