# llm_head_engine.sv

> **Category: GUIDE. Scope: CURRENT (may also have legacy callers).** RTL is authoritative; diagrams use the [shared visual style](../../diagrams/diagram_style.md).
[Documentation](../../README.md) → [Source guide](../full_graph.md) → [RTL index](README.md)

**Source:** [llm_head_engine.sv](<../../../Verilog%20Source%20code/llm_head_engine.sv>).

## At a glance

| Item | Description |
|---|---|
| Responsibility | Stream the 4,096 vocabulary rows with four ordered weight reads per row and one packed scale read per eight rows. Eight reserved result slots hold S39 sums and associated U24 coefficients; tagged results feed the parent's RNE, PRNG and selection pipeline. |

The request counter reserves a result slot before the first weight chunk. Ordered response counters distinguish scale words from weights; the row's scale is copied into its reserved slot before SIMD completion. Four ordered `sum_valid_i` responses produce each S39 result. `result_valid_o/result_ready_i` retains the oldest row under backpressure; slots include work still in memory/SIMD, so at most eight engine rows are outstanding.

`done_o` pulses after result row 4,095 is accepted; parent selection must still drain. Reset clears control/validity. Cancellation suppresses new reads, operand capture and results, and keeps `busy_o` asserted until accepted parameter/SIMD responses drain. The parent gates pending SIMD issue on cancellation before releasing shared ownership. Payload arrays need no reset because a fresh reservation writes them before result validity.

Diagram follow-up required: the diagram below depicts the retired single-row engine interface; the stream now launches once and returns tagged, backpressured rows including their scales.

## Sơ đồ kiến trúc

```mermaid
%%{init: {
  "theme": "base",
  "themeVariables": {
    "background": "#ffffff",
    "primaryTextColor": "#111111",
    "secondaryTextColor": "#111111",
    "tertiaryTextColor": "#111111",
    "lineColor": "#444444",
    "clusterBkg": "#ffffff",
    "clusterBorder": "#aaaaaa",
    "edgeLabelBackground": "#ffffff",
    "fontSize": "17px"
  },
  "flowchart": {
    "curve": "linear",
    "nodeSpacing": 30,
    "rankSpacing": 40,
    "htmlLabels": true,
    "useMaxWidth": true
  }
}}%%
flowchart TB
 S["start_i / vocabulary_i"] --> C["Active flag<br/>Request / response / sum counters"]
 C --> P["Four parameter addresses<br/>vocabulary row x 4 + chunk"]
 P --> M["Parent parameter SRAM"]
 M -->|"parameter_valid_i"| O["operand_capture_o / input_chunk_o"]
 O --> R["Parent operand registers"]
 R --> Q["math_issue_o on following edge"]
 Q --> SIMD["Parent shared u_math"]
 SIMD -->|"sum_valid_i / sum_i"| A["S39 accumulator<br/>done_o after fourth sum"]
 A --> OUT["Parent row scale / sampling"]
classDef control fill:#f8cecc,stroke:#b85450,color:#111111;
classDef interface fill:#fff2cc,stroke:#d6b656,color:#111111;
classDef buffer fill:#f5f5f5,stroke:#666666,color:#111111;
classDef compute fill:#b1ddf0,stroke:#10739e,color:#111111;
classDef output fill:#dae8fc,stroke:#6c8ebf,color:#111111;
classDef platform fill:#e1d5e7,stroke:#9673a6,color:#111111;
class C control;
class S,O,R,Q,SIMD buffer;
class P,A,OUT compute;
class M platform;
```
