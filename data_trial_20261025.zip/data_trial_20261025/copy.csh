#!/bin.csh -fx

cp -rf ../../Lab_20261025_v2/report/lab_synth.netlist.v llm_soc.v
cp -rf ../data_trial_20261011/llm_soc_FUNC.sdc .
cp -rf ../../Lab_20261025_v2/lib_nandgate/icc_lab_nangate.tar .
