"""Extract the exact linear row engine with a two-word prefetch window."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rtl=ROOT/'Verilog Source code'
path=rtl/'llm_soc.sv'
s=path.read_text()
def replace(old,new):
    global s
    assert old in s,old[:100]
    s=s.replace(old,new)
replace('localparam int OP_COUNT = 110;', 'localparam int OP_COUNT = 112;')
replace('    localparam int A_NORM_WAIT_IDX = 109;', '    localparam int A_NORM_WAIT_IDX = 109;\n    localparam int L_ROW_START_IDX = 110;\n    localparam int L_ROW_WAIT_IDX = 111;')
replace("        A_NORM_WAIT = OP_COUNT'(1) << A_NORM_WAIT_IDX,", "        A_NORM_WAIT = OP_COUNT'(1) << A_NORM_WAIT_IDX,\n        L_ROW_START = OP_COUNT'(1) << L_ROW_START_IDX,\n        L_ROW_WAIT = OP_COUNT'(1) << L_ROW_WAIT_IDX,")
replace('    logic head_parameter_req, head_capture, head_math_issue, head_dot_done;', '''    logic linear_parameter_req, linear_ready, linear_busy, linear_done, linear_fault, linear_dot_issue;
    logic [14:0] linear_parameter_address;
    logic [3:0] linear_input_chunk;
    logic signed [38:0] linear_dot_acc;
    wire signed [23:0] linear_operand [0:31];
    logic head_parameter_req, head_capture, head_math_issue, head_dot_done;''')
replace('.rd_addr(head_parameter_req ? head_parameter_address : p_address_q)', '.rd_addr(linear_parameter_req ? linear_parameter_address :\n            head_parameter_req ? head_parameter_address : p_address_q)')
replace('assign p_read = op[O_P_REQ_IDX] || head_parameter_req;', 'assign p_read = op[O_P_REQ_IDX] || head_parameter_req || linear_parameter_req;')
start=s.index('    logic ternary_valid, ternary_reserved;')
end=s.index('    logic root_busy, root_done;',start)
s=s[:start]+'''    generate
    for (genvar input_lane = 0; input_lane < 32; input_lane = input_lane + 1) begin : g_linear_operand
        assign linear_operand[input_lane] = input_cache_q[linear_input_chunk][input_lane * 24 +: 24];
    end
    endgenerate
    llm_linear_engine u_linear_engine(.clk(clk), .rst_n(core_rst_n), .start_i(op[L_ROW_START_IDX]),
        .cancel_i(op_fault_q), .weight_base_i(weight_row_q), .chunks_i(matrix_chunks_q),
        .ready_o(linear_ready), .busy_o(linear_busy), .done_o(linear_done), .fault_o(linear_fault),
        .parameter_req_o(linear_parameter_req), .parameter_address_o(linear_parameter_address),
        .parameter_valid_i(p_valid), .parameter_data_i(p_data), .input_chunk_o(linear_input_chunk),
        .x_i(linear_operand), .dot_issue_o(linear_dot_issue), .accumulator_o(linear_dot_acc));
'''+s[end:]
replace('RET_W_O_P_REQ', 'RET_W_L_ROW_START')
replace('RET_W_L_ROW_START: op <= O_P_REQ;', 'RET_W_L_ROW_START: op <= L_ROW_START;')
replace("                        p_address_q <= parameter_word_q[14:0]; return_p <= RET_P_L_WEIGHT; op <= O_P_REQ;", '                        op <= L_ROW_START;')
replace("                        p_address_q <= weight_row_q; return_p <= RET_P_L_WEIGHT; op <= O_P_REQ;", '                        op <= L_ROW_START;')
start=s.index('                op[L_WEIGHT_IDX] : begin')
end=s.index('                op[L_COEFF_IDX]',start)
s=s[:start]+'''                op[L_ROW_START_IDX] : if (linear_ready) op <= L_ROW_WAIT;
                op[L_ROW_WAIT_IDX] : if (linear_done) begin
                    if (linear_fault) begin op_fault_q <= 1; op <= O_FINISH; end
                    else begin linear_acc_q <= linear_dot_acc; op <= L_COEFF; end
                end
'''+s[end:]
replace('                    end else op <= O_P_REQ;\n                    if (matrix_row_q', '                    end else op <= L_ROW_START;\n                    if (matrix_row_q')
replace("                        p_address_q <= weight_row_q + 15'((matrix_chunks_q + 3) >> 2);\n                        return_p <= RET_P_L_WEIGHT;", '')
replace('if (!v_write_busy && !k_write_busy)', 'if (!v_write_busy && !k_write_busy && !linear_busy)')
# Remove obsolete local ternary payload/check ownership; the row engine owns it.
start=s.index('    logic reserved_weight;')
end=s.index('    // One portable operand cache',start)
s=s[:start]+s[end:]
replace('    logic [1:0] ternary_code_q [0:31];\n', '')
start=s.index('                    op[L_DECODE_IDX] : begin')
end=s.index('                    op[N_SQUARE_IDX]',start)
s=s[:start]+s[end:]
start=s.index('        always_ff @(posedge clk)\n            if (core_rst_n && op[L_INPUT_IDX])')
end=s.index('        always_ff @(posedge clk) begin',start)
s=s[:start]+s[end:]
replace('op[L_INPUT_IDX], op[H_INPUT_IDX] : math_a_q[lane]', 'op[H_INPUT_IDX] : math_a_q[lane]')
path.write_text(s,newline='\n')
name='llm_linear_engine.sv'
(rtl/name).write_text((ROOT/'tools/optimization_staging'/name).read_text(),newline='\n')
qsf=ROOT/'quartus/llm_soc.qsf'
qsf.write_text(qsf.read_text()+'\nset_global_assignment -name SYSTEMVERILOG_FILE "../Verilog Source code/'+name+'"\n',newline='\n')
t=ROOT/'tests/full_rtl/tb_operators.sv'
t.write_text(t.read_text().replace('dut.op!==dut.O_P_REQ) $fatal(1,"Linear partial', 'dut.op!==dut.L_ROW_START) $fatal(1,"Linear partial'),newline='\n')
print('OPTIMIZATION_WAVE5_APPLIED')
