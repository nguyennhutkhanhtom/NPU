"""Install bounded streaming head/QK engines and exact probability/value fusion."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rtl=ROOT/'Verilog Source code'
stage=ROOT/'tools/optimization_staging'
path=rtl/'llm_soc.sv'
s=path.read_text()
def replace(old,new):
    global s
    assert old in s,old[:120]
    s=s.replace(old,new)
replace('localparam int OP_COUNT = 106;', 'localparam int OP_COUNT = 108;')
replace('    localparam int L_DOT_WAIT_IDX = 105;', '    localparam int L_DOT_WAIT_IDX = 105;\n    localparam int H_STREAM_WAIT_IDX = 106;\n    localparam int A_STREAM_WAIT_IDX = 107;')
replace("        L_DOT_WAIT = OP_COUNT'(1) << L_DOT_WAIT_IDX,", "        L_DOT_WAIT = OP_COUNT'(1) << L_DOT_WAIT_IDX,\n        H_STREAM_WAIT = OP_COUNT'(1) << H_STREAM_WAIT_IDX,\n        A_STREAM_WAIT = OP_COUNT'(1) << A_STREAM_WAIT_IDX,")
replace('    logic p_read, p_valid, p_host_valid;', '''    logic p_read, p_valid, p_host_valid;
    logic head_parameter_req, head_capture, head_math_issue, head_dot_done;
    logic [14:0] head_parameter_address;
    logic [1:0] head_input_chunk;
    logic signed [38:0] head_dot_acc;
    logic attention_k_req, attention_capture, attention_math_issue, attention_scores_done;
    logic [11:0] attention_k_address;
    logic signed [31:0] attention_score, attention_max;''')
replace('.rd_addr(p_address_q)', '.rd_addr(head_parameter_req ? head_parameter_address : p_address_q)')
replace('    assign p_read = op[O_P_REQ_IDX];', '    assign p_read = op[O_P_REQ_IDX] || head_parameter_req;')
replace('    logic [767:0] k_data;', '    logic [767:0] k_data;\n    wire [11:0] k_read_address = attention_k_req ? attention_k_address : k_address_q;')
replace('.rd_en(k_read), .rd_addr(k_address_q)', '.rd_en(k_read), .rd_addr(k_read_address)')
replace('    assign k_read = op[O_K_REQ_IDX];', '    assign k_read = op[O_K_REQ_IDX] || attention_k_req;')
replace('    assign math_start = op[O_M_START_IDX];', '''    assign math_start = op[O_M_START_IDX] || head_math_issue || attention_math_issue;
    llm_head_engine u_head_engine(.clk(clk), .rst_n(core_rst_n), .start_i(op[H_SCALE_IDX]),
        .cancel_i(op_fault_q), .vocabulary_i(vocabulary_row_q),
        .parameter_req_o(head_parameter_req), .parameter_address_o(head_parameter_address),
        .parameter_valid_i(p_valid), .operand_capture_o(head_capture), .math_issue_o(head_math_issue),
        .input_chunk_o(head_input_chunk), .sum_valid_i(math_sum_valid), .sum_i(math_sum),
        .done_o(head_dot_done), .accumulator_o(head_dot_acc));
    llm_attention_engine u_attention_engine(.clk(clk), .rst_n(core_rst_n), .start_i(op[A_QUERY_IDX]),
        .cancel_i(op_fault_q), .layer_i(layer_q), .head_i(head_q), .position_i(position_q),
        .kv_req_o(attention_k_req), .kv_address_o(attention_k_address), .kv_valid_i(k_valid),
        .operand_capture_o(attention_capture), .math_issue_o(attention_math_issue),
        .sum_valid_i(math_sum_valid), .sum_i(math_sum), .score_address_i(time_q),
        .score_o(attention_score), .max_score_o(attention_max), .done_o(attention_scores_done));''')
replace('                    op[E_DATA_IDX] : math_a_q[lane]', '                    op[E_DATA_IDX] : math_a_q[lane]')
# Streaming SRAM responses capture payload one edge before the corresponding math start.
needle='''            if (core_rst_n) begin
                unique case (1'b1)
                    op[E_DATA_IDX] : math_a_q[lane]'''
replace(needle, '''            if (core_rst_n) begin
                if (head_capture) math_a_q[lane] <= input_cache_q[{2'b0, head_input_chunk}][lane * 24 +: 24];
                else if (attention_capture) math_a_q[lane] <= query_q[lane * 24 +: 24];
                else unique case (1'b1)
                    op[E_DATA_IDX] : math_a_q[lane]''')
needle='''            if (core_rst_n) begin
                unique case (1'b1)
                    op[E_DATA_IDX] : math_b_q[lane]'''
replace(needle, '''            if (core_rst_n) begin
                if (head_capture) math_b_q[lane] <= 32'($signed(p_data[lane * 8 +: 8]));
                else if (attention_capture) math_b_q[lane] <= 32'($signed(k_data[lane * 24 +: 24]));
                else unique case (1'b1)
                    op[E_DATA_IDX] : math_b_q[lane]''')
replace('                op[A_QUERY_IDX] : begin query_q <= vector_q; begin k_address_q <= {layer_q, time_q, 1\'b0, head_q}; return_k <= RET_K_A_KEY; op <= O_K_REQ; end end',
        '''                op[A_QUERY_IDX] : begin query_q <= vector_q; op <= A_STREAM_WAIT; end
                op[A_STREAM_WAIT_IDX] : if (attention_scores_done) begin
                    max_score_q <= attention_max; time_q <= 0; op <= A_EXP_READ;
                end''')
replace("33'(score_memory[time_q])", "33'(attention_score)")
replace('logic [24:0] probability_memory [0:127], exp_hi_q, exp_lo_q, probability_q;', 'logic [24:0] exp_hi_q, exp_lo_q, probability_q;')
start=s.index('                op[A_EXP_STORE_IDX] : begin')
end=s.index('                op[A_WEIGHT_IDX]',start)
s=s[:start]+'''                op[A_EXP_STORE_IDX] : begin
                    probability_q <= exp_hi_q - 25'((exp_interpolation_q + 37'd2048) >> 12);
                    probability_sum_q <= probability_sum_q + exp_hi_q - 32'((exp_interpolation_q + 37'd2048) >> 12);
                    k_address_q <= {layer_q, time_q, 1'b1, head_q}; return_k <= RET_K_A_WEIGHT; op <= O_K_REQ;
                end
'''+s[end:]
replace("                    else begin time_q <= time_q + 1'b1; begin k_address_q <= {layer_q, 7'(time_q + 1'b1), 1'b1, head_q}; return_k <= RET_K_A_VALUE; op <= O_K_REQ; end end", "                    else begin time_q <= time_q + 1'b1; op <= A_EXP_READ; end")
replace('RET_K_A_VALUE', 'RET_K_A_WEIGHT')
replace('RET_K_A_WEIGHT: op <= A_VALUE;', 'RET_K_A_WEIGHT: op <= A_WEIGHT;')
replace("                    begin p_address_q <= {1'b0, vocabulary_row_q, 2'b00}; return_p <= RET_P_H_WEIGHT; op <= O_P_REQ; end", '                    op <= H_STREAM_WAIT;')
# The exact head scale state starts the local engine; wait for all four reductions and drain.
replace('                op[H_WEIGHT_IDX] :', '''                op[H_STREAM_WAIT_IDX] : if (head_dot_done) begin linear_acc_q <= head_dot_acc; op <= H_COEFF; end
                op[H_WEIGHT_IDX] :''')
path.write_text(s,newline='\n')
for name in ['llm_head_engine.sv','llm_attention_engine.sv']:
    (rtl/name).write_text((stage/name).read_text(),newline='\n')
qsf=ROOT/'quartus/llm_soc.qsf'
qsf.write_text(qsf.read_text()+''.join('\nset_global_assignment -name SYSTEMVERILOG_FILE "../Verilog Source code/'+n+'"\n' for n in ['llm_head_engine.sv','llm_attention_engine.sv']),newline='\n')
t=ROOT/'tests/full_rtl/tb_graph.sv'
t.write_text(t.read_text().replace('dut.k_address_q[9:3]', 'dut.k_read_address[9:3]').replace('dut.k_address_q,dut.position_q', 'dut.k_read_address,dut.position_q'),newline='\n')
print('OPTIMIZATION_WAVE3_APPLIED')
