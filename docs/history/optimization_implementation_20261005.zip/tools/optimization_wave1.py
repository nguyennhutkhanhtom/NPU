"""Apply the approved control, cache and store checkpoint exactly once."""
from pathlib import Path
import math
import re

ROOT = Path(__file__).resolve().parents[1]
path = ROOT/'Verilog Source code/llm_soc.sv'
s = path.read_text(encoding='utf-8-sig')

def replace(old, new):
    global s
    assert old in s, old[:120]
    s = s.replace(old, new)

replace('parameter bit ENABLE_DEBUG_INDEX = 1', 'parameter bit ENABLE_DEBUG_INDEX = 0')
replace('(host_state == H_READ || host_state == H_WAIT)', 'host_state == H_READ')
replace('localparam int OP_COUNT = 103;', 'localparam int OP_COUNT = 105;')
replace('    typedef enum logic [OP_COUNT - 1:0]',
        '    localparam int L_PRELOAD_IDX = 103;\n    localparam int H_PRELOAD_IDX = 104;\n    typedef enum logic [OP_COUNT - 1:0]')
replace("        SC_ROUTE = OP_COUNT'(1) << SC_ROUTE_IDX",
        "        L_PRELOAD = OP_COUNT'(1) << L_PRELOAD_IDX,\n        H_PRELOAD = OP_COUNT'(1) << H_PRELOAD_IDX,\n        SC_ROUTE = OP_COUNT'(1) << SC_ROUTE_IDX")
replace('    logic [511:0] table_q;', '''    // One portable operand cache is shared by mutually exclusive linear/head operations.
    logic [767:0] input_cache_q [0:11];
    logic input_cache_valid_q, input_cache_gate_q;
    logic [2:0] input_cache_source_q;
    logic [3:0] input_cache_chunks_q;
    logic [3:0] preload_chunk_q;
    logic rope_table_valid_q;
    logic [6:0] rope_table_position_q;
    logic [255:0] head_scale_word_q;
    logic [511:0] table_q;''')
replace('    for (debug_bit = 0; debug_bit < 7;', '    if (ENABLE_DEBUG_INDEX) begin : g_debug_enabled\n    for (debug_bit = 0; debug_bit < 7;')
replace('    typedef enum logic [2:0] {H_IDLE', '''    typedef enum logic [2:0] {H_IDLE''')
# Close the optional debug generate before host declarations.
debug_end = s.index('    endgenerate', s.index('if (ENABLE_DEBUG_INDEX)'))
s = s[:debug_end] + "    end else begin : g_debug_disabled\n        assign op_debug_index = 7'd0;\n    end\n" + s[debug_end:]
replace('                    op[L_INPUT_IDX], op[N_SQUARE_IDX], op[N_INPUT_IDX], op[R_INPUT_IDX],\n                    op[S_MUL_IDX], op[H_INPUT_IDX] : math_a_q[lane] <= vector_q[lane * 24 +: 24];',
        '''                    op[L_INPUT_IDX], op[H_INPUT_IDX] : math_a_q[lane] <= input_cache_q[chunk_q][lane * 24 +: 24];
                    op[N_SQUARE_IDX], op[N_INPUT_IDX], op[R_INPUT_IDX],
                    op[S_MUL_IDX] : math_a_q[lane] <= vector_q[lane * 24 +: 24];''')
replace('                            begin p_address_q <= 15\'(ROPE_BASE + (int\'(position_q) << 1)); return_p <= R_TABLE0; op <= O_P_REQ; end',
        '''                            if (graph == G_RK && rope_table_valid_q && rope_table_position_q == position_q) begin
                                v_address_q <= 7'd36; return_v <= R_INPUT; op <= O_V_REQ;
                            end else begin p_address_q <= 15'(ROPE_BASE + (int'(position_q) << 1)); return_p <= R_TABLE0; op <= O_P_REQ; end''')
replace("                            begin p_address_q <= 15'(EMB_SCALE_BASE); return_p <= H_SCALE; op <= O_P_REQ; end",
        "                            preload_chunk_q <= 0; v_address_q <= 7'd12; return_v <= H_PRELOAD; op <= O_V_REQ;")
replace('                    begin p_address_q <= parameter_word_q[14:0]; return_p <= L_WEIGHT; op <= O_P_REQ; end',
        '''                    if (input_cache_valid_q && input_cache_source_q == source_q &&
                        input_cache_chunks_q == parameter_word_q[23:20] &&
                        (((graph == G_K || graph == G_V) && !input_cache_gate_q) ||
                         (graph == G_UP && input_cache_gate_q))) begin
                        p_address_q <= parameter_word_q[14:0]; return_p <= L_WEIGHT; op <= O_P_REQ;
                    end else begin
                        preload_chunk_q <= 0;
                        v_address_q <= 7'((int'(source_q) << 3) + (int'(source_q) << 2));
                        return_v <= L_PRELOAD; op <= O_V_REQ;
                    end''')
replace('                op[L_WEIGHT_IDX] : begin weights_q <= parameter_word_q; begin v_address_q <= 7\'(((int\'($unsigned(3\'(source_q))) << 3) + (int\'($unsigned(3\'(source_q))) << 2)) + int\'($unsigned(4\'(chunk_q)))); return_v <= L_INPUT; op <= O_V_REQ; end end',
        '''                op[L_PRELOAD_IDX] : begin
                    if (preload_chunk_q + 1'b1 >= matrix_chunks_q) begin
                        p_address_q <= weight_row_q; return_p <= L_WEIGHT; op <= O_P_REQ;
                    end else begin
                        preload_chunk_q <= preload_chunk_q + 1'b1;
                        v_address_q <= 7'((int'(source_q) << 3) + (int'(source_q) << 2) + preload_chunk_q + 1);
                        return_v <= L_PRELOAD; op <= O_V_REQ;
                    end
                end
                op[L_WEIGHT_IDX] : begin weights_q <= parameter_word_q; op <= L_INPUT; end''')
replace("                        else begin v_address_q <= 7'(((int'($unsigned(3'(source_q))) << 3) + (int'($unsigned(3'(source_q))) << 2)) + int'($unsigned(4'(chunk_q + 1'b1)))); return_v <= L_INPUT; op <= O_V_REQ; end",
        '                        else op <= L_INPUT;')
start = s.index('                op[L_STORE_IDX] : begin')
end = s.index('                op[N_SQUARE_IDX]', start)
s = s[:start] + '''                op[L_STORE_IDX] : begin
                    // L_STORE captures the final lane; O_WRITE consumes the completed row on the next edge.
                    if (matrix_row_q[4:0] == 31 || matrix_row_q + 1'b1 >= matrix_rows_q) begin
                        write_vector_addr_q <= 7'((int'(destination_q) << 3) + (int'(destination_q) << 2) + int'(matrix_row_q[8:5]));
                        write_vector_mask_q <= 32'hffffffff;
                        op <= O_WRITE;
                        return_w <= matrix_row_q + 1'b1 >= matrix_rows_q ? O_FINISH : O_P_REQ;
                    end else op <= O_P_REQ;
                    if (matrix_row_q + 1'b1 < matrix_rows_q) begin
                        matrix_row_q <= matrix_row_q + 1'b1; chunk_q <= 0; linear_acc_q <= 0;
                        weight_row_q <= weight_row_q + 15'((matrix_chunks_q + 3) >> 2);
                        p_address_q <= weight_row_q + 15'((matrix_chunks_q + 3) >> 2);
                        return_p <= L_WEIGHT;
                    end
                end
''' + s[end:]
replace('                op[H_SCALE_IDX] : begin\n                    coefficient_q <= parameter_word_q[(int\'(vocabulary_row_q[2:0]) << 5) +: 24];',
        '''                op[H_PRELOAD_IDX] : begin
                    if (preload_chunk_q == 3) begin
                        p_address_q <= 15'(EMB_SCALE_BASE); return_p <= H_SCALE; op <= O_P_REQ;
                    end else begin
                        preload_chunk_q <= preload_chunk_q + 1'b1;
                        v_address_q <= 7'(12 + preload_chunk_q + 1); return_v <= H_PRELOAD; op <= O_V_REQ;
                    end
                end
                op[H_SCALE_IDX] : begin
                    if (vocabulary_row_q[2:0] == 0) head_scale_word_q <= parameter_word_q;
                    coefficient_q <= vocabulary_row_q[2:0] == 0 ? parameter_word_q[23:0] :
                        head_scale_word_q[(int'(vocabulary_row_q[2:0]) << 5) +: 24];''')
replace('                op[H_WEIGHT_IDX] : begin weights_q <= parameter_word_q; begin v_address_q <= 7\'(((int\'($unsigned(3\'(1))) << 3) + (int\'($unsigned(3\'(1))) << 2)) + int\'($unsigned(4\'(chunk_q)))); return_v <= H_INPUT; op <= O_V_REQ; end end',
        '                op[H_WEIGHT_IDX] : begin weights_q <= parameter_word_q; op <= H_INPUT; end')
replace("                        begin p_address_q <= 15'(EMB_SCALE_BASE + ((vocabulary_row_q + 1) >> 3)); return_p <= H_SCALE; op <= O_P_REQ; end",
        '''                        if (vocabulary_row_q[2:0] == 7) begin
                            p_address_q <= 15'(EMB_SCALE_BASE + ((vocabulary_row_q + 1) >> 3)); return_p <= H_SCALE; op <= O_P_REQ;
                        end else op <= H_SCALE;''')
# Register ownership is explicit and independent of the operator FSM.
insert = '''    generate
    for (genvar cache_row = 0; cache_row < 12; cache_row = cache_row + 1) begin : g_input_cache
        always_ff @(posedge clk)
            if (core_rst_n && (op[L_PRELOAD_IDX] || op[H_PRELOAD_IDX]) && preload_chunk_q == 4'(cache_row))
                input_cache_q[cache_row] <= vector_q;
    end
    endgenerate
    wire [6:0] cache_source_base = 7'((int'(input_cache_source_q) << 3) + (int'(input_cache_source_q) << 2));
    always_ff @(posedge clk or negedge core_rst_n) begin
        if (!core_rst_n) begin input_cache_valid_q <= 0; rope_table_valid_q <= 0; end
        else begin
            if (launch || op_fault_q || (op[O_IDLE_IDX] && graph == G_HEAD) ||
                (op[O_WRITE_IDX] && write_vector_addr_q >= cache_source_base && write_vector_addr_q < cache_source_base + 7'd12))
                input_cache_valid_q <= 0;
            else if (op[L_PRELOAD_IDX] && preload_chunk_q + 1'b1 >= matrix_chunks_q)
                input_cache_valid_q <= 1;
            if (launch || op_fault_q || op[N_GAIN0_IDX] || op[N_GAIN1_IDX]) rope_table_valid_q <= 0;
            else if (op[R_TABLE1_IDX]) rope_table_valid_q <= graph == G_RQ;
        end
    end
    always_ff @(posedge clk) begin
        if (core_rst_n && op[L_PRELOAD_IDX] && preload_chunk_q + 1'b1 >= matrix_chunks_q) begin
            input_cache_source_q <= source_q; input_cache_chunks_q <= matrix_chunks_q;
            input_cache_gate_q <= graph == G_GATE;
        end
        if (core_rst_n && op[R_TABLE1_IDX]) rope_table_position_q <= position_q;
    end

'''
replace('    // Payloads are assigned before their operation consumes them.', insert+'    // Payloads are assigned before their operation consumes them.')
# Compact continuations use explicit constant decoders; never a variable one-hot shift.
types = []
for kind in ['p','v','k','m','w','scalar']:
    names = sorted(set(re.findall(r'\breturn_'+kind+r'\s*<=\s*([A-Z][A-Z0-9_]*)', s)))
    if kind == 'w': names += [n for n in ['O_FINISH','O_P_REQ'] if n not in names]
    if kind == 'scalar': names += ['O_IDLE']
    bits = max(1, math.ceil(math.log2(len(names))))
    prefix = 'RET_'+kind.upper()+'_'
    types.append('    typedef enum logic ['+str(bits-1)+':0] { '+', '.join(prefix+n for n in names)+' } '+kind+'_return_t;\n    '+kind+'_return_t return_'+kind+';')
    for n in names:
        s = re.sub(r'(\breturn_'+kind+r'\s*<=\s*)'+n+r'\b', r'\g<1>'+prefix+n, s)
    if kind == 'w':
        s = s.replace('? O_FINISH : O_P_REQ;', '? '+prefix+'O_FINISH : '+prefix+'O_P_REQ;')
    decoder = 'begin\n                        case (return_'+kind+')\n'+''.join('                            '+prefix+n+': op <= '+n+';\n' for n in names)+'                            default: begin op_fault_q <= 1; op <= O_FINISH; end\n                        endcase\n                    end'
    s = s.replace('op <= return_'+kind+';', decoder)
replace('    op_t op, return_p, return_v, return_k, return_m, return_w, return_scalar;',
        '    op_t op;\n'+'\n'.join(types))
path.write_text(s, encoding='utf-8', newline='\n')
t = ROOT/'tests/full_rtl/tb_operators.sv'
text = t.read_text().replace('$deposit(dut.return_scalar,dut.O_IDLE)', '$deposit(dut.return_scalar,dut.RET_SCALAR_O_IDLE)')
t.write_text(text, newline='\n')
print('OPTIMIZATION_WAVE1_APPLIED')
