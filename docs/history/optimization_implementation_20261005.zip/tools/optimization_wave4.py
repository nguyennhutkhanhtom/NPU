"""Install exact four-way normalization and sigmoid batches, with rounded-divide isolation."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rtl=ROOT/'Verilog Source code'
path=rtl/'llm_soc.sv'
s=path.read_text()
def replace(old,new):
    global s
    assert old in s,old[:100]
    s=s.replace(old,new)
replace('parameter bit ENABLE_DEBUG_INDEX = 0)', 'parameter bit ENABLE_DEBUG_INDEX = 0,\n    parameter int ATTN_DIV_LANES = 4,\n    parameter int SIGMOID_LANES = 4)')
replace('localparam int OP_COUNT = 108;', 'localparam int OP_COUNT = 110;')
replace('    localparam int A_STREAM_WAIT_IDX = 107;', '    localparam int A_STREAM_WAIT_IDX = 107;\n    localparam int N_DIV_ROUND_IDX = 108;\n    localparam int A_NORM_WAIT_IDX = 109;')
replace("        A_STREAM_WAIT = OP_COUNT'(1) << A_STREAM_WAIT_IDX,", "        A_STREAM_WAIT = OP_COUNT'(1) << A_STREAM_WAIT_IDX,\n        N_DIV_ROUND = OP_COUNT'(1) << N_DIV_ROUND_IDX,\n        A_NORM_WAIT = OP_COUNT'(1) << A_NORM_WAIT_IDX,")
replace('    logic divide_round_up;', '''    logic divide_round_up;
    logic [24:0] norm_quotient_q;
    logic norm_round_q;
    logic attention_norm_ready, attention_norm_done, attention_div_start;
    logic [767:0] attention_normalized;
    llm_attention_normalize #(.DIV_LANES(ATTN_DIV_LANES)) u_attention_normalize(
        .clk(clk), .rst_n(core_rst_n), .start_i(op[A_LANE_IDX]), .cancel_i(op_fault_q),
        .accumulator_i(attention_acc_q), .denominator_i(probability_sum_q),
        .ready_o(attention_norm_ready), .batch_start_o(attention_div_start),
        .done_o(attention_norm_done), .vector_o(attention_normalized));''')
replace('    logic sig_busy, sig_done;\n    logic signed [15:0] sig_x_q;', '    localparam int SIGMOID_SHIFT = $clog2(SIGMOID_LANES);\n    logic [SIGMOID_LANES - 1:0] sig_busy, sig_done;\n    logic signed [15:0] sig_x_q [0:SIGMOID_LANES - 1];')
replace('    logic signed [15:0] sigmoid_pick_q [0:3];\n    logic [15:0] sig_y;', '    logic [15:0] sig_y [0:SIGMOID_LANES - 1];')
replace('''    sigmoid u_sig(.clk(clk), .rst_n(core_rst_n), .start(op[S_SIG_IDX]),
        .x_raw(sig_x_q), .frac_bits(5'd12), .busy(sig_busy), .done(sig_done), .y_raw(sig_y));''', '''    generate
    for (genvar sig_lane = 0; sig_lane < SIGMOID_LANES; sig_lane = sig_lane + 1) begin : g_sigmoid
        sigmoid u_sig(.clk(clk), .rst_n(core_rst_n), .start(op[S_SIG_IDX]),
            .x_raw(sig_x_q[sig_lane]), .frac_bits(5'd12), .busy(sig_busy[sig_lane]),
            .done(sig_done[sig_lane]), .y_raw(sig_y[sig_lane]));
        always_ff @(posedge clk)
            if (core_rst_n && op[SG_GROUP_IDX]) sig_x_q[sig_lane] <= sigmoid_inputs_q[int'(lane_q) + sig_lane];
    end
    endgenerate''')
replace("                if (op[N_DIV_IDX] || op[A_DIV_IDX]) divider_starts <= divider_starts + 1'b1;", "                if (attention_div_start) divider_starts <= divider_starts + 64'(ATTN_DIV_LANES);\n                else if (op[N_DIV_IDX]) divider_starts <= divider_starts + 1'b1;")
replace("                if (op[S_SIG_IDX]) sigmoid_starts <= sigmoid_starts + 1'b1;", "                if (op[S_SIG_IDX]) sigmoid_starts <= sigmoid_starts + 64'(SIGMOID_LANES);")
replace("            if (core_rst_n && op[S_SIG_WAIT_IDX] && sig_done && lane_q == 5'(lane))\n                sigmoid_values_q[lane] <= sig_y;", "            if (core_rst_n && op[S_SIG_WAIT_IDX] && &sig_done &&\n                (int'(lane_q) >> SIGMOID_SHIFT) == lane / SIGMOID_LANES)\n                sigmoid_values_q[lane] <= sig_y[lane % SIGMOID_LANES];")
replace('''                if (op[E_CLAMP_IDX] || op[N_CLAMP_IDX] || op[R_CLAMP_IDX] ||''', '''                if (op[A_NORM_WAIT_IDX] && attention_norm_done)
                    write_vector_q[lane * 24 +: 24] <= attention_normalized[lane * 24 +: 24];
                else if (op[E_CLAMP_IDX] || op[N_CLAMP_IDX] || op[R_CLAMP_IDX] ||''')
replace("            if (op[SG_PICK_IDX]) sig_x_q <= sigmoid_pick_q[int'(lane_q[4:3])];", '')
start=s.index('    genvar sigmoid_group;')
end=s.index('    // Only scalar-product launch states',start)
s=s[:start]+s[end:]
replace('''                op[N_DIV_WAIT_IDX] : if (div_done) begin
                    reciprocal_q <= div_quotient[24:0] + {24'h0, divide_round_up}; row_q <= 0;''', '''                op[N_DIV_WAIT_IDX] : if (div_done) begin
                    norm_quotient_q <= div_quotient[24:0]; norm_round_q <= divide_round_up; op <= N_DIV_ROUND;
                end
                op[N_DIV_ROUND_IDX] : begin
                    reciprocal_q <= norm_quotient_q + {24'h0, norm_round_q}; row_q <= 0;''')
start=s.index('                op[A_LANE_IDX] : begin')
end=s.index('                op[A_FLAGS_IDX]',start)
s=s[:start]+'''                op[A_LANE_IDX] : if (attention_norm_ready) op <= A_NORM_WAIT;
                op[A_NORM_WAIT_IDX] : if (attention_norm_done) begin
                    write_vector_addr_q <= 7'(60 + head_q); write_vector_mask_q <= 32'hffffffff; op <= O_WRITE;
                    if (head_q == 3) return_w <= RET_W_O_FINISH;
                    else begin
                        head_q <= head_q + 1'b1; time_q <= 0;
                        max_score_q <= 32'sh80000000; probability_sum_q <= 0;
                        v_address_q <= 7'(24 + head_q + 1'b1); return_v <= RET_V_A_QUERY; return_w <= RET_W_O_V_REQ;
                    end
                end
'''+s[end:]
replace('op[S_SIG_WAIT_IDX] : if (sig_done)', 'op[S_SIG_WAIT_IDX] : if (&sig_done)')
replace("                    if (lane_q == 31) op <= S_MUL;", "                    if (int'(lane_q) + SIGMOID_LANES >= 32) begin lane_q <= 0; op <= S_MUL; end")
replace("                        lane_q <= lane_q + 1'b1;", "                        lane_q <= lane_q + 5'(SIGMOID_LANES);")
path.write_text(s,newline='\n')
name='llm_attention_normalize.sv'
(rtl/name).write_text((ROOT/'tools/optimization_staging'/name).read_text(),newline='\n')
qsf=ROOT/'quartus/llm_soc.qsf'
qsf.write_text(qsf.read_text()+'\nset_global_assignment -name SYSTEMVERILOG_FILE "../Verilog Source code/'+name+'"\n',newline='\n')
print('OPTIMIZATION_WAVE4_APPLIED')
