"""Install the approved exact ternary engine and SIMD streaming protocol."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rtl=ROOT/'Verilog Source code'
stage=ROOT/'tools/optimization_staging'
soc=rtl/'llm_soc.sv'
s=soc.read_text()
def replace(old,new):
    global s
    assert old in s,old[:100]
    s=s.replace(old,new)
replace('localparam int OP_COUNT = 105;', 'localparam int OP_COUNT = 106;')
replace('    localparam int H_PRELOAD_IDX = 104;', '    localparam int H_PRELOAD_IDX = 104;\n    localparam int L_DOT_WAIT_IDX = 105;')
replace("        H_PRELOAD = OP_COUNT'(1) << H_PRELOAD_IDX,", "        H_PRELOAD = OP_COUNT'(1) << H_PRELOAD_IDX,\n        L_DOT_WAIT = OP_COUNT'(1) << L_DOT_WAIT_IDX,")
replace('    logic math_start, math_busy, math_done;', '    logic math_start, math_busy, math_done, math_in_ready, math_product_valid, math_sum_valid;')
replace('    llm_math u_math(', '    llm_math #(.STREAMING(1)) u_math(')
replace('.product(math_product), .sum(math_sum));', '.product(math_product), .sum(math_sum), .in_ready(math_in_ready),\n        .product_valid(math_product_valid), .sum_valid(math_sum_valid));')
replace('    assign math_start = op[O_M_START_IDX];', '''    assign math_start = op[O_M_START_IDX];
    logic ternary_valid, ternary_reserved;
    logic signed [29:0] ternary_sum;
    ternary_dot32 u_ternary(.clk(clk), .rst_n(core_rst_n), .valid_i(op[L_DECODE_IDX]),
        .x_i(math_a_q), .w_i(ternary_code_q), .valid_o(ternary_valid),
        .reserved_o(ternary_reserved), .sum_o(ternary_sum));''')
replace('                    if (reserved_weight) begin op_fault_q <= 1; op <= O_FINISH; end\n                    else op <= L_DECODE;', '                    op <= L_DECODE;')
replace('                op[L_DECODE_IDX] : begin return_m <= RET_M_L_MAC; op <= O_M_START; end', '''                op[L_DECODE_IDX] : op <= L_DOT_WAIT;
                op[L_DOT_WAIT_IDX] : if (ternary_valid) begin
                    if (ternary_reserved) begin op_fault_q <= 1; op <= O_FINISH; end
                    else op <= L_MAC;
                end''')
replace('                op[L_MAC_IDX] : begin\n                    linear_acc_q <= linear_acc_q + math_sum[38:0];', '                op[L_MAC_IDX] : begin\n                    linear_acc_q <= linear_acc_q + 39\'(ternary_sum);')
soc.write_text(s,newline='\n')
(rtl/'ternary_dot32.sv').write_text((stage/'ternary_dot32.sv').read_text(),newline='\n')
math=rtl/'llm_math.sv'
m=math.read_text()
m=m.replace('module llm_math (', 'module llm_math #(parameter bit STREAMING = 0) (')
m=m.replace('output logic busy, done,', 'output logic busy, done, in_ready, product_valid, sum_valid,')
m=m.replace('    assign done = valid_q[9];', '''    // Product and reduction responses have separate validity; their pipeline depths differ.
    assign in_ready = rst_n && (STREAMING || !busy);
    assign product_valid = valid_q[3];
    assign sum_valid = valid_q[8];
    assign done = valid_q[9]; // Legacy completion remains unchanged for one outstanding request.''')
m=m.replace('start && !busy', 'start && in_ready')
math.write_text(m,newline='\n')
t=ROOT/'tests/full_rtl/tb_math.sv'
text=t.read_text().replace('start=0, busy, done;', 'start=0, busy, done, in_ready, product_valid, sum_valid;')
text=text.replace('    llm_math dut(.*);', '''    logic stream_complete, ternary_complete;
    llm_stream_checker u_stream_check(.complete(stream_complete));
    llm_ternary_checker u_ternary_check(.complete(ternary_complete));
    llm_math dut(.*);''')
text=text.replace('        $display("LLM_MATH_PASS', '        wait(stream_complete && ternary_complete);\n        $display("LLM_MATH_PASS')
text+='\n'+(stage/'arithmetic_checkers.sv').read_text()
t.write_text(text,newline='\n')
qsf=ROOT/'quartus/llm_soc.qsf'
qsf.write_text(qsf.read_text()+'\nset_global_assignment -name SYSTEMVERILOG_FILE "../Verilog Source code/ternary_dot32.sv"\n',newline='\n')
print('OPTIMIZATION_WAVE2_APPLIED')
