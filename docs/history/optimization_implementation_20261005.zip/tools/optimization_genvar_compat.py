"""Use separately declared structural indices for Quartus parser compatibility."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1] / 'Verilog Source code'
for name in ('llm_soc.sv', 'ternary_dot32.sv', 'llm_attention_normalize.sv', 'llm_linear_engine.sv'):
    path = root / name
    original = path.read_text(encoding='utf-8')
    names = list(dict.fromkeys(re.findall(r'for \(genvar (\w+) =', original)))
    if not names:
        raise RuntimeError(f'{name}: no inline declaration found')
    updated = re.sub(r'for \(genvar (\w+) =', r'for (\1 =', original)
    # A single declaration in module scope retains each generate block name.
    declaration = '    genvar ' + ', '.join(names) + ';\n'
    marker = updated.index('\n    ', updated.index(');') + 2) + 1
    updated = updated[:marker] + declaration + updated[marker:]
    path.write_text(updated, encoding='utf-8')
    print(f'GENVAR_COMPAT: {name}: {", ".join(names)}')
