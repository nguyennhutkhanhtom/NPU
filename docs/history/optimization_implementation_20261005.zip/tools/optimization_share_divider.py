"""Share normalization lane zero with the existing mutually exclusive RMSNorm divider."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rtl=ROOT/'Verilog Source code'
p=rtl/'llm_attention_normalize.sv'
s=p.read_text()
s=s.replace('parameter int DIV_LANES = 4)', 'parameter int DIV_LANES = 4, parameter bit USE_SHARED = 0)')
s=s.replace('    output logic ready_o, batch_start_o, done_o,', '''    input logic shared_busy_i, shared_done_i,
    input logic [63:0] shared_quotient_i,
    input logic [31:0] shared_remainder_i,
    output logic [63:0] shared_numerator_o,
    output logic [31:0] shared_denominator_o,
    output logic ready_o, batch_start_o, done_o,''')
s=s.replace('    assign batch_start_o = state == ISSUE;', '''    assign shared_numerator_o = numerator_q[0];
    assign shared_denominator_o = denominator_q;
    assign batch_start_o = state == ISSUE;''')
start=s.index('        div #(.NUM_W(64)')
end=s.index('        always_ff @(posedge clk)',start)
old=s[start:end]
s=s[:start]+'''        if (lane == 0 && USE_SHARED) begin : g_shared
            assign divider_busy[lane] = shared_busy_i;
            assign divider_done[lane] = shared_done_i;
            assign quotient[lane] = shared_quotient_i;
            assign remainder[lane] = shared_remainder_i;
        end else begin : g_private
'''+old+'''        end
'''+s[end:]
p.write_text(s,newline='\n')
p=rtl/'llm_soc.sv'
s=p.read_text()
s=s.replace('    logic [767:0] attention_normalized;', '''    logic [767:0] attention_normalized;
    wire [63:0] attention_div_numerator;
    wire [31:0] attention_div_denominator;''')
s=s.replace('#(.DIV_LANES(ATTN_DIV_LANES))', '#(.DIV_LANES(ATTN_DIV_LANES), .USE_SHARED(1))')
s=s.replace('        .accumulator_i(attention_acc_q), .denominator_i(probability_sum_q),', '''        .accumulator_i(attention_acc_q), .denominator_i(probability_sum_q),
        .shared_busy_i(div_busy), .shared_done_i(div_done), .shared_quotient_i(div_quotient),
        .shared_remainder_i(div_remainder), .shared_numerator_o(attention_div_numerator),
        .shared_denominator_o(attention_div_denominator),''')
s=s.replace('''        .start(op[N_DIV_IDX] || op[A_DIV_IDX]), .numerator(div_numerator_q),
        .denominator(div_denominator_q),''', '''        .start(op[N_DIV_IDX] || attention_div_start),
        .numerator(attention_div_start ? attention_div_numerator : div_numerator_q),
        .denominator(attention_div_start ? attention_div_denominator : div_denominator_q),''')
p.write_text(s,newline='\n')
p=ROOT/'tests/full_rtl/tb_math.sv'
s=p.read_text().replace('llm_attention_normalize #(.DIV_LANES(4)) dut(.*);', '''llm_attention_normalize #(.DIV_LANES(4)) dut(.clk(clk),.rst_n(rst_n),.start_i(start_i),.cancel_i(cancel_i),
        .accumulator_i(accumulator_i),.denominator_i(denominator_i),.ready_o(ready_o),
        .batch_start_o(batch_start_o),.done_o(done_o),.vector_o(vector_o),
        .shared_busy_i(1'b0),.shared_done_i(1'b0),.shared_quotient_i(64'h0),.shared_remainder_i(32'h0),
        .shared_numerator_o(),.shared_denominator_o());''')
p.write_text(s,newline='\n')
print('NORMALIZATION_SHARED_DIVIDER_INSTALLED')
