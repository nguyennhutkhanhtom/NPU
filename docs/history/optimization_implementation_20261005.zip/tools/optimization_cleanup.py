"""Isolate active helpers and remove superseded operator bodies without changing graph IDs."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rtl=ROOT/'Verilog Source code'
for old,name,module in [('norm.sv','isqrt_u64.sv','isqrt_u64'),('banked_word_ram.sv','sram_word_tile.sv','sram_word_tile')]:
    p=rtl/old
    s=p.read_text()
    start=s.index('module '+module+' ')
    end=s.index('endmodule',start)+len('endmodule')
    (rtl/name).write_text(s[start:end]+'\n',newline='\n')
    p.write_text(s[:start]+s[end:].lstrip('\n'),newline='\n')
q=ROOT/'quartus/llm_soc.qsf'
s=q.read_text()
for name in ['norm.sv','banked_word_ram.sv','sram_256_wrapper.sv']:
    s='\n'.join(line for line in s.splitlines() if 'SYSTEMVERILOG_FILE' not in line or ('/'+name+'"') not in line)+'\n'
s+='\nset_global_assignment -name SYSTEMVERILOG_FILE "../Verilog Source code/isqrt_u64.sv"\n'
s+='set_global_assignment -name SYSTEMVERILOG_FILE "../Verilog Source code/sram_word_tile.sv"\n'
q.write_text(s,newline='\n')
p=rtl/'llm_soc.sv'
# The verified task checkpoint contains every approved change and every
# pre-existing modification. Reconstruct only this task's cleanup transformation.
s=(ROOT/'tests/full_rtl/evidence/opt_prefetch1_selected/rtl/llm_soc.sv').read_text()
for start_state,end_state in [('A_KEY','A_EXP_READ'),('H_WEIGHT','H_COEFF')]:
    start=s.index('\n                op['+start_state+'_IDX] :')
    end=s.index('\n                op['+end_state+'_IDX] :',start)
    s=s[:start]+s[end:]
s=s.replace('logic signed [31:0] score_memory [0:127], max_score_q, best_score_q;', 'logic signed [31:0] max_score_q, best_score_q;')
s=s.replace('logic [255:0] parameter_word_q, weights_q;', 'logic [255:0] parameter_word_q;')
# These operand branches belonged to the superseded linear/head serialized MACs.
s=s.replace('                    op[H_INPUT_IDX] : math_a_q[lane] <= input_cache_q[chunk_q][lane * 24 +: 24];\n','')
s=s.replace("                    op[H_INPUT_IDX] : math_b_q[lane] <= 32'($signed(weights_q[lane * 8 +: 8]));\n",'')
s=s.replace("        .start(op[N_DIV_IDX] || op[A_DIV_IDX])", "        .start(op[N_DIV_IDX])")
p.write_text(s,newline='\n')
print('ACTIVE_HELPERS_EXTRACTED_LEGACY_REMOVED_FROM_FULL_TOP_FILE_LIST')
