module llm_normalize_checker(output logic complete=0);
    logic clk=0,rst_n=0,start_i=0,cancel_i=0;
    logic signed [55:0] accumulator_i [0:31];
    logic [31:0] denominator_i;
    wire ready_o,batch_start_o,done_o;
    wire [767:0] vector_o;
    logic signed [127:0] expected [0:31],n,q,r,mag;
    integer clocks,checks=0,cancel_checks=0;
    llm_attention_normalize #(.DIV_LANES(4)) dut(.*);
    always #5 clk=~clk;
    task automatic transact(input integer fixture);
        @(negedge clk);
        case(fixture)
            0:denominator_i=1;
            1:denominator_i=2;
            2:denominator_i=3;
            3:denominator_i=65536;
            4:denominator_i=32'hffffffff;
            5:denominator_i=16777216;
            6:denominator_i=16777217;
            7:denominator_i=32'h80000000;
            default:begin denominator_i=$urandom;if(denominator_i==0) denominator_i=1;end
        endcase
        for(integer lane=0;lane<32;lane++) begin
            case(lane%8)
                0:accumulator_i[lane]=56'sh80000000000000;
                1:accumulator_i[lane]=56'sh7fffffffffffff;
                2:accumulator_i[lane]=56'(128'(denominator_i)*3+denominator_i/2);
                3:accumulator_i[lane]=-56'(128'(denominator_i)*2+denominator_i/2);
                4:accumulator_i[lane]=56'(128'(denominator_i)*8388607);
                5:accumulator_i[lane]=-56'(128'(denominator_i)*8388608);
                default:accumulator_i[lane]=56'({$urandom,$urandom});
            endcase
            n=128'(accumulator_i[lane]);mag=n<0 ? -n : n;
            q=mag/128'(denominator_i);r=mag%128'(denominator_i);
            if(2*r>128'(denominator_i) || (2*r==128'(denominator_i) && q[0])) q++;
            expected[lane]=n<0 ? -q : q;
            if(expected[lane]>8388607) expected[lane]=8388607;
            if(expected[lane]<-8388608) expected[lane]=-8388608;
        end
        if(!ready_o) $fatal(1,"Normalizer request before ready");
        start_i=1;@(negedge clk);start_i=0;clocks=0;
        while(!done_o && clocks<700) begin @(negedge clk);clocks++;end
        if(!done_o) $fatal(1,"Normalizer timeout");
        for(integer lane=0;lane<32;lane++) begin
            if(vector_o[lane*24+:24]!==expected[lane][23:0])
                $fatal(1,"Normalizer exact RNE/clamp fixture=%0d lane=%0d expected=%h actual=%h",fixture,lane,expected[lane],vector_o[lane*24+:24]);
            checks++;
        end
        @(negedge clk);if(done_o || !ready_o) $fatal(1,"Normalizer response retirement");
    endtask
    initial begin
        repeat(3) @(negedge clk);rst_n=1;
        for(integer fixture=0;fixture<18;fixture++) transact(fixture);
        for(integer phase=0;phase<6;phase++) begin
            @(negedge clk);start_i=1;@(negedge clk);start_i=0;
            repeat(phase==0 ? 1 : phase==1 ? 2 : phase==2 ? 10 : phase==3 ? 65 : phase==4 ? 68 : 70) @(negedge clk);
            rst_n=0;#1;if(done_o || batch_start_o) $fatal(1,"Normalizer reset cancellation");
            repeat(2) @(negedge clk);rst_n=1;
            repeat(72) begin @(negedge clk);if(done_o || batch_start_o) $fatal(1,"Normalizer stale reset response");end
            cancel_checks++;
        end
        for(integer phase=0;phase<3;phase++) begin
            @(negedge clk);start_i=1;@(negedge clk);start_i=0;repeat(3+phase*20) @(negedge clk);
            cancel_i=1;@(negedge clk);cancel_i=0;
            while(!ready_o) begin @(negedge clk);if(done_o) $fatal(1,"Normalizer stale cancelled response");end
            transact(phase);cancel_checks++;
        end
        $display("LLM_NORMALIZE_PASS lane_checks=%0d cancellation_phases=%0d RNE_ties=checked S56_extremes=checked reference=S128",checks,cancel_checks);
        complete=1;
    end
endmodule
