// Concurrent independent S128 scoreboards exercise sustained, sparse and cancelled traffic.
module llm_stream_checker(output logic complete = 0);
    logic clk = 0, rst_n = 0, start = 0, busy, done, in_ready, product_valid, sum_valid;
    logic signed [23:0] a [0:31];
    logic signed [31:0] b [0:31];
    wire signed [55:0] product [0:31];
    wire signed [60:0] sum;
    logic signed [127:0] products [0:2047][0:31], sums [0:2047], ref_product, ref_sum;
    integer accepted = 0, product_count = 0, sum_count = 0, checks = 0;
    logic [8:0] expected_valid = 0;
    llm_math #(.STREAMING(1)) dut(.*);
    always #5 clk = ~clk;
    always @(posedge clk) begin
        if (!rst_n) begin accepted=0; product_count=0; sum_count=0; expected_valid=0; end
        else begin
            expected_valid = {expected_valid[7:0], start && in_ready};
            if(start && in_ready) begin
                ref_sum=0;
                for(integer lane=0;lane<32;lane++) begin
                    ref_product=128'(a[lane])*128'(b[lane]);
                    products[accepted][lane]=ref_product; ref_sum+=ref_product;
                end
                sums[accepted]=ref_sum; accepted++;
            end
        end
        #1;
        if(product_valid!==expected_valid[3] || sum_valid!==expected_valid[8])
            $fatal(1,"Streaming SIMD valid/data latency mismatch");
        if(product_valid) begin
            for(integer lane=0;lane<32;lane++)
                if(product[lane]!==products[product_count][lane][55:0])
                    $fatal(1,"Streaming SIMD product transaction=%0d lane=%0d",product_count,lane);
            product_count++; checks++;
        end
        if(sum_valid) begin
            if(sum!==sums[sum_count][60:0]) $fatal(1,"Streaming SIMD sum transaction=%0d",sum_count);
            sum_count++; checks++;
        end
    end
    initial begin
        repeat(3) @(negedge clk);rst_n=1;
        for(integer packet=0;packet<1000;packet++) begin
            @(negedge clk);start=packet<64 || packet%5!=0;
            for(integer lane=0;lane<32;lane++) begin
                a[lane]=packet==0 ? 24'sh800000 : packet==1 ? 24'sh7fffff : 24'($urandom);
                b[lane]=packet==0 ? 32'sh80000000 : packet==1 ? 32'sh7fffffff : 32'($urandom);
            end
        end
        @(negedge clk);start=0;repeat(12) @(negedge clk);
        if(accepted!=product_count || accepted!=sum_count || busy) $fatal(1,"Streaming SIMD lost or duplicated response");
        for(integer phase=0;phase<10;phase++) begin
            @(negedge clk);start=1;
            @(negedge clk);start=0;repeat(phase) @(negedge clk);
            rst_n=0;#1;if(done || sum_valid || product_valid || in_ready) $fatal(1,"Streaming SIMD reset cancellation");
            repeat(2) @(negedge clk);rst_n=1;
            repeat(12) begin @(negedge clk);if(done || sum_valid || product_valid) $fatal(1,"Streaming SIMD stale response");end
        end
        $display("LLM_STREAM_PASS scoreboard_checks=%0d sustained=64 sparse=936 reset_phases=10 reference=S128",checks);
        complete=1;
    end
endmodule

module llm_ternary_checker(output logic complete = 0);
    logic clk=0,rst_n=0,valid_i=0;
    logic signed [23:0] x_i [0:31];
    logic [1:0] w_i [0:31];
    wire valid_o,reserved_o;
    wire signed [29:0] sum_o;
    logic signed [127:0] sums [0:2047], ref_sum;
    logic faults [0:2047];
    logic [3:0] expected_valid=0;
    integer accepted=0,returned=0,checks=0;
    ternary_dot32 dut(.*);
    always #5 clk=~clk;
    always @(posedge clk) begin
        if(!rst_n) begin accepted=0;returned=0;expected_valid=0;end
        else begin
            expected_valid={expected_valid[2:0],valid_i};
            if(valid_i) begin
                ref_sum=0;faults[accepted]=0;
                for(integer lane=0;lane<32;lane++) begin
                    case(w_i[lane])
                        2'b01:ref_sum+=128'(x_i[lane]);
                        2'b11:ref_sum-=128'(x_i[lane]);
                        2'b10:faults[accepted]=1;
                        default:;
                    endcase
                end
                sums[accepted]=ref_sum;accepted++;
            end
        end
        #1;
        if(valid_o!==expected_valid[3]) $fatal(1,"Ternary valid latency");
        if(valid_o) begin
            if(sum_o!==sums[returned][29:0] || reserved_o!==faults[returned])
                $fatal(1,"Ternary exact sum/fault transaction=%0d expected=%h actual=%h",returned,sums[returned],sum_o);
            returned++;checks++;
        end else if(reserved_o) $fatal(1,"Ternary untagged fault");
    end
    initial begin
        repeat(3) @(negedge clk);rst_n=1;
        for(integer packet=0;packet<1000;packet++) begin
            @(negedge clk);valid_i=packet<64 || packet%5!=0;
            for(integer lane=0;lane<32;lane++) begin
                x_i[lane]=packet<4 ? 24'sh800000 : 24'($urandom);
                w_i[lane]=packet<4 ? 2'(packet) : 2'($urandom);
            end
        end
        @(negedge clk);valid_i=0;repeat(6) @(negedge clk);
        if(accepted!=returned) $fatal(1,"Ternary lost/duplicated response");
        for(integer phase=0;phase<4;phase++) begin
            @(negedge clk);valid_i=1;
            @(negedge clk);valid_i=0;repeat(phase) @(negedge clk);
            rst_n=0;#1;if(valid_o || reserved_o) $fatal(1,"Ternary reset cancellation");
            repeat(2) @(negedge clk);rst_n=1;
            repeat(6) begin @(negedge clk);if(valid_o || reserved_o) $fatal(1,"Ternary stale response");end
        end
        $display("LLM_TERNARY_PASS transactions=%0d reserved=checked S24_MIN=checked reset_phases=4 reference=S128",checks);
        complete=1;
    end
endmodule
