# Historical optimization staging

This directory and `tools/optimization_wave*.py`, `optimization_cleanup*.py`,
`optimization_genvar_compat.py` and `optimization_share_divider.py` retain the
one-shot transformations used during the approved phased implementation.
They are implementation history, not a replay interface: later verified fixes
in the active RTL are not all represented by earlier staging files. Re-running
these transformations against the completed design can replace those fixes.

The active sources are in `Verilog Source code`. Use the standard regression,
host cancellation, portable elaboration and timing runners documented in
`docs/verification/optimization_status.md` to reproduce verification.
`tools/optimization_checkpoint.py` archives a fresh immutable task checkpoint
or reports code counts against `docs/verification/optimization_baseline/rtl`.

The requirement mapping, measured results and scope are recorded in
`rtl_change_review_v3.md`.
