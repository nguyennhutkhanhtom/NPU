"""Apply architecture-only diagrams and preserve all annotated RTL excerpts."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DOCS = ROOT / 'research/npu_explained'
BACKUP = WORK / 'before_architecture_diagrams.zip'
if BACKUP.exists():
    raise SystemExit('Backup already exists; inspect before applying this migration again.')

original = {p.relative_to(ROOT).as_posix(): p.read_bytes()
            for p in DOCS.rglob('*') if p.is_file()}
for name in ('block_visuals.py', 'build_guide.py', 'validate_guide.py', 'validation.json'):
    p = WORK / name
    original[p.relative_to(ROOT).as_posix()] = p.read_bytes()
with zipfile.ZipFile(BACKUP, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in original.items():
        archive.writestr(name, data)

# Preserve authored prose/notes, replacing the old diagram definitions at their
# canonical generator entry point so rebuilding cannot restore FSM diagrams.
p = WORK / 'block_visuals.py'
text = p.read_text(encoding='utf-8')
lines = text.splitlines(keepends=True)
spans = []
for node in ast.parse(text).body:
    if isinstance(node, ast.Assign) and any(
        isinstance(t, ast.Name) and t.id in ('DIAGRAMS', 'SECTION_DIAGRAMS')
        for t in node.targets
    ):
        spans.append((node.lineno - 1, node.end_lineno))
assert len(spans) == 2
for first, last in reversed(spans):
    del lines[first:last]
text = ''.join(lines)
text = text.replace('"""Authored Mermaid diagrams and detailed walkthroughs for the RTL guide."""',
                    '"""Authored walkthroughs; architecture diagrams live in architecture_diagrams."""\n'
                    'from architecture_diagrams import DIAGRAMS, SECTION_DIAGRAMS')
text = text.replace('# Extra diagrams are placed next to the source groups whose control/data flow is\n'
                    '# difficult to understand from prose and code alone.\n', '')
p.write_text(text, encoding='utf-8')

p = WORK / 'build_guide.py'
text = p.read_text(encoding='utf-8')
text = text.replace('from block_visuals import DIAGRAMS, DETAILS, SECTION_DIAGRAMS, GROUP_NOTES',
                    'from block_visuals import DIAGRAMS, DETAILS, SECTION_DIAGRAMS, GROUP_NOTES\n'
                    'from architecture_diagrams import LEGEND, CAPTIONS')
text = text.replace("'## Sơ đồ hoạt động'", "'## Sơ đồ kiến trúc tổng quan'")
old_caption = 'Sơ đồ chỉ biểu diễn đường dữ liệu và thứ tự điều khiển chính. Mũi tên không mặc định có nghĩa hai khối chạy song song; phần diễn giải dưới đây nêu rõ chỗ nào là tổ hợp, theo cạnh clock hoặc nhiều chu kỳ.'
assert old_caption in text
text = text.replace(repr(old_caption), "LEGEND + (' ' + CAPTIONS[name] if name in CAPTIONS else '')")
text = text.replace("'#### Minh họa logic của nhóm'", "'#### Sơ đồ khối phần cứng của nhóm'")
text = text.replace('Mỗi trang gồm vai trò, sơ đồ toàn khối, luồng hoạt động chi tiết và source được gom thành các nhóm logic. Nhóm phức tạp có thêm sơ đồ riêng ngay cạnh code. Đọc nhóm đang dùng trước; legacy/helper được giữ để tránh nhầm với hierarchy hiện tại.',
                    'Mỗi trang gồm vai trò, sơ đồ kiến trúc tổng quan, phần giải thích hoạt động và source được gom theo nhóm logic. Hình cạnh các nhóm code cũng mô tả khối phần cứng và kết nối, không mô tả FSM, timing hay pipeline CPU. Package được trình bày như quan hệ định nghĩa RTL; legacy/helper có sơ đồ độc lập và không thuộc hierarchy NPU hiện tại.')
p.write_text(text, encoding='utf-8')

subprocess.run([sys.executable, str(WORK / 'build_guide.py')], check=True, cwd=ROOT)

from architecture_diagrams import OVERVIEW, LEGEND
p = DOCS / 'README.md'
text = p.read_text(encoding='utf-8')
text, count = re.subn(r'```mermaid\n.*?\n```', lambda _: '```mermaid\n' + OVERVIEW + '\n```', text, flags=re.S)
assert count == 1
text = text.replace('Mỗi trang có tổng quan, sơ đồ hoạt động và các đoạn source',
                    'Mỗi trang có tổng quan, sơ đồ kiến trúc phần cứng và các đoạn source')
text = text.replace('Logic nhiều bước có thêm sơ đồ riêng ngay cạnh phần giải thích.',
                    'Các nhóm logic phức tạp có thêm sơ đồ khối phần cứng ngay cạnh phần giải thích.')
text = text.replace('## 2. Sơ đồ kiến trúc đang chạy', '## 2. Sơ đồ kiến trúc tổng quan đang chạy')
text = text.replace('Các đường đến workspace đi qua mux trong `matmulfree`.',
                    LEGEND + '\n\nCác đường đến workspace đi qua mux trong `matmulfree`.')
text = text.replace('đủ **29 sơ đồ tổng quan RTL**, **16 sơ đồ chi tiết** và **122 nhóm logic**',
                    'đủ **46 sơ đồ kiến trúc/quan hệ RTL** (1 tổng quan NPU, 29 toàn khối, 16 sơ đồ phần cứng theo nhóm) và **122 nhóm logic**')
text = text.replace('Kết quả kiểm tra được lưu trong [validation.json](../../review/npu_explanation/validation.json).',
                    'Kết quả kiểm tra được lưu trong [validation.json](../../review/npu_explanation/validation.json). '
                    'Các hình được cập nhật ngày 30/09/2026 theo cấu trúc phần cứng; package biểu diễn phụ thuộc định nghĩa, còn module legacy chỉ xuất hiện độc lập trong trang riêng.')
p.write_text(text, encoding='utf-8')

# Guard the edit scope: source excerpts and the source snapshot must be identical.
code_pattern = re.compile(r'<!-- source-range:.*?```systemverilog\n.*?\n```', re.S)
changes = []
for relative, before in original.items():
    p = ROOT / relative
    after = p.read_bytes()
    if after == before:
        continue
    if relative.startswith('research/npu_explained/') and p.suffix == '.md':
        old = before.decode('utf-8').replace('\r\n', '\n')
        new = after.decode('utf-8').replace('\r\n', '\n')
        assert code_pattern.findall(old) == code_pattern.findall(new), relative
        old_graphs = re.findall(r'```mermaid\n(.*?)\n```', old, re.S)
        new_graphs = re.findall(r'```mermaid\n(.*?)\n```', new, re.S)
        assert len(old_graphs) == len(new_graphs), relative
        assert all(a != b for a, b in zip(old_graphs, new_graphs)), relative
        changes.append({'document': relative, 'diagrams_replaced': len(new_graphs)})
assert (DOCS / 'source_manifest.json').read_bytes() == original['research/npu_explained/source_manifest.json']
assert sum(item['diagrams_replaced'] for item in changes) == 46
(WORK / 'architecture_changes.json').write_text(json.dumps({
    'diagrams_replaced': 46,
    'source_excerpts_unchanged': True,
    'source_manifest_unchanged': True,
    'documents': changes,
    'backup': BACKUP.as_posix(),
}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'diagrams_replaced': 46, 'changed_docs': len(changes), 'backup': BACKUP.as_posix()}))
