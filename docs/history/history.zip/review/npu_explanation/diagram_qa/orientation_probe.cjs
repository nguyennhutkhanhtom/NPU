const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('C:/Users/khanh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

(async () => {
  const browser = await chromium.launch({
    executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    headless: true,
  });
  const page = await browser.newPage({ viewport: { width: 1400, height: 650 } });
  await page.setContent('<!doctype html><div id="diagram"></div>');
  await page.addScriptTag({ path: path.join(__dirname, 'mermaid.min.js') });
  const code = `flowchart LR
    I1["inputs"] --> A@{ shape: trap-t, label: "trap-t" } --> O1["output"]
    I2["inputs"] --> B@{ shape: trap-b, label: "trap-b" } --> O2["output"]
    I3["inputs"] --> C@{ shape: lean-r, label: "lean-r" } --> O3["output"]
    I4["inputs"] --> D@{ shape: lean-l, label: "lean-l" } --> O4["output"]
    I5["inputs"] --> E@{ shape: odd, label: "odd" } --> O5["output"]
    I6["inputs"] --> F@{ shape: manual-input, label: "manual-input" } --> O6["output"]
    I7["inputs"] --> G@{ shape: manual-file, label: "manual-file" } --> O7["output"]`;
  await page.evaluate(() => mermaid.initialize({
    startOnLoad: false,
    securityLevel: 'strict',
    theme: 'neutral',
    flowchart: { htmlLabels: true, useMaxWidth: false },
  }));
  const svg = await page.evaluate(async source => (await mermaid.render('orientation-probe', source)).svg, code);
  await page.locator('#diagram').evaluate((element, content) => { element.innerHTML = content; }, svg);
  fs.writeFileSync(path.join(__dirname, 'orientation_probe.svg'), svg);
  await page.locator('#diagram').screenshot({ path: path.join(__dirname, 'orientation_probe.png') });
  console.log(JSON.stringify({ parsed: true }));
  await browser.close();
})().catch(error => { console.error(error); process.exit(1); });
