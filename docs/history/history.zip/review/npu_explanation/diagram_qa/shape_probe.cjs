const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('C:/Users/khanh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  const page = await browser.newPage({ viewport: { width: 900, height: 500 } });
  await page.setContent('<!doctype html><div id="diagram"></div>');
  await page.addScriptTag({ path: path.join(__dirname, 'mermaid.min.js') });
  const code = `flowchart LR
    IN["Input"] --> MUX@{ shape: trap-b, label: "MUX / selector" }
    MUX --> MEM@{ shape: rect, label: "Memory array<hr/>256 × 256 bit<hr/>row 0 · row 1 · …" }
    MEM --> OUT["Output"]`;
  await page.evaluate(() => mermaid.initialize({ startOnLoad: false, securityLevel: 'strict', theme: 'neutral', flowchart: { htmlLabels: true, useMaxWidth: false } }));
  const svg = await page.evaluate(async code => (await mermaid.render('probe', code)).svg, code);
  await page.locator('#diagram').evaluate((el, svg) => el.innerHTML = svg, svg);
  fs.writeFileSync(path.join(__dirname, 'shape_probe.svg'), svg);
  await page.locator('#diagram').screenshot({ path: path.join(__dirname, 'shape_probe.png') });
  console.log(JSON.stringify({ parsed: true }));
  await browser.close();
})().catch(error => { console.error(error); process.exit(1); });
