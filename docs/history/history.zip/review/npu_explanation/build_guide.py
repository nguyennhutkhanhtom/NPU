from pathlib import Path
import re, json, hashlib, html
from block_visuals import DIAGRAMS, DETAILS, SECTION_DIAGRAMS, GROUP_NOTES
from architecture_diagrams import LEGEND, CAPTIONS, OVERVIEW

ROOT = Path(r'D:\2151097_Nguyen Nhut Khanh')
SRC = ROOT / 'Verilog Source code'
OUT = ROOT / 'research/npu_explained'
BLOCKDIR = OUT / 'blocks'
BLOCKDIR.mkdir(parents=True, exist_ok=True)

# The introductions and section notes are authored against this RTL snapshot.
# The renderer preserves one table row per physical source line.
BLOCKS = {}
def block(name, title, status, overview, flow, sections):
    BLOCKS[name] = dict(title=title, status=status, overview=overview, flow=flow, sections=sections)

block('matmulfree.sv', 'Top-level: điều phối toàn NPU', 'Đang dùng — core chính',
'''Đây là nơi nối host, instruction memory, descriptor, SRAM và ba execution unit. Core không đưa nhiều instruction vào pipeline. Một FSM chọn unit, đợi kết quả rồi mới tăng PC. Vì vậy khi đọc file này, cần theo dõi đồng thời `sched` (bước điều khiển) và `active_unit` (unit được nối với workspace).

Port host là bus đơn giản 32 bit, không phải AXI/APB. Địa chỉ host tính theo byte; SRAM compute tính theo word 256 bit. Host write dữ liệu chỉ được cho phép khi core không chạy.''',
'''`start → S_FETCH → S_START → S_WAIT → S_ADVANCE`. TMATMUL dùng scale động đi qua `S_COMPOSE_START/WAIT` trước `S_TM_START`. HALT hoặc lỗi dẫn đến `S_HALT`, đưa ready lên 1. Overflow được giữ đến lần start kế tiếp; error và overflow là hai trạng thái khác nhau.

Cache q không chỉ giữ D: còn giữ base và length để scale gắn đúng tensor. Bất kỳ ghi đè vùng q nào cũng làm metadata cũ mất hiệu lực.''',
[(1,24,'Giao diện và opcode','Khai báo host port, trạng thái thực thi và mã instruction. Các tên DIV/EXP/LDV/STV không có nghĩa scheduler hỗ trợ chúng.'),
(25,42,'Giải mã host','Kiểm tra cả vùng địa chỉ lẫn alignment 4 byte. Chỉ control read được chấp nhận trong lúc running.'),
(43,60,'Program counter và instruction memory','PC 9 bit chọn một trong 512 instruction; host chỉ ghi 13 bit thấp của word vào program.'),
(61,89,'Descriptor','Ba ID trong instruction chọn source0, source1 và destination. TMATMUL dùng trường source1 để chọn matrix descriptor.'),
(90,136,'Hai SRAM','Workspace đọc/ghi bởi unit đang hoạt động. Parameter SRAM chỉ đọc ở phía compute; host nạp weight và bias.'),
(137,163,'Rowwise unit','Đưa descriptor và opcode vào dispatcher; dữ liệu workspace dùng chung được nhận qua valid.'),
(164,201,'NORM + QUANT','Nối scratch, epsilon, delta và metadata D. M/r đầu ra có thể đọc qua control window để debug.'),
(202,240,'Ternary unit','Đưa descriptor đã ghép scale vào TMATMUL. Cổng đọc parameter được nối riêng.'),
(241,266,'Scale động','Mỗi workspace descriptor có cache D. scale_compose nhận hệ số weight/output và D của nguồn q.'),
(267,292,'Hiệu lực metadata','Ghi tensor làm vô hiệu scale cũ. NORM hoàn thành thành công mới gắn D mới vào descriptor đích.'),
(293,312,'Phát start và điều khiển PC','Start của unit là xung theo state. PC chỉ advance sau khi instruction trước đã kết thúc.'),
(313,344,'Mux workspace','Chỉ unit được active_unit chọn có quyền phát địa chỉ, data và enable ra workspace.'),
(345,434,'Scheduler','Bắt đầu lượt chạy, chốt instruction, kiểm tra scale q, đợi done, gom lỗi và dừng ở HALT. Các phép gán trong một clock dùng giá trị cũ ở vế phải.'),
(435,462,'Host đọc status','Mux trả parameter, workspace, descriptor, program hoặc control/status theo địa chỉ host.'),
(463,475,'Host ghi cấu hình','Control register giữ base scratch, epsilon 64 bit và delta. Chỉ cập nhật khi không running.')])

block('npu_pkg.sv','Kiểu dữ liệu, saturation và rounding','Đang dùng — package chung',
'''Package thống nhất format tensor, layout descriptor và các hàm số học. Đây là chỗ nên đọc trước các datapath. `logic signed` có sign bit nằm trong độ rộng đã ghi; S16 gồm cả bit dấu. `struct packed` ghép các trường thành một vector bit liên tục theo thứ tự khai báo.''',
'''`sat_s16/sat_s32` clamp về miền biểu diễn. `rne_shift64` tách sign và magnitude, xác định guard/sticky/LSB rồi làm tròn ties-to-even. `scale_shift64` dùng RNE khi chia cho 2^shift, hoặc shift trái khi phải tăng scale raw. Các hàm kiểm tra workspace tính số word bằng phép chia làm tròn lên.''',
[(1,17,'Thông số chung','SRAM 256 bit, 32 ternary lane, 2 vector lane, K tối đa 512. Thay hằng số riêng lẻ chưa đủ để tái cấu hình toàn RTL vì một số khối còn width cố định.'),
(18,46,'Format và descriptor','Length là số phần tử. Matrix row bắt đầu trên ranh giới word; bias S32 pack 8 phần tử/word.'),
(47,58,'Saturation','So sánh trong S64 trước khi lấy bit thấp, tránh wrap-around.'),
(59,89,'RNE','Guard là bit ngay dưới phần giữ lại. Sticky OR các bit thấp hơn; khi đúng nửa đơn vị, chỉ tăng nếu LSB đang lẻ.'),
(90,98,'Đổi scale','Shift dương chia và RNE; shift âm nhân lũy thừa hai. Caller phải bảo đảm miền shift và operand không tràn.'),
(99,117,'Kiểm tra memory','Tính ceil(length/elements_per_word), kiểm tra cuối vùng SRAM và phép giao nhau của hai khoảng nửa mở [base, base+size).')])

block('norm.sv','RMSNorm toàn vector và QUANT','Đang dùng — chứa norm và isqrt_u64',
'''File có hai module. `isqrt_u64` tính căn nguyên của một số U64. `norm` sử dụng căn này, một divider tuần tự và ba lượt đọc/tính để biến vector S16 thành q S8. Các hệ số M/r là số nguyên mô tả scale; không có floating-point.

RMSNorm ở đây không có affine gamma/beta. Epsilon đã được host quy đổi sang raw mean-square với 32 fractional bit. Scratch z là S24/F16, đặt trong ô S32; output q dùng scale D/(0x7F×0x1_0000).''',
'''Lượt 1: tính S=Σx², chia cho K với phần lẻ 32 bit, cộng epsilon rồi lấy căn R. Tính M_norm/r_norm xấp xỉ 2^32/R. Lượt 2: đọc X lần nữa, tạo z và maxabs. Tính D=max(maxabs,delta), M_quant/r_quant xấp xỉ 127/D. Lượt 3: đọc scratch z, quantize, pack q và ghi workspace.

Scratch không được overlap X hoặc q. q có thể dùng lại vùng X vì lúc ghi q, X đã được tiêu thụ hết. Tail ngoài K không tham gia phép tính. Nếu z vượt S24 thì overflow được báo; top dừng chuỗi sau NORM đó.''',
[(1,49,'Căn nguyên tuần tự','Thuật toán thử các lũy thừa của 4 từ 2^62 trở xuống. Mỗi bước quyết định một phần kết quả; sau 32 bước trả floor(sqrt(radicand)).'),
(50,98,'Giao diện và state NORM','Tách state request/wait/process/write để không dùng dữ liệu SRAM trước valid.'),
(99,154,'Thanh ghi và scalar unit','sum_sq U40; v_raw U64; hệ số U24/U6; pack buffer 256 bit. Divider 64/32 và square-root là hai instance nội bộ.'),
(155,170,'Bình phương hai phần tử','Lấy hai S16 từ read_buf. Chỉ cộng bình phương nếu chỉ số nằm trong K, kể cả word cuối chưa đủ phần tử.'),
(171,204,'Chọn shift hệ số','Ưu tiên r lớn để giữ precision trong U24; lựa chọn phải đồng thời giữ tử số trong U64.'),
(205,214,'Chuẩn bị tử số và epsilon','Ghép phần nguyên và phần lẻ của mean-square. Bit 64 của tổng giúp phát hiện tràn U64.'),
(215,234,'Đường tạo z','Nhân S16 với hệ số norm, RNE, clamp S24 và tính trị tuyệt đối để tìm maxabs.'),
(235,254,'Đường tạo q','Đọc 24 bit thấp của mỗi ô S32, nhân hệ số QUANT và RNE, rồi clamp vào S8.'),
(255,309,'Phát request','Control tổ hợp theo FSM: chọn vùng input/scratch/output, phát divider start hoặc sqrt start.'),
(310,346,'Reset thanh ghi','Chỉ reset trạng thái và buffer trong khối. Nội dung workspace không được reset ở đây.'),
(347,379,'Nhận lệnh và kiểm tra vùng','Chốt bases, K, epsilon, delta. Reject K sai, delta=0, vượt SRAM hoặc scratch overlap.'),
(380,394,'Lượt 1','Đọc input theo word, đi hai lane mỗi bước và cộng pair_sq cho đến hết K.'),
(395,421,'Mean-square và căn','Lần chia thứ nhất lấy thương/phần dư; lần thứ hai lấy phần lẻ Q32. Kiểm tra tổng epsilon trước khi sqrt.'),
(422,451,'Hệ số norm','Input toàn zero dùng M=0. Trường hợp thường chia tử số cho R rồi RNE thương bằng cách so sánh hai lần remainder với denominator.'),
(452,478,'Lượt 2 và ghi scratch','Tạo hai z mỗi bước, sign-extend lên S32 và cập nhật maxabs. Cứ 8 z hoặc hết K thì ghi một word.'),
(479,505,'Hệ số quantization','Giữ D=max(absmax,delta). Nhánh cả hai bằng 0 là nhánh phòng vệ không đạt được với delta đã kiểm tra hợp lệ.'),
(506,536,'Lượt 3 và hoàn tất','Đọc từng word gồm 8 z; pack dần 32 q vào output word. FINISH hạ busy, phát done rồi về IDLE.')])

block('ternary_mul.sv','32 PE ternary và vòng lặp dot product','Đang dùng — TMATMUL',
'''Mỗi instruction tính n_rows dot product, mỗi dot product dài K. 32 PE là 32 phép chọn +q/−q/0 trong một chunk, không phải 32 output song song. Sau mỗi hàng, accumulator được rescale, cộng bias rồi pack vào output.''',
'''`REQ_CHUNK → WAIT_CHUNK → ACCUM` lặp qua ceil(K/32) chunk. Mỗi word weight chứa 128 mã, nên chỉ fetch weight ở chunk chia hết cho 4; q luôn cần word mới. Hết một row thì đọc bias (trừ no_bias), SCALE rồi WRITE khi pack đầy hoặc hết output. Tail được mask, mã 10 hữu ích gây lỗi.''',
[(1,59,'Giao diện và register','Descriptor được chốt khi start. Accumulator S18, mỗi term S9. postscale là logic tổ hợp riêng.'),
(60,83,'Ternary PE và cây cộng','Offset weight là 64×(chunk mod 4). Mỗi lane tách q S8 và mã weight 2 bit; sign-extend trước khi đổi dấu.'),
(84,107,'Địa chỉ SRAM','Weight row stride=ceil(K/128); q stride một word/chunk; bias index=row/8; output ghi từng word.'),
(108,132,'Reset','Xóa control và buffer cục bộ, không xóa SRAM.'),
(133,166,'Chốt lệnh và validate','Kiểm tra format, length, r, memory bounds và q/output overlap trước khi tính.'),
(167,183,'Nhận q và weight','got_q/got_w nhớ dữ liệu đã đến để chấp nhận hai cổng trả ở các thời điểm khác nhau.'),
(184,207,'Accumulate và bias','Cộng partial vào accumulator. Chunk cuối chuyển sang bias hoặc scale; reserved weight gây format_error.'),
(208,232,'Rescale và pack','Ghi y16 hoặc y32 vào pack_buf. Khi chưa đầy, tăng output_row và tái sử dụng cùng core.'),
(233,246,'Write và finish','Xóa pack buffer sau ghi, chuyển row tiếp theo hoặc phát done.')])

block('rowwise_op.sv','ALU vector nhỏ và cập nhật state','Đang dùng — datapath rowwise',
'''Khối nhận tối đa 16 phần tử trong một word, chốt input rồi xử lý dần. ADD/SUB/MUL/RELU đi hai phần tử mỗi bước; SIG chờ sigmoid từng phần tử; REC đi một phần tử với hai tích song song. Hai multiplier dùng chung cho MUL và REC; điều này không có nghĩa toàn chip chỉ có hai multiplier.''',
'''Đường tổ hợp tạo result_buffer_next từ buffer hiện tại. Phần sequential chốt kết quả, tiến element_index và trả done. Sign/magnitude cho phép cùng multiplier unsigned xử lý S16 và gate có raw=0x8000. REC cộng hai tích trước RNE15; tail không hữu ích giữ zero trong output.''',
[(1,34,'Giao diện và sigmoid','Chốt select, input words, scale và số phần tử hữu ích. Sigmoid nhận một lane theo element_index.'),
(35,48,'Dữ liệu trung gian','Lane mở rộng S17 phân biệt unsigned gate với S16 âm. Hai product S32, recurrent_sum S33.'),
(49,57,'Mặc định tổ hợp','Giữ buffer cũ, xóa cờ lane và tính shift từ scale nguồn/đích. REC dùng complement 0x8000−gate.'),
(58,81,'Hai multiplier dùng chung','MUL đưa hai cặp A/B; REC đưa H×F và C×(1−F). Operand isolation đưa multiplier về 0 khi không cần. Sau nhân magnitude, khôi phục sign.'),
(82,98,'Rounding và saturation','Chỉ lane hữu ích mới cập nhật output/error. Gate bị giới hạn raw 0x0000…0x8000; signed output clamp S16.'),
(99,119,'SIG, RELU và REC','Các operation đặc biệt ghi đè đường kết quả chung. REC dùng một RNE sau tổng S33, tránh sai số làm tròn hai lần.'),
(120,144,'Reset','Xóa buffer và trạng thái giao dịch cũ.'),
(145,171,'Chốt input và validate','Nhận start khi !busy. Reject số phần tử/scale/opcode sai; input được giữ trong register để host hoặc dispatcher thay tín hiệu ngoài không ảnh hưởng phép tính đang chạy.'),
(172,194,'Chạy từng lane','SIG chỉ tiến khi sig_done. Operation khác tích lũy cờ, tăng một lane cho REC hoặc hai lane cho các phép còn lại.')])

block('rowwise_dispatch.sv','Đọc tensor, gọi ALU và ghi output','Đang dùng — điều phối rowwise',
'''Dispatcher làm việc ở mức memory và descriptor, còn rowwise_op làm số học trên một word. A/B/destination phải có length phù hợp. ADD/SUB cần cùng scale nguồn; MUL cho phép scale nguồn khác; REC yêu cầu candidate và state có cùng scale, gate U16/F15.''',
'''Đọc A; nếu SIG/RELU thì gọi ALU ngay. Nếu phép hai nguồn thì đọc B; REC còn đọc destination cũ thành C-word. Sau ALU done, nếu không lỗi format thì WRITE. Lặp đến ceil(length/16) word. In-place cùng base được hỗ trợ ở các trường hợp đã kiểm tra; overlap lệch base bị từ chối.''',
[(1,22,'Giao diện và state','Một request đọc tại một thời điểm, các word nguồn được giữ trong buffer.'),
(23,51,'Validate và tail','Kiểm tra format, scale, độ dài và overlap. valid_elems=min(16, số phần tử còn lại).'),
(52,71,'Nối ALU','F_t, unsigned flag và số lane hữu ích đi kèm từng giao dịch.'),
(72,95,'Request memory','REQ_A/B/C chọn base tương ứng; WRITE dùng alu_result.'),
(96,116,'Reset','Xóa control, descriptor đã chốt và word buffer.'),
(117,136,'Nhận lệnh và đọc A','Chốt descriptor một lần. SIG/RELU xóa nguồn B không cần dùng.'),
(137,154,'Đọc B/state và chờ ALU','REC lấy state từ destination; lỗi format từ ALU ngăn write word đó.'),
(155,166,'Tiến word và kết thúc','Tăng word_index hoặc FINISH, phát done một chu kỳ.')])

block('scale_compose.sv','Ghép scale động của q vào postscale','Đang dùng — trước TMATMUL dynamic_q',
'''Khối biến `(factor_m/2^factor_r) × quant_d/(0x7F×0x1_0000)` thành một cặp result_m/result_r. factor_m biểu diễn phần scale weight/output; quant_d đến từ NORM. Hệ số được chuẩn bị theo tensor, không tính lại cho từng weight.''',
'''Bắt đầu candidate r=47. Nếu tử số bị tràn hoặc M sau chia quá lớn, giảm r rồi thử lại. Divider 64/64 trả quotient/remainder; RNE quyết định M. Hệ số không biểu diễn được, D=0 hoặc r sai làm format_error; factor_m=0 là trường hợp zero hợp lệ.''',
[(1,20,'Giao diện và thanh ghi','Tử số cơ sở là U48 từ hai U24; phép chia và shift thực hiện trong U64.'),
(21,37,'Chuẩn bị phép chia','Shift candidate−base_r dương đưa vào tử, âm đưa vào mẫu. Hằng `0x007F_0000` bằng `0x7F×0x1_0000`. Kiểm tra overflow trước shift.'),
(38,49,'Divider riêng','Một instance 64/64, start chỉ ở DIV_START.'),
(50,78,'Reset và nhận hệ số','Chốt factor_m×D, factor_r; thử r lớn nhất trước.'),
(79,106,'Thử hệ số','RNE thương bằng twice_rem; giảm candidate nếu M vượt 0xffffff, reject nếu underflow về 0 hoặc không còn r phù hợp.'),
(107,118,'Trả kết quả','M/r giữ kết quả khi done; FINISH đưa state về IDLE.')])

block('sigmoid.sv','Sigmoid bằng ROM và nội suy','Đang dùng — gọi từ rowwise_op',
'''Input là S16 với F_t=0…24, output gate U16/F15. LUT có 257 mẫu từ −8 đến +8, bước 1/16. Với điểm giữa hai mẫu, khối đọc lần lượt y0 và y1 rồi nội suy bằng fraction 24 bit. Bảng tính sẵn, nên runtime không cần exp.''',
'''`IDLE → READ0 → READ1 → INTERP → IDLE`. Chỉ index/fraction được chốt lúc start; thay x_raw sau đó không thay kết quả. Ngoài miền LUT, dùng mẫu biên. Branch SYNTHESIS luôn dùng function case; file LUT ngoài chỉ dành cho simulation và bị kiểm tra từng mẫu.''',
[(1,26,'Giao diện và ROM address','Một lookup ROM được dùng hai lần kế tiếp; endpoint `0x100` không đọc index kế tiếp.'),
(27,58,'Synthesis và simulation','Case ROM hằng dùng ở synthesis. Simulation có thể load hex sau khi kiểm tra đúng 257 mẫu; lỗi file gây fatal.'),
(59,80,'Tọa độ và nội suy','grid=(x_raw×2^(28−F_t))+(0x80×2^24), tương đương (x_real×16+0x80) trong Q24. RNE áp dụng trên cả y0+delta, giữ đúng parity khi tie.'),
(81,117,'FSM lấy hai mẫu','READ0/READ1 chốt giá trị ROM; INTERP ghi output và phát done.')])

block('sram_256_wrapper.sv','Ranh giới giữa RTL và SRAM macro','Đang dùng — chung cho hai SRAM',
'''Mảng memory có word 256 bit và depth=2^ADDR_W. Host thao tác một lane 32 bit, compute thao tác cả word. Đây là behavioral model có ranh giới rõ để thay bằng adapter macro; chưa chứng minh ánh xạ vào SRAM macro cụ thể.''',
'''Một mux tạo write_address/data/mask. Host write có ưu tiên trong mux, nhưng top phải bảo đảm host và compute không đồng thời truy cập. SRAM data không reset; chỉ read-control và read-output reset. Tại cạnh nhận rd_en, chốt địa chỉ; cạnh kế tiếp khi read_pending_q=1, xuất data/valid. Consumer synchronous thấy kết quả ở cạnh lấy mẫu tiếp theo. Host read là combinational và cần bridge khi thay macro synchronous.''',
[(1,28,'Giao diện và memory','ADDR_W=8 cho workspace, =10 cho parameter. Host address ở đây là chỉ số word32, không còn là byte address.'),
(29,42,'Host read và write mux','Ba bit thấp host_addr chọn một trong tám lane32; các bit cao chọn word256.'),
(43,53,'Ghi memory','Không có reset loop trên array. Mask8 cho phép chỉ cập nhật lane host yêu cầu.'),
(54,71,'Compute read','Pipeline request/response dựa trên read_pending_q và read_address_q; đọc không phụ thuộc giá trị rd_addr mới khi trả kết quả cũ.'),
(72,80,'Assertion simulation','Báo lỗi nếu host chồng giao dịch compute, kể cả read đang pending. Assertion không tạo phần cứng trong SYNTHESIS.')])

block('descriptor_file.sv','Bảng mô tả tensor và ma trận','Đang dùng',
'''Tám workspace descriptor 32 bit và tám matrix descriptor 96 bit giúp instruction ngắn vẫn mô tả tensor có địa chỉ, length và scale. Đọc descriptor là combinational; host ghi đồng bộ theo word32. Ba cổng workspace đọc độc lập cho hai nguồn và đích.''',
'''Host chọn loại bằng host_is_matrix, ID bằng host_id. Workspace ghi một word. Matrix ghi ba word: thấp 31:0, giữa63:32, cao95:64. Reset xóa descriptor; tensor data trong SRAM vẫn phải được host nạp riêng.''',
[(1,22,'Giao diện và mảng','ws chứa metadata activation/state, md chứa metadata weight/bias/scale.'),(23,40,'Đọc','Chọn descriptor bằng ID hoặc slice32 cho host; word_sel ngoài0…2 trả0.'),(41,62,'Reset và ghi','Reset đủ8 entry. Host write chỉ sửa loại/word được chọn.')])

block('div.sv','Divider unsigned tuần tự','Đang dùng — scalar nội bộ',
'''Đây là divider unsigned kiểu restoring, không phải vector DIV instruction. Mỗi bước dịch một bit của numerator sang remainder, thử trừ denominator và sinh một bit quotient. NUM_W=64 trong hai instance hiện tại; DEN_W=32 ở norm và64 ở scale_compose.''',
'''Start khi rảnh chốt numerator/denominator. Mỗi cycle busy tiến một bit, sau NUM_W bước trả quotient/remainder và done. Chia0 trả quotient toàn1, remainder lấy bit thấp của numerator, div_zero=1; caller phải xử lý cờ lỗi, không dùng đó như kết quả toán học hợp lệ.''',
[(1,24,'Giao diện và độ rộng','Remainder trung gian rộng DEN_W+1 để không mất carry khi dịch.'),(25,33,'Một bước chia','Dịch remainder và quotient, nếu đủ lớn thì trừ mẫu và đặt bit quotient mới=1.'),(34,54,'Reset/start','Bắt trường hợp denominator=0 trước vòng lặp; nếu hợp lệ giữ denominator và bộ đếm.'),(55,68,'Vòng lặp','Chốt q_next/rem_shift, giảm count. Khi count cũ=1, xuất kết quả của bước cuối.')])

block('acc_mul.sv','Cây cộng 32 term ternary','Đang dùng — trong ternary_mul',
'''Tên file có “mul”, nhưng module này chỉ reduction bằng cộng. Với NUM_INPUTS=32, cây có32 lá và31 nút cộng. Mỗi term S9 được sign-extend lên ACC_W=18 trước khi cộng; sum là kết quả chunk, chưa phải tổng toàn K.''',
'''Nạp lá vào nửa cuối mảng tree, padding0 nếu cần đến lũy thừa2. Vòng lặp từ dưới lên tính parent=left+right. Đây là cây tổ hợp không có clock; với32 lá có5 tầng cộng về mặt cấu trúc, không phải31 cycle.''',
[(1,11,'Kích thước cây','LEAVES làm tròn NUM_INPUTS lên lũy thừa2; tree có2×LEAVES−1 node.'),(12,19,'Reduction','Sign-extend lá, cộng hai con vào cha, lấy tree[0]. Vòng for ở đây tạo logic song song khi elaboration/synthesis, không phải CPU loop.')])

block('postscale.sv','Đổi scale, cộng bias và saturation','Đang dùng — sau accumulator',
'''Accumulator S18 là tổng raw q×ternary. Cần nhân hệ số M/2^r để về đơn vị output, rồi cộng bias S32 đã cùng đơn vị đó. Hai output y_s16/y_s32 được tính đồng thời; flag output_s32 chọn miền kiểm tra overflow.''',
'''Tích S42 → sign-extend S64 → RNE shift r → cộng bias → clamp. Không cộng bias trước scale vì bias đã ở đơn vị output. Module tổ hợp, không tự có start/done; FSM ternary_mul quyết định lúc dùng kết quả.''',
[(1,14,'Giao diện và intermediate','U24 M được thêm bit0 trước cast signed để không bị hiểu nhầm là số âm.'),(15,24,'Số học','Giữ tích đầy đủ, làm tròn rồi cộng bias; overflow cho biết clamp theo format output đang chọn.')])

block('norm_dispatch.sv','Kiểm tra descriptor trước NORM','Đang dùng',
'''Wrapper này kiểm tra nguồn S16, đích S8, length bằng nhau và descriptor nằm trong workspace. Core norm bên trong tiếp tục kiểm tra scratch, overlap và tham số thuật toán. frac_bits không được chuyển trực tiếp vào core norm; epsilon phải đã được host quy đổi.''',
'''Nếu descriptor hợp lệ, chuyển start đến norm. Nếu không, rejected phát một pulse để done và format_error cùng lên, tránh scheduler chờ vô hạn một core chưa được start.''',
[(1,30,'Giao diện','Base scratch và các control scalar đi kèm địa chỉ tensor.'),(31,42,'Reject handshake','invalid là tổ hợp; rejected được chốt một cycle để báo lệnh bị từ chối.'),(43,70,'Nối core','Chuyển descriptor thành base/K và đưa data/status giữa norm và top.')])

for filename, mod, aw, capacity in [('regfile.sv','register',8,'8 KiB'),('mem_mapping.sv','mem_mapping',10,'32 KiB')]:
    block(filename, f'Wrapper SRAM {capacity}', 'Đang dùng',
    f'''File này giữ interface riêng cho {'workspace' if aw==8 else 'parameter memory'} nhưng dùng chung `sram_256_wrapper` với ADDR_W={aw}. Module có tên `{mod}`; {'register ở đây là workspace SRAM, không phải một bank 8 thanh ghi vector như tên lịch sử dễ gợi ra' if aw==8 else 'đường compute của instance trong top chỉ đọc; host nạp weight/bias qua cổng32bit'}.''',
    '''Compute đọc/ghi word256; host chọn một slice32. Wrapper không thêm FSM hay đổi latency. Mỗi port được nối một-một vào implementation chung; xem sram_256_wrapper để hiểu timing và write mask.''',
    [(1,20,'Hai giao diện','Địa chỉ compute đếm word256, host đếm word32. Host address byte đã được top bỏ hai bit alignment.'),(21,38,'Instance SRAM','Parameter ADDR_W quyết định depth; các named port nối trực tiếp cùng chức năng.')])

block('PC.sv','Program counter','Đang dùng',
'''PC 9 bit chọn một trong512 instruction. Clear đưa về0, advance tăng1; khi cả hai có hiệu lực, clear ưu tiên. Không có branch/jump trong module này.''',
'''Reset active-low asynchronous. Clear là điều kiện synchronous tại cạnh clk; advance chỉ được top phát sau instruction hoàn tất. Bản thân phép cộng9bit có thể wrap, nhưng scheduler chặn advance tại511.''',
[(1,7,'Giao diện','clk/reset và hai control clear/advance.'),(8,14,'Register PC','Reset hoặc clear về0; nếu chỉ advance thì tăng; nếu không có control thì giữ giá trị.')])
block('ins_mem.sv','Instruction memory do host nạp','Đang dùng',
'''Mảng512×13bit có fetch read và host read combinational, host write synchronous. Không có chương trình mặc định và không reset memory. Cần nạp HALT trước khi start.''',
'''PC trực tiếp chọn mem[addr]. Host nạp host_instr tại host_addr khi host_we. Top chặn host write lúc running. Khi đưa vào ASIC, cần chọn implementation cho hai đường read này hoặc bridge tương ứng.''',
[(1,10,'Giao diện và mảng','Địa chỉ9bit, data instruction13bit; dung lượng logic832byte.'),(11,17,'Đọc/ghi','Read tổ hợp; write tại posedge clk. Không suy ra latency của SRAM macro từ model này.')])
block('matmul_wrap.sv','Wrapper clock/reset/LED','Đang dùng nếu chọn board top',
'''Wrapper đưa CLOCK_50 vào clk và SW[0] vào rst_n của core. LEDG[0]=ready, [1]=overflow, [2]=error. Tín hiệu running/PC/instruction được giữ nội bộ, không đưa ra LED.''',
'''Không có datapath hay chương trình riêng trong wrapper. Host bên ngoài vẫn phải nạp đầy đủ memory/descriptor/program. SW[0]=0 giữ reset; đưa lên1 mới thoát reset. Khi đóng gói ASIC sẽ cần thay giao diện board phù hợp.''',
[(1,14,'Port và debug nội bộ','Tên clock theo board không phải tần số timing signoff.'),(15,29,'Instance core','Named ports đưa host thẳng vào matmulfree và status đến LED.')])

block('addsub.sv','Helper cộng/trừ có saturation','Helper — không instantiate trong top hiện tại',
'''Helper minh họa phép cộng/trừ hai S16 trong S17. Rowwise_op hiện tự thực hiện phép tương ứng với đổi scale, nên file này không phải một ALU bổ sung đang chạy trong core.''',
'''Mở rộng dấu a/b, chọn cộng b hoặc cộng −b. wide giữ kết quả17bit; XOR hai bit trên phát hiện kết quả không còn biểu diễn được bằng S16. sat_s16 clamp output.''',
[(1,10,'Giao diện','sub=1 là trừ; wide và result có độ rộng khác nhau.'),(11,17,'Datapath tổ hợp','Không clock/start/done. Helper không tự rescale nguồn/đích.')])
block('mul.sv','Helper nhân S16 và gate','Helper — không instantiate trong top hiện tại',
'''Helper nhân a signed16 với b signed16 hoặc unsigned gate. Rowwise_op đã có đường nhân chia sẻ MUL/REC riêng; không cộng helper này vào số multiplier của top.''',
'''b_s17 giữ đúng sign hoặc zero-extend gate. Tích p33 được RNE theo rshift rồi clamp S16. product chỉ xuất32bit thấp của p33. Gate unsigned vượt raw `0x8000` bị báo overflow; không nên dùng helper như multiplier U16 tổng quát không giới hạn.''',
[(1,13,'Giao diện và intermediate','b_unsigned quyết định cách diễn giải cùng16bit của b.'),(14,22,'Multiply/round/clamp','Output result được làm tròn; output product không phải result đã đổi scale.')])

for name, before, after, payload in [('fd_reg.sv','Fetch','Decode','instruction13bit và PC9bit'),('de_reg.sv','Decode','Execute','instruction, hai operand256bit và control'),('em_reg.sv','Execute','Memory','ALU result, operand256bit, instruction và control'),('mw_reg.sv','Memory','Write Back','memory/ALU result256bit, instruction và write-back control')]:
    block(name, f'Pipeline register {before} → {after}', 'Legacy — không nối vào matmulfree hiện tại',
    f'''File giữ {payload} giữa stage {before} và {after} của cấu trúc pipeline cũ. Bản đang nằm trong source đã đổi payload liên quan sang256bit, nên cũng không phải nguyên văn source thesis. Scheduler v2 không instantiate file này.''',
    '''Ở posedge clk, enable=1 cho phép chép toàn bộ input sang output. Nếu reset hoặc flush, output về0; reset active-low asynchronous, flush synchronous và ưu tiên hơn enable. Khi enable=0, thanh ghi giữ nguyên. Các assignment nằm cùng dòng vẫn là cập nhật song song tại một cạnh clock.''',
    [(1,1000,'Giao diện và register','Các suffix của tín hiệu là tên giữ lại từ pipeline cũ. Sự có mặt của file không chứng minh top hiện tại có stage tương ứng.')])
block('ctrl_unit.sv','Decoder giữ lại từ cấu trúc cũ','Legacy — không dùng trong scheduler v2',
'''Decoder này chuyển opcode sang control kiểu pipeline: reg read/write, ALU select và memory enables. Nó không phải decoder đang quyết định REC/RELU/HALT trong matmulfree.''',
'''Đặt default tất cả output trước case để không tạo latch. ADD/SUB/MUL/SIG chọn ALU và bật đọc/ghi; NORM chọn7; TMATMUL bật reg controls. LDV/STV/DIV/EXP báo unsupported. Default giữ0; không được dùng decoder này thay scheduler để suy luận toàn ISA v2.''',
[(1,12,'Port và opcode','Các tín hiệu memory/wb được giữ vì interface cũ.'),(13,23,'Decode','Điều khiển tổ hợp, không chứa pipeline FSM hay memory transaction.')])
block('hazard_detect.sv','Control stall/flush kiểu cũ','Legacy — không dùng trong top hiện tại',
'''Module chỉ tạo enable/flush dựa trên hai cờ busy. Nó không có logic so sánh ID source/destination hay forwarding. Đừng đọc tên file rồi suy ra đây là hazard unit hoàn chỉnh.''',
'''Khi multicycle_busy hoặc memory_busy, chặn PC/FD/DE, vẫn cho EM/MW chạy và đặt flush_younger. Scheduler single-issue hiện không nối các output này.''',
[(1,12,'Control tổ hợp','Các output chỉ phụ thuộc busy; không giữ state.')])
block('exp.sv','EXP stub','Legacy — không phải exp có thể sử dụng',
'''Module có tên exp_row, nhận a16bit nhưng luôn trả0. Đây là stub để đường instantiate lịch sử không ra X; không tính e^a và không thay được EXP trong model.''',
'''Scheduler từ chối opcode EXP. Greedy argmax có thể không cần softmax ở đầu ra, nhưng điều đó không có nghĩa mọi model đều không cần exp ở các operator khác.''',
[(1,8,'Stub xác định','Input a không dùng; result hằng0. Không có LUT exp trong đường inference hiện tại.')])
block('mem_burst.v','Adapter burst cho memory ngoài kiểu FPGA','Legacy — không instantiate trong ASIC core hiện tại',
'''Module chuyển burst request sang các tín hiệu app_* của memory controller. Nó không phải DDR PHY/controller hoàn chỉnh. Core hiện tại dùng SRAM/host, nên không có DDR streaming chỉ vì file này vẫn còn trong folder.

Một số comment gốc có encoding khó đọc; chú giải tập trung vào tín hiệu và FSM. Các đoạn code bị comment không hoạt động.''',
'''Chờ init_calib_complete, chọn read hoặc write từ IDLE (read ưu tiên). Các bộ đếm tách số address đã gửi và số data đã nhận/cấp. app_rdy nhận command; app_wdf_rdy nhận write data. Hoàn tất phát READ_END/WRITE_END rồi về IDLE. Offset địa chỉ tăng8 theo convention controller cũ; không diễn giải nó thành8byte cho mọi interface.

Đây là giải thích code giữ lại, không phải chứng nhận adapter đã sẵn sàng dùng với mọi IP. Concatenation địa chỉ thêm3bit có thể bị cắt theo ADDR_BITS của đích; tích hợp thực tế phải xác nhận đơn vị địa chỉ và handshake của controller.''',
[(1,38,'Giao diện burst và app','MEM_DATA_BITS mặc định256, ADDR_BITS28. Hai bus address/data thuộc interface controller cũ.'),(39,82,'State, counter và wiring','Các assign nối command, data và cờ finish; khối comment nhiều dòng không thực thi.'),(83,96,'Yêu cầu write data','wr_burst_data_req phụ thuộc state WRITE và readiness; app_wdf_wren có register và gate ready.'),(97,143,'Reset/IDLE','Reset active-high. Sau calibration, read có ưu tiên nếu cả hai request cùng lên.'),(144,180,'Read và chờ data','Theo dõi address chấp nhận và data valid bằng hai counter riêng.'),(181,216,'Write','Cấp data và địa chỉ theo các readiness riêng; giữ đủ transaction trước wait/end.'),(217,247,'Kết thúc write','Chờ command/data drain rồi phát WRITE_END; default state quay IDLE.')])

assert set(DIAGRAMS) == set(BLOCKS), (set(BLOCKS) - set(DIAGRAMS), set(DIAGRAMS) - set(BLOCKS))
assert set(DETAILS) == set(BLOCKS), (set(BLOCKS) - set(DETAILS), set(DETAILS) - set(BLOCKS))

# Align section starts with actual statements, rather than approximate paragraph sizes.
SECTION_STARTS = {
 'matmulfree.sv':[1,25,43,60,89,133,159,194,227,251,276,293,325,433,458],
 'norm.sv':[1,50,99,145,160,192,202,221,240,298,333,362,378,400,428,467,491],
 'ternary_mul.sv':[1,60,84,108,134,164,180,204,226],
 'rowwise_op.sv':[1,35,49,58,82,100,123,145,169],
 'rowwise_dispatch.sv':[1,23,52,72,95,114,136,152],
 'scale_compose.sv':[1,21,38,50,79,109],
 'sigmoid.sv':[1,27,59,80],
 'mem_burst.v':[1,40,83,95,133,185,217],
}
for name,starts in SECTION_STARTS.items():
    old=BLOCKS[name]['sections']
    assert len(old)==len(starts)
    end=len((SRC/name).read_text(encoding='utf-8').splitlines())
    BLOCKS[name]['sections']=[(a,starts[i+1]-1 if i+1<len(starts) else end,t,d) for i,(a,(_,_,t,d)) in enumerate(zip(starts,old))]

# Line-specific explanations for expressions where the numeric intent is important.
SPECIAL = {
 'assign host_desc =': 'Giải mã vùng descriptor: kiểm tra các bit địa chỉ cao, bit7=0 và alignment4byte; dòng sau kiểm tra word_sel theo workspace hay matrix.',
 'assign host_ctrl =': 'Giải mã control window0x000400xx và alignment4byte; hai dòng sau giới hạn những offset được hỗ trợ.',
 'FMT_S8 =': 'Gán mã format0 cho phần tử signed8bit, pack32 phần tử trong word256.',
 'FMT_S16 =': 'Gán mã format1 cho phần tử signed16bit, pack16 phần tử trong word256.',
 'FMT_U16 =': 'Gán mã format 0x2 cho phần tử unsigned 16 bit; đường gate yêu cầu F15 và raw không vượt 0x8000.',
 'FMT_S32 =': 'Gán mã format3 cho phần tử signed32bit, pack8 phần tử trong word256.',
 'ws_valid =': 'Descriptor hợp lệ cần length1…K_MAX và F_t≤24; dòng sau còn kiểm tra cuối vùng không vượt workspace.',
 '- $signed(magnitude_product': 'Nhánh của toán tử chọn ở dòng trước: dấu tích âm thì lấy đối magnitude, còn lại giữ magnitude.',
 "index_q + 9'd1 : index_q;": 'Hoàn tất mux địa chỉ: READ1 lấy mẫu kề trên, các trường hợp khác dùng index_q.',
 'overflow = output_s32': 'Nếu output_s32=1, so biased với biên S32; nhánh dòng sau dành cho outputS16.',
 ': (biased >': 'Nhánh output S16: overflow nếu biased vượt miền raw signed 0x8000…0x7FFF.',
 'invalid = !ws_valid(src_desc)': 'Từ chối nếu một descriptor vượt miền length/scale/memory; hai dòng sau kiểm tra S16→S8 và cùng length.',
 'weight_bit_base =': 'Chọn đầu đoạn weight64bit: ghép hai bit thấp của chunk với sáu bit0, tức (chunk mod4)×64. Không dùng literal6bit cho số64 vì sẽ bị cắt.',
 'terms[i] = -': 'Sign-extend activation lên 9 bit rồi mới đổi dấu; q=−128 (S8 raw 0x80) với weight −1 cho +128 (S9 raw 0x080) hợp lệ.',
 "2'b11 : terms": 'Weight −1: đổi dấu sau khi mở rộng S8→S9, giữ được +128 (S9 raw 0x080).',
 "2'b01 : terms": 'Weight+1: giữ nguyên giá trị activation, mở rộng dấu từ8 lên9bit.',
 'if (w ==': 'Mã weight10 trong lane hữu ích đặt cờ reserved_weight; FSM sẽ dừng thay vì coi đó là weight hợp lệ.',
 'recurrent_sum =': 'Cộng hai product sau sign-extension S32→S33: H×F + C×(0x8000−F). Bit thêm giữ carry của tổng.',
 'recurrent_value =': 'Chia tổng REC cho 0x8000 bằng RNE shift 15 một lần; không làm tròn từng tích riêng.',
 'complement =': 'Tính raw của 1−F trong U16/F15. Gate hợp lệ nằm trong 0x0000…0x8000; gate ngoài miền sẽ bị báo lỗi.',
 'result_shift =': 'MUL có F_nguồn=F_A+F_B; ADD/SUB dùng F_A. Trừ F_đích để tìm số bit shift, âm nghĩa cần shift trái.',
 'overflow = wide': 'Hai bit cao khác nhau nghĩa kết quả S17 không thể rút về S16 mà giữ nguyên dấu; đặt overflow.',
 'guard =': 'Lấy bit ngay dưới phần nguyên được giữ: bit này cho biết phần bỏ đi có ít nhất nửa đơn vị hay không.',
 'sticky =': 'OR tất cả bit dưới guard. Sticky=1 nghĩa phần bỏ đi không phải đúng nửa đơn vị.',
 'lsb =': 'Lấy bit thấp nhất của phần giữ lại để phân biệt số chẵn/lẻ khi tie.',
 'inc =': 'Tăng khi hơn nửa, hoặc đúng nửa mà phần giữ lại đang lẻ. Đây là quy tắc ties-to-even.',
 'mag =': 'Lấy magnitude unsigned theo bit dấu; kể cả trị âm nhỏ nhất của64bit, magnitude unsigned vẫn biểu diễn được.',
 'rne_shift64 = sign': 'Khôi phục dấu sau khi làm tròn magnitude, để số âm được xử lý đối xứng.',
 'mean_with_epsilon =': 'Ghép mean nguyên<<32, thương của phép chia phần dư<<32 choK và epsilon đã quy đổi; dùng65bit để phát hiện tràn.',
 'norm_num =': 'Tử số2^(32+r_norm), vì cần hệ số norm xấp xỉ2^32/R trước khi biểu diễn thànhM/2^r.',
 'quant_num =': 'Tử số127×2^r_quant; chia choD sẽ cho multiplier nguyên của bước quantize.',
 'norm_m <= div_q': 'Làm tròn quotient theo remainder: tăng nếu2×rem>R hoặc bằngR mà quotient lẻ. Chốt hệ số norm U24.',
 'quant_m <= div_q': 'RNE quotient của127×2^r/D bằng remainder, rồi chốt M_quant U24.',
 'frac_q <= div_q': 'Lưu thương phần lẻ để quan sát. V_raw ở bước này dùng trực tiếp div_q mới hoàn thành, không dùng frac_q cũ.',
 'grid =': 'Đổi x_raw và F_t thành tọa độ LUT Q24: (16×x_real+0x80)×2^24. Miền −8…8 ánh xạ thành 0x000…0x100.',
 'interpolated =': 'Cộng y0×2^24 với delta×fraction rồi RNE24 trên toàn tổng, giữ đúng parity của y0 khi tie.',
 'difference =': 'Hiệu y1−y0 của hai mẫu sigmoid kề nhau; bảng tăng nên hiệu không âm.',
 'assign rom_address =': 'Đọc index+1 chỉ khi state READ1 và index chưa là endpoint256; trường hợp còn lại dùng index đã chốt.',
 'denominator = 64': 'Mẫu số cố định 0x007F_0000 = 0x7F×0x1_0000 dùng để khôi phục scale từ D của NORM.',
 'numerator_base <= factor': 'Nhân hai U24 thành U48: phần weight/output scale nhân D của activation hiện tại.',
 'rounded = {1': 'Dùng65bit cho quotient sau RNE, tránh mất carry khi cộng1 vào U64.',
 'twice_rem =': 'Mở rộng remainder lên65bit rồi nhân2; so với denominator để quyết định rounding.',
 'rem_shift = {': 'Dịch remainder trái1 và kéo bit cao nhất chưa xử lý của numerator/quotient vào bit thấp.',
 'q_next = {': 'Dịch thanh ghi quotient trái1, dành bit0 để ghi kết quả phép so sánh/trừ ở bước này.',
 'q_next[0] =': 'Nếu remainder sau dịch đủ lớn để trừ denominator, bit quotient mới bằng1.',
 'one <= 64': 'Khởi tạo bit thử ở2^62, lũy thừa4 lớn nhất trong U64; mỗi vòng sẽ dịch xuống2bit.',
 'root <= (res': 'Chốt kết quả sau bước cuối có trừ, dùng biểu thức giá trị kế tiếp vì res chưa cập nhật tại cạnh này.',
 'assign host_rdata = memory': 'Tách host_addr thành word256 ở các bit cao và lane32 ở ba bit thấp; read tổ hợp, không đợi clock.',
 'write_data = {8': 'Nhân bản host_wdata32 vào tám lane; write_mask chỉ cho ghi lane được host chọn.',
 'write_mask = 8': 'Mask one-hot: chỉ một lane32 được cập nhật trong word256, bảy lane khác giữ nguyên.',
 'rd_valid <= read_pending': 'Valid của response lấy request pending từ cycle trước; đồng thời data đọc theo địa chỉ đã chốt.',
 'if (rst_n && host_en': 'Assertion bắt host access trùng compute request/write hoặc read pending; top phải tránh tình huống này.',
 'assign start_pulse =': 'Host write control offset0 với bit0=1 tạo start request; scheduler chỉ nhận khi không running.',
 'assign host_ready =': 'Ready chỉ lên khi địa chỉ hợp lệ và core idle, hoặc là control read trong lúc chạy.',
 'if (host_desc &&': 'Host sửa descriptor làm mất hiệu lực mọi cache q scale; cần nạp metadata trước chuỗi inference.',
 'q_d[instr_q[8:6]] <=': 'Lưu D từ NORM cho descriptor đích của instruction vừa hoàn thành.',
 'q_valid[instr_q[8:6]] <=': 'Đánh dấu scale output q hợp lệ sau NORM thành công.',
 'if (sched == S_WAIT && active_unit == 2': 'Chỉ cập nhật cache scale khi NORM đã done và không có format_error/overflow.',
 'S_ADVANCE : if (pc ==': 'Chặn việc đi tiếp qua instruction511; báo lỗi thay vì cho PC9bit wrap về0.',
 'product = $signed(acc)': 'Nhân accumulator S18 với M unsigned24 được zero-extend trước cast; giữ tích trong S42.',
 'biased =': 'Cộng bias đã cùng đơn vị output vào giá trị sau rounding. Bias được sign-extend S32→S64.',
 'if (idx0 < vector_length_q) pair': 'Chỉ cộng bình phương lane0 nếu thuộc K, bỏ padding của word cuối.',
 'if (idx1 < vector_length_q) pair': 'Chỉ cộng bình phương lane1 nếu thuộc K; hỗ trợ cả K lẻ.',
 'if ((input_chunk_q *': 'Mask lane ngoài K về zero trước reduction; padding không được ảnh hưởng dot product hoặc kiểm tra mã weight.',
 'valid_elems =': 'Tính số phần tử hữu ích của word hiện tại: min(16, length−16×word_index).',
 'chunks_per_row <=': 'Ceil(K/32): số chunk activation phải accumulate cho một output.',
 'weight_words_per_row <=': 'Ceil(K/128): stride mỗi hàng ternary trong parameter SRAM, bao gồm padding alignment.',
 'param_rd_en = (input': 'Chỉ fetch word weight mới ở mỗi nhóm4 chunk; các chunk còn lại dùng w_word đã giữ.',
 'param_rd_addr = matrix_desc_q.weight': 'Địa chỉ weight=base+row×ceil(K/128)+floor(chunk/4); mỗi row căn theo word256.',
 'if ((got_q ||': 'Vào ACCUM khi cả q và weight đã nhận, kể cả valid vừa xuất hiện ở cycle hiện tại.',
 'lane_a[j] =': 'Lấy lane 16 bit của A; zero-extend nếu gate unsigned, sign-extend nếu S16. Lane 17 bit bảo toàn raw 0x8000.',
 'lane_b[j] =': 'Lấy lane16bit của B, chọn signed hoặc unsigned theo descriptor đã chốt.',
 'magnitude_product[j] =': 'Một trong hai toán tử nhân unsigned16×16 dùng chung giữa MUL và REC; kết quả magnitude32bit.',
 'product[j] =': 'Dấu tích là XOR dấu hai operand. Dòng kế tiếp chọn magnitude hoặc đối của magnitude.',
 'multiply_a[j] = (j': 'Trong REC, multiplier0 nhận state cũ H; multiplier1 nhận candidate C. Cả hai được sign-extend lên17bit.',
 'multiply_b[j] = (j': 'Trong REC, multiplier 0 nhận F; multiplier 1 nhận 0x8000−F, đều zero-extend để không hiểu gate 1 là âm.',
 'for (i = LEAVES - 2': 'Tính từng node từ hai node con đã có giá trị, đi từ đáy lên root; mô tả balanced adder tree tổ hợp.',
 'if (i < NUM_INPUTS) tree': 'Nạp term vào lá và lặp bit dấu cho đủ ACC_W; không zero-extend số âm.',
 'else tree[LEAVES': 'Lá padding vượt số input được gán0, để tree hỗ trợ số input không là lũy thừa2.',
 'sum = tree': 'Kết quả tại root là tổng tất cả term trong chunk.',
}

# Signal meanings make declaration/wiring/register rows readable without renaming RTL.
SIGNALS = {
 'clk':'clock của khối', 'rst_n':'reset active-low', 'rst':'reset active-high của adapter cũ',
 'start':'yêu cầu bắt đầu giao dịch', 'busy':'khối đang xử lý', 'done':'xung báo hoàn tất',
 'overflow':'cờ kết quả vượt miền số', 'overflow_out':'cờ overflow tích lũy của lượt chạy',
 'format_error':'cờ format/metadata không hợp lệ', 'error':'cờ lỗi của lượt chạy', 'ready':'core đã dừng, sẵn sàng cho host', 'running':'core đang thực thi chương trình',
 'state':'trạng thái FSM của khối', 'sched':'trạng thái scheduler', 'active_unit':'unit được cấp cổng workspace',
 'host_en':'host đang yêu cầu truy cập', 'host_we':'host chọn ghi thay vì đọc', 'host_addr':'địa chỉ phía host', 'host_wdata':'data32 host muốn ghi', 'host_rdata':'data32 trả về host', 'host_ready':'giao dịch host được chấp nhận',
 'rd_en':'request đọc của compute', 'rd_addr':'địa chỉ word cần đọc', 'rd_data':'word dữ liệu đọc ra', 'rd_valid':'response đọc hợp lệ',
 'wr_en':'cho phép ghi compute', 'wr_addr':'địa chỉ word cần ghi', 'wr_data':'word dữ liệu cần ghi',
 'ws_rd_en':'request đọc workspace', 'ws_rd_addr':'địa chỉ đọc workspace', 'ws_rd_data':'word256 trả từ workspace', 'ws_rd_valid':'workspace trả dữ liệu hợp lệ',
 'ws_wr_en':'cho phép ghi workspace', 'ws_wr_addr':'địa chỉ ghi workspace', 'ws_wr_data':'word256 ghi workspace',
 'param_rd_en':'request đọc parameter SRAM', 'param_rd_addr':'địa chỉ đọc parameter SRAM', 'param_rd_data':'word256 weight/bias trả về', 'param_rd_valid':'response parameter hợp lệ',
 'input_desc_q':'descriptor q đã chốt', 'output_desc_q':'descriptor output đã chốt', 'matrix_desc_q':'matrix descriptor đã chốt',
 'source_a_desc_q':'descriptor nguồn A đã chốt', 'source_b_desc_q':'descriptor nguồn B đã chốt', 'destination_desc_q':'descriptor đích đã chốt',
 'q_desc':'metadata nguồn activation S8', 'out_desc':'metadata output TMATMUL', 'mat_desc':'metadata ma trận và postscale',
 'src_desc':'metadata tensor nguồn', 'dst_desc':'metadata tensor đích', 'a_desc':'metadata nguồn A', 'b_desc':'metadata nguồn B',
 'd_src0':'descriptor source0 đang được instruction chọn', 'd_src1':'descriptor source1 đang được instruction chọn', 'd_dst':'descriptor destination đang được chọn',
 'd_mat':'matrix descriptor gốc', 'effective_mat':'matrix descriptor với hệ số postscale hiệu dụng',
 'q_valid':'bitmask hiệu lực scale q', 'q_d':'D gắn với từng descriptor q', 'q_base':'base SRAM mà cache q mô tả', 'q_length':'length mà cache q mô tả',
 'scratch_z_base':'word đầu scratch z', 'epsilon_raw32':'epsilon theo đơn vị raw-square có32 fractional bit', 'delta_raw':'cận dưới khác0 cho D',
 'quant_d':'D=max(absmax,delta)', 'norm_m':'multiplier U24 của RMSNorm', 'norm_r':'shift của RMSNorm', 'quant_m':'multiplier U24 của QUANT', 'quant_r':'shift của QUANT',
 'input_base_q':'base input X đã chốt', 'scratch_base_q':'base scratch z đã chốt', 'output_base_q':'base q đã chốt', 'vector_length_q':'K đã chốt', 'epsilon_q':'epsilon đã chốt', 'delta_q':'delta đã chốt',
 'sum_sq':'tổng bình phương U40', 'pair_sq':'tổng bình phương của hai lane hữu ích', 'mean_q':'phần nguyên của S/K', 'mean_rem':'phần dư của S/K', 'frac_q':'phần lẻ mean-square lưu để quan sát',
 'v_raw':'mean-square Q32 đã cộng epsilon', 'rms_r':'căn nguyên U32 của v_raw', 'absmax':'trị tuyệt đối z lớn nhất đã thấy',
 'word_index':'chỉ số word đang đọc', 'word_index_q':'chỉ số word tensor đang đọc', 'word_count_q':'số word cần xử lý', 'lane':'vị trí phần tử trong word',
 'read_buf':'word SRAM đã nhận', 'pack_buf':'buffer pack output trước khi ghi SRAM', 'pack_count':'số/vị trí phần tử đang pack', 'write_word':'chỉ số word output', 'out_word':'chỉ số word output TMATMUL',
 'output_row_q':'hàng output đang tính', 'input_chunk_q':'chunk32 activation trong hàng hiện tại', 'accumulator_q':'tổng tích lũy S18 của hàng', 'partial':'tổng32 term của chunk', 'terms':'các term S9 đưa vào reduction',
 'got_q':'đã nhận word activation', 'got_w':'đã có word weight cho chunk', 'q_word':'buffer32 activation S8', 'w_word':'buffer128 ternary weight',
 'bias':'bias S32 theo đơn vị output', 'y16':'output đã clamp S16', 'y32':'output đã clamp S32',
 'source_a_q':'word nguồn A đã chốt', 'source_b_q':'word nguồn B đã chốt', 'state_word_q':'word state cũ cho REC', 'result_buffer_q':'buffer kết quả đang xây', 'result_buffer_next':'giá trị kế tiếp của buffer kết quả',
 'operation_q':'opcode đã chốt', 'element_count_q':'số phần tử hữu ích', 'element_index_q':'vị trí phần tử đang tính', 'valid_elems':'số lane hữu ích của word cuối',
 'source_a_frac_q':'F_t của A đã chốt', 'source_b_frac_q':'F_t của B đã chốt', 'destination_frac_q':'F_t output đã chốt',
 'source_a_unsigned_q':'A được diễn giải unsigned', 'source_b_unsigned_q':'B được diễn giải unsigned', 'destination_unsigned_q':'output là gate unsigned',
 'gate':'F_raw của REC trong U16/F15', 'old_state':'state H cũ', 'candidate':'ứng viên; ở REC là C, ở scale_compose là shift đang thử',
 'result_word':'word256 output rowwise', 'a_word':'word A', 'b_word':'word B', 'c_word':'word state cũ của REC', 'alu_result':'word kết quả ALU',
 'x_raw':'input raw S16 của sigmoid', 'frac_bits':'số bit phần lẻ của input', 'y_raw':'gate raw U16/F15', 'index_q':'chỉ số mẫu thấp đã chốt', 'fraction_q':'phần lẻ Q24 của tọa độ LUT đã chốt', 'index_next':'chỉ số LUT tính từ input', 'fraction_next':'phần lẻ LUT tính từ input', 'y0':'mẫu sigmoid thấp', 'y1':'mẫu sigmoid cao', 'rom_address':'địa chỉ mẫu ROM', 'rom_data':'giá trị mẫu ROM',
 'div_start':'start divider', 'div_done':'divider đã xong', 'div_busy':'divider đang chạy', 'div_zero':'divider báo mẫu bằng0', 'div_num':'tử số cấp divider', 'div_den':'mẫu số cấp divider', 'div_q':'thương divider', 'div_rem':'phần dư divider',
 'numerator':'tử số phép chia', 'denominator':'mẫu số phép chia', 'quotient':'thương', 'remainder':'phần dư', 'q_work':'thanh ghi numerator/quotient trong vòng chia', 'rem_work':'remainder đang tích lũy', 'den_reg':'denominator đã chốt', 'count':'bộ đếm bước lặp',
 'radicand':'số U64 cần lấy căn', 'root':'kết quả floor(sqrt)', 'op':'operand hoặc opcode, theo giao diện module', 'res':'kết quả căn trung gian', 'one':'lũy thừa4 đang thử trong square-root',
 'result_m':'M hiệu dụng sau ghép scale', 'result_r':'r hiệu dụng sau ghép scale', 'factor_m':'M phần weight/output scale', 'factor_r':'r phần weight/output scale', 'base_r':'r gốc đã chốt',
 'pc':'địa chỉ instruction hiện tại', 'pc_out':'register PC9bit', 'pc_clear':'đưa PC về0', 'pc_advance':'cho PC tiến1', 'instr_q':'instruction13bit đang thực thi', 'instr_fetch':'instruction đọc tại PC',
 'invalid':'descriptor/operation bị từ chối', 'rejected':'xung báo lệnh NORM bị reject',
 'read_address_q':'địa chỉ SRAM đã chốt', 'read_pending_q':'có request đọc đang chờ response', 'write_address':'địa chỉ ghi sau arbitration', 'write_data':'data256 sau arbitration', 'write_mask':'mask8 chọn lane32 cần ghi',
 'rd_addr_cnt':'số địa chỉ burst read đã phát', 'rd_data_cnt':'số data burst read đã nhận', 'wr_addr_cnt':'số địa chỉ burst write đã phát', 'wr_data_cnt':'số data burst write đã cấp',
 'app_cmd_r':'command gửi memory controller', 'app_addr_r':'địa chỉ gửi memory controller', 'app_en_r':'command valid gửi controller', 'app_wdf_end_r':'cờ cuối write data beat theo interface cũ', 'app_wdf_wren_r':'write data enable đã chốt',
}

SIGNALS.update({
 'term':'mảng các term ternary S9 cần cộng', 'sum':'tổng của chunk32term', 'tree':'các node S18 của cây cộng cân bằng', 'i':'chỉ số vòng lặp',
 'a':'operand A', 'b':'operand B', 'sub':'chọn trừ khi bằng1', 'wide':'kết quả mở rộng S17', 'result':'kết quả đã saturation',
 'b_ext':'operand B mở rộng dấu S17', 'b_s17':'B S17 sau chọn signed/gate', 'p33':'tích đầy đủ S33 của helper mul',
 'acc':'accumulator S18', 'scale_m':'multiplier U24 của postscale', 'scale_r':'shift U6 của postscale', 'output_s32':'chọn format output S32 thay vì S16',
 'product':'tích trung gian trước rescale', 'rounded':'giá trị sau rounding', 'biased':'giá trị sau cộng bias', 'scale_ov':'overflow của postscale',
 'y_s16':'output clamp S16', 'y_s32':'output clamp S32', 'rshift':'số bit chia lũy thừa2 trước saturation',
 'weight_base':'base word256 của weight', 'bias_base':'base word256 của bias', 'k_len':'độ dài dot product', 'n_rows':'số output của ma trận',
 'base_word':'địa chỉ word256 đầu tensor', 'length':'số phần tử tensor', 'reserved':'bit để dành hoặc flag mở rộng theo loại descriptor',
 'x':'giá trị đầu vào hàm số học', 'sign':'bit dấu của input', 'mag':'magnitude unsigned của input', 'q':'magnitude sau shift',
 'guard':'bit ngay dưới phần giữ lại', 'sticky':'OR các bit dưới guard', 'lsb':'bit thấp của phần giữ lại', 'inc':'quyết định tăng1 khi RNE',
 'a_unsigned':'A là gate unsigned', 'b_unsigned':'B là gate unsigned', 'dst_unsigned':'output là gate unsigned',
 'select':'opcode chọn phép rowwise', 'multiply_a':'hai operand A của multiplier dùng chung', 'multiply_b':'hai operand B của multiplier dùng chung',
 'magnitude_a':'trị tuyệt đối của operand A', 'magnitude_b':'trị tuyệt đối của operand B', 'magnitude_product':'hai tích unsigned16×16',
 'lane_a':'hai lane A mở rộng17bit', 'lane_b':'hai lane B mở rộng17bit', 'raw_value':'kết quả phép tính trước đổi scale', 'scaled':'kết quả sau đổi scale',
 'recurrent_sum':'tổng hai tích REC trong S33', 'recurrent_value':'REC sau RNE15', 'lane_overflow':'cờ overflow của bước lane hiện tại', 'lane_format_error':'cờ gate/format sai ở bước lane hiện tại',
 'result_shift':'shift cần để về F_t đích', 'complement':'raw của1−F',
 'weight_bit_base':'offset bit của nhóm32weight trong w_word', 'weight_words_per_row':'ceil(K/128), stride word của một hàng weight', 'chunks_per_row':'ceil(K/32), số bước accumulate một hàng',
 'reserved_weight':'đã gặp weightcode10 trong lane hữu ích', 'w':'mã2bit của một weight',
 'x_base':'base input S16', 'z_base':'base scratch z', 'elem_index':'register dự phòng, chưa tham gia điều khiển lượt NORM hiện tại',
 'x0':'input S16 lane thứ nhất', 'x1':'input S16 lane thứ hai', 'x0_sq':'bình phương lane0', 'x1_sq':'bình phương lane1',
 'idx0':'chỉ số phần tử toàn vector của lane0', 'idx1':'chỉ số phần tử toàn vector của lane1',
 'mean_with_epsilon':'tổng U65 để kiểm tra overflow mean-square + epsilon', 'norm_num':'tử số tính hệ số norm', 'quant_num':'tử số tính hệ số QUANT',
 'norm_r_sel':'shift norm được logic lựa chọn', 'quant_r_sel':'shift QUANT được logic lựa chọn', 'msb':'vị trí bit1 cao nhất của denominator',
 'den':'denominator của hàm chọn shift', 'limit':'giới hạn den×M_max', 'num':'tử số127<<r đang thử', 'found':'đã tìm shift hợp lệ đầu tiên khi quét từ lớn xuống',
 'z_prod0':'tích x0×M_norm S40', 'z_prod1':'tích x1×M_norm S40', 'z_round0':'z lane0 sau RNE', 'z_round1':'z lane1 sau RNE',
 'z0':'z lane0 đã clamp S24', 'z1':'z lane1 đã clamp S24', 'absz0':'magnitude z0', 'absz1':'magnitude z1',
 'zr0':'z lane0 lấy từ ô scratch S32', 'zr1':'z lane1 lấy từ ô scratch S32', 'qprod0':'tích z0×M_quant S48', 'qprod1':'tích z1×M_quant S48',
 'qround0':'q lane0 sau RNE', 'qround1':'q lane1 sau RNE', 'q0':'activation quantized S8 lane0', 'q1':'activation quantized S8 lane1',
 'numerator_base':'tích U48 factor_m×D đã chốt', 'twice_rem':'hai lần remainder trong U65', 'shift':'độ dịch để biểu diễn scale; ý nghĩa dấu theo hàm đang dùng', 'shift_overflow':'shift sẽ vượt U64',
 'q_next':'quotient sau một bước divider', 'rem_shift':'remainder sau dịch/thử trừ ở bước hiện tại',
 'grid':'tọa độ LUT trong Q24', 'x_extended':'input S16 sign-extend lên S64', 'interpolated':'giá trị sigmoid nội suy sau RNE', 'difference':'y1−y0', 'lut':'array mẫu dùng cho simulation từ file',
 'sig_x':'lane S16 gửi sigmoid', 'sig_y':'gate U16/F15 nhận từ sigmoid',
 'composed_m':'M hiệu dụng từ scale_compose', 'composed_r':'r hiệu dụng từ scale_compose',
 'host_param':'địa chỉ host thuộc parameter SRAM', 'host_ws':'địa chỉ host thuộc workspace', 'host_desc':'địa chỉ host thuộc descriptor window', 'host_imem':'địa chỉ host thuộc instruction memory', 'host_ctrl':'địa chỉ host thuộc control window',
 'desc_host_id':'ID descriptor do host chọn', 'desc_host_matrix':'host đang chọn matrix descriptor', 'desc_host_word':'slice32 của matrix descriptor',
 'host_id':'ID descriptor0…7', 'host_is_matrix':'chọn matrix thay vì workspace descriptor', 'host_word_sel':'chọn slice32 của matrix descriptor',
 'ws_id0':'ID descriptor source0', 'ws_id1':'ID descriptor source1', 'ws_id2':'ID descriptor destination',
 'ws_desc0':'descriptor source0 đọc ra', 'ws_desc1':'descriptor source1 đọc ra', 'ws_desc2':'descriptor destination đọc ra', 'mat_id':'ID matrix descriptor',
 'addr':'địa chỉ fetch instruction', 'instr':'instruction đọc từ program', 'host_instr':'instruction13bit host ghi', 'host_rinstr':'instruction13bit trả host', 'mem':'array instruction512×13bit',
 'memory':'array dữ liệu SRAM word256', 'clear':'đưa PC về0', 'advance':'tăng PC lên instruction kế tiếp',
 'instr_debug':'instruction đang thực thi đưa ra debug', 'pc_debug':'PC đưa ra debug', 'CLOCK_50':'clock từ board wrapper', 'SW':'switch0 dùng làm rst_n', 'LEDG':'ba LED chỉ ready/overflow/error',
 'reg_wr_en':'cho phép ghi register kiểu pipeline cũ', 'reg_rd_en':'cho phép đọc register kiểu pipeline cũ', 'alu_op':'chọn phép ALU kiểu cũ', 'mem_wren':'cho phép memory write kiểu cũ',
 'mem_rden_0':'cho phép memory read0 kiểu cũ', 'mem_rden_1':'cho phép memory read1 kiểu cũ', 'wb_sel':'chọn nguồn write-back kiểu cũ', 'unsupported':'opcode không hỗ trợ bởi decoder legacy',
 'enable':'cho phép pipeline register nhận input', 'flush':'xóa payload/control của pipeline register', 'flush_younger':'yêu cầu flush các instruction trẻ trong control legacy',
})

COMMENTS = {
 'Board wrapper:':'Wrapper board: ba LED lần lượt báo ready, overflow và error.',
 'The host must':'Host phải nạp SRAM, descriptor và chương trình kết thúc bằng HALT trước khi start.',
 'Compute-side parameter':'Cổng compute của parameter SRAM có1024word256bit, tổng32KiB.',
 'Compute-side 256':'Cổng compute của workspace truyền nguyên word256bit.',
 '32-bit host port':'Host truyền32bit; host_addr của parameter wrapper là chỉ số word32 từ0 đến8191.',
 '32-bit host/debug':'Host/debug truyền32bit; host_addr của workspace wrapper là chỉ số word32 từ0 đến2047.',
 'Shared implementation':'Hai wrapper dùng chung implementation để packing host và latency read nhất quán.',
 'Simple 32-bit':'Giao diện host đơn giản32bit, không tự có giao thức AXI/APB.',
 'Runtime q scales':'Scale động q gắn với descriptor cùng đúng vùng memory và length của tensor.',
 'NORM-generated q':'q do NORM sinh phải dùng D/scale động của chính vector đó khi TMATMUL.',
 'Small sequential':'Divider unsigned tuần tự cho các phép scalar nội bộ.',
 'Signed operations':'Nếu cần phép chia signed, caller phải xử lý magnitude/sign ở ngoài divider unsigned.',
 'EXP is not':'EXP không được triển khai; greedy argmax không bắt buộc tính softmax ở đầu ra.',
 'Drive zero':'Stub trả0 để kết quả xác định nếu module legacy bị instantiate; không phải exp thật.',
 'Full-vector integer':'RMSNorm integer trên toàn vector, tiếp theo là activation quantization.',
 'X: S16':'Input S16 theo scale tensor; scratch z S24/F16 được sign-extend trong ô S32.',
 'q: S8':'Output q S8 dùng RNE và clamp vào raw signed 0x80…0x7F (−128…127); K hợp lệ 1…512.',
 'scalar divider shared':'Một divider trong norm được tái sử dụng cho mean-square và sinh các hệ số; scale_compose vẫn có instance khác.',
 'Dynamic coefficient':'Chọn r lớn để tăng precision trong giới hạn M unsigned24bit.',
 'Behavioral memory':'Ranh giới memory behavioral dành cho việc thay bằng adapter SRAM của foundry.',
 'Compute reads retain':'Giữ hợp đồng request/response read hiện tại; xem timing ở phần tổng quan khối.',
 'Host reads are':'Host read ở model này là asynchronous; macro synchronous cần host bridge.',
 'One masked write':'Một write port có mask; top arbitration bảo đảm client không truy cập chồng nhau.',
 'Memory data has':'Không reset asynchronous, không clear loop và không khởi tạo nội dung array SRAM.',
 'Compose postscale':'Ghép scale postscale từ scale NORM+QUANT thay đổi theo tensor.',
 'C = factor':'Hệ số hiệu dụng bằng factor_m×D chia cho127×65536×2^factor_r.',
 'Find the largest':'Chọn r lớn nhất không quá47 sao cho hệ số sau RNE vừa U24; hoàn toàn không dùng floating-point.',
 'MUL and REC':'MUL và REC dùng chung hai toán tử nhân unsigned16×16 trong rowwise datapath; số cell vật lý cần synthesis xác nhận.',
 'Sign correction':'Nhân magnitude rồi khôi phục sign, giữ đúng gate raw 0x8000 tương ứng 1.',
 'Operand isolation':'Đưa operand multiplier về0 khi ADD/SIG hoặc idle, giảm switching không cần thiết.',
 'Generated together':'ROM function và file hex được tạo cùng bộ mẫu; ROM mặc định không phụ thuộc working directory.',
 'A single ROM':'Một lookup ROM cấp y0 rồi y1 ở hai cycle kế tiếp.',
 'ASIC synthesis sees':'Nhánh synthesis dùng case table hằng, không dựa vào initialized RAM.',
 'All S16 inputs':'Fraction24bit đủ biểu diễn chính xác tọa độ lưới của input S16 với F_t0…24; sai số còn đến từ bảng và nội suy.',
 'RNE applies':'RNE áp dụng toàn tổng nội suy, gồm parity phần nguyên y0 khi nằm đúng điểm tie.',
 'Workspace descriptor.':'Length của descriptor đếm phần tử tensor, không đếm SRAM word.',
 'Ternary matrix descriptor.':'Mỗi hàng output/weight bắt đầu trên ranh giới word256bit trong layout ma trận.',
 'Weight rows':'Một hàng weight chiếm ceil(K/128)word; bias S32 pack8giá trị/word.',
 'Round-to-nearest-even':'Hàm dịch phải có làm tròn nearest-even cho số signed.',
 'shift=0':'Shift0 trả nguyên x. Caller chính dùng shift không quá47.',
 'Shift is positive':'Shift dương chia lũy thừa2; shift âm nhân lũy thừa2.',
 'Callers constrain':'Caller giới hạn left shift≤24 và operand không quá33bit signed để giữ kết quả trong S64.',
}

def prose(s):
    # Do not run on source/code cells. Preserve identifiers and numeric formats.
    s=re.sub(r'(\d)(bit|byte|word|cycle|lane|term|giá trị|phần tử|mẫu|KiB|clock)\b',r'\1 \2',s)
    s=re.sub(r'\b(word|gate|lane|output|signed|unsigned|magnitude|remainder|quotient|chunk|input|raw|mask|data|format|bit|depth)(?=\d)',r'\1 ',s)
    s=re.sub(r'\b(có|và|với|phải|thành|từ|đến|về|lên|bằng|hơn|quá|nhỏ hơn|lớn hơn|dưới|trên|tổng|phép|lấy|đưa|gán|cộng|thừa|cần|nguyên|đủ|số|địa chỉ|khác|cho|ngoài|đa|trả|chọn|yêu cầu|chứa|trong|trước|sau)(?=[0-9−])',r'\1 ',s)
    s=re.sub(r'\b(padding|raw|pack|shift|bit|ceil\(K/128\))(?=\d)',r'\1 ',s)
    s=s.replace('format2','format 2').replace('format0','format 0').replace('format1','format 1').replace('format3','format 3')
    s=s.replace('. .','.')
    s=re.sub(r'\b(output|input|nguồn|đích|format|gate|yêu cầu)(?=[SUF]\d)',r'\1 ',s)
    return s

def read_source(path):
    raw = path.read_bytes()
    try: return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return raw.decode('gb18030', errors='replace')

def label(name):
    base=re.match(r'[A-Za-z_]\w*',name.strip())
    if not base: return ''
    key=base.group()
    if key in SIGNALS: return SIGNALS[key]
    for suffix,meaning in [('_start','yêu cầu bắt đầu'),('_done','xung hoàn tất'),('_busy','trạng thái đang xử lý'),('_error','cờ lỗi'),('_ov','cờ overflow'),('_rd_en','request đọc'),('_wr_en','cho phép ghi'),('_rd_addr','địa chỉ đọc'),('_wr_addr','địa chỉ ghi'),('_wr_data','data cần ghi')]:
        if key.endswith(suffix): return meaning+' của '+key[:-len(suffix)]
    return ''

UNHANDLED=[]

def explain(line, name, number, comment_state):
    s=line.strip()
    if not s: return 'Dòng trống, phân tách các phần để dễ đọc; không tạo logic.'
    if comment_state:
        return 'Nội dung trong block comment; không được compiler thực thi.'
    if s.startswith('//') or s.startswith('/*') or s=='*/':
        comment=s.removeprefix('//').strip()
        for prefix,meaning in COMMENTS.items():
            if comment.startswith(prefix): return 'Comment: '+meaning
        if comment.startswith('---'): return 'Tiêu đề phân đoạn: '+comment.strip('- ').strip()+'. Không tạo logic.'
        return 'Comment mô tả ý định của đoạn bên dưới; không tạo phần cứng. Xem phần giải thích của nhóm dòng này để đọc bằng tiếng Việt.'
    code=re.sub(r'//.*','',s).strip()
    for prefix,desc in SPECIAL.items():
        if code.startswith(prefix): return desc
    if code.startswith('`include'): return 'Chèn định nghĩa function ROM từ sigmoid_lut.svh khi biên dịch; đây là source hằng, không phải đọc file khi chip chạy.'
    if code.startswith('`ifdef SYNTHESIS'): return 'Bắt đầu nhánh dành cho synthesis: dùng ROM hằng, không dùng kiểm tra/load file simulation.'
    if code.startswith('`ifndef SYNTHESIS'): return 'Chỉ biên dịch đoạn sau khi không định nghĩa SYNTHESIS; dùng cho assertion simulation.'
    if code.startswith('`else'): return 'Nhánh biên dịch còn lại khi không chọn nhánh preprocessor phía trên.'
    if code.startswith('`endif'): return 'Kết thúc lựa chọn nhánh lúc biên dịch; không phải một state runtime.'
    if code.startswith('module '): return 'Bắt đầu module phần cứng '+code.split()[1].split('(')[0]+'. Port và parameter tiếp theo xác định giao diện khối.'
    if code.startswith('package '): return 'Bắt đầu package chứa hằng số, kiểu dữ liệu và function dùng chung; bản thân package không là execution unit có clock.'
    if code=='endmodule': return 'Kết thúc định nghĩa module này.'
    if code=='endpackage': return 'Kết thúc package dùng chung.'
    if code=='endfunction': return 'Kết thúc function; giá trị trả được gán vào tên function trong thân hàm.'
    if code.startswith('import '): return 'Đưa các kiểu descriptor và hàm số học của npu_pkg vào phạm vi sử dụng của module.'
    if code.startswith('function '):
        m=re.search(r'(\w+)\s*\(',code); return 'Khai báo function '+(m.group(1) if m else '')+'; automatic tạo biến cục bộ riêng cho mỗi lần sử dụng.'
    if code.startswith('typedef enum'): return 'Khai báo enum có độ rộng bit tường minh; các tên sau là mã format hoặc state, không phải các module riêng.'
    if code.startswith('typedef struct'): return 'Bắt đầu struct packed; các trường phía trên nằm ở các bit cao hơn khi ghép thành descriptor.'
    if code.startswith('}'):
        return 'Đóng định nghĩa enum/struct và đặt tên kiểu để các khối khác dùng đúng layout.'
    if code.startswith(('parameter ','localparam ')):
        return 'Định nghĩa hằng số lúc elaboration: '+code.rstrip(';,.')+'. Giá trị này không thay đổi bằng instruction runtime.'
    if re.match(r'(input|output|inout)\b',code):
        direction=re.match(r'(input|output|inout)',code).group()
        ids=re.findall(r'\b[A-Za-z_]\w*\b',code)
        meaningful=[(x,SIGNALS[x]) for x in ids if x in SIGNALS]
        descr='; '.join(dict.fromkeys(f'{x}: {v}' for x,v in meaningful))
        width=re.search(r'\[[^]]+\]',code)
        return 'Khai báo '+{'input':'cổng vào','output':'cổng ra','inout':'cổng hai chiều'}[direction]+(' với khoảng bit '+width.group() if width else '')+'.'+(' '+descr+'.' if descr else '')
    if re.match(r'(logic|reg|wire|integer|int|ws_desc_t|mat_desc_t|state_t|sched_t|tensor_fmt_t)\b',code) and not re.match(r'int\s*\(',code):
        ids=re.findall(r'\b[A-Za-z_]\w*\b',code)
        meaningful=[(x,SIGNALS[x]) for x in ids if x in SIGNALS]
        descr='; '.join(dict.fromkeys(f'{x}: {v}' for x,v in meaningful))
        width=re.search(r'\[[^]]+\]',code)
        return 'Khai báo tín hiệu/biến nội bộ'+(' có khoảng bit '+width.group() if width else '')+'. '+(descr+'.' if descr else 'Tên và kiểu ở cột code xác định dữ liệu được dùng trong nhóm xử lý này; khai báo logic riêng chưa quyết định là flip-flop hay logic tổ hợp.')
    if code.startswith('always_comb'): return 'Bắt đầu logic tổ hợp; kết quả được tính lại từ input hiện tại. Cần gán đủ các nhánh cho từng đầu ra để tránh latch.' if code=='always_comb begin' else 'Logic tổ hợp trả giá trị hằng0 cho stub EXP; không tính exponential.'
    if code.startswith(('always_ff','always@','always @')):
        return 'Bắt đầu xử lý theo cạnh clock'+('; có reset asynchronous tại cạnh '+('xuống rst_n' if 'negedge' in code else 'lên rst') if 'edge rst' in code else '')+'. Các phép <= chốt đồng thời, vế phải đọc giá trị trước cạnh.'
    if code.startswith('initial'): return 'Khối chạy một lần lúc simulation bắt đầu để kiểm tra và nạp file LUT; không có trong nhánh synthesis này.'
    if code in ['generate','endgenerate']: return ('Bắt đầu' if code=='generate' else 'Kết thúc')+' lựa chọn cấu trúc phần cứng theo parameter, không phải vòng lặp runtime.'
    if code.startswith('case'):
        return 'Chọn nhánh theo '+code[code.find('(')+1:code.rfind(')')]+'; mỗi nhánh mô tả operation/state hoặc lựa chọn dữ liệu tương ứng.'
    if code=='endcase': return 'Kết thúc các nhánh case; default phía trên xử lý lựa chọn không khớp nếu có.'
    if code=='else': return 'Nhánh thay thế khi điều kiện if ngay trước không đúng.'
    if re.fullmatch(r'end\s*;?',code): return 'Đóng phạm vi begin gần nhất; quay về mức điều kiện/vòng lặp bên ngoài.'
    if code=='begin': return 'Mở nhóm câu lệnh của điều kiện, state hoặc process ngay phía trên.'
    if code.startswith('begin :'): return 'Mở scope có tên để nhóm biến/cấu trúc; tên scope giúp tìm đúng hierarchy khi debug.'
    if code in [');',') (','(',')','#(']: return 'Dấu phân cách/đóng danh sách parameter, port hoặc lời gọi instance; không tự tạo phép tính.'
    if code.startswith('for ') or code.startswith('for('):
        return 'Vòng for duyệt chỉ số trong giới hạn ghi ở code. Trong process tổ hợp/reset, các iteration thuộc cùng lần đánh giá; không mặc định mất một clock cho mỗi iteration.'
    if code.startswith('while '): return 'Duyệt file LUT đến EOF trong simulation; vòng này kiểm tra nội dung file, không là datapath inference.'
    if code.startswith(('$fclose','$readmemh','$fatal','$error')):
        return {'$fclose':'Đóng handle file LUT sau kiểm tra.', '$readmemh':'Nạp các mẫu hex vào array simulation; chỉ chạy sau khi file đã được xác thực.', '$fatal':'Dừng simulation khi LUT thiếu/sai/không đúng kích thước; tránh dùng bảng không hợp lệ.', '$error':'Báo vi phạm hợp đồng host/compute trong simulation.'}[next(x for x in ['$fclose','$readmemh','$fatal','$error'] if code.startswith(x))]
    if code.startswith('.'):
        ports=re.findall(r'\.(\w+)\(([^()]*(?:\([^()]*\)[^()]*)*)\)',code)
        if ports: return 'Nối '+ '; '.join(f'port {p} với {v}'+(' — '+label(p) if label(p) else '') for p,v in ports)+'.'
        return 'Tiếp tục kết nối named port/parameter của instance; biểu thức ở cột code xác định nguồn dữ liệu cho cổng đó.'
    # Named module instance, including parameterized multi-line declarations.
    if re.match(r'\w+\s+(?:#\(|u_\w+\()',code):
        return 'Instantiate '+code.split()[0]+' trong hierarchy, với parameter/port nối ở các dòng tiếp theo. Instance này mới làm module con trở thành một phần của khối.'
    if code.startswith(') u_'): return 'Kết thúc parameter override và bắt đầu named-port connections của instance.'
    # Meaning for assignments, including multiple statements on compact legacy lines.
    assignment_code=code
    # Remove if-condition parentheses so <= comparisons are never described as assignments.
    while (cm:=re.search(r'\bif\s*\(',assignment_code)):
        j=cm.end(); depth=1
        while j<len(assignment_code) and depth:
            if assignment_code[j]=='(': depth+=1
            if assignment_code[j]==')': depth-=1
            j+=1
        if depth: assignment_code=assignment_code[:cm.start()]; break
        assignment_code=assignment_code[:cm.start()]+' '+assignment_code[j:]
    assignments=re.findall(r'([A-Za-z_]\w*(?:\[[^;]*?\])?(?:\.\w+)?)\s*(<=|=(?!=))\s*([^;]+);',assignment_code)
    if assignments:
        clauses=[]
        for lhs,op,rhs in assignments:
            meaning=label(lhs)
            target=lhs+(' ('+meaning+')' if meaning else '')
            rhs=rhs.strip()
            if rhs in ["0","'0","1'b0","16'd0","9'd0"]: desc=('Chốt ' if op=='<=' else 'Đặt ')+target+' về0'
            elif rhs in ['1',"1'b1"]: desc=('Chốt ' if op=='<=' else 'Đặt ')+target+' lên1'
            elif lhs in ['state','sched']: desc='Chuyển FSM sang '+rhs+' ở cạnh clock'
            elif label(rhs): desc=('Chốt ' if op=='<=' else 'Lấy ')+target+' từ '+rhs+' ('+label(rhs)+')'
            else: desc=('Chốt ' if op=='<=' else 'Tính ')+target+' theo '+rhs
            if 'sat_s16' in rhs or 'sat_s32' in rhs: desc+='; clamp về miền output trước khi lấy bit thấp'
            if 'rne_shift64' in rhs: desc+='; chia lũy thừa2 và làm tròn ties-to-even'
            clauses.append(desc)
        condition=re.search(r'\b(?:else\s+)?if\s*\(',code)
        prefix=''
        if condition:
            begin=condition.end(); depth=1; j=begin
            while j<len(code) and depth:
                if code[j]=='(': depth+=1
                if code[j]==')': depth-=1
                j+=1
            cond=code[begin:j-1]
            prefix='Khi '+cond+': '
        elif re.match(r'\w+\s*:',code): prefix='Nhánh '+code.split(':',1)[0]+': '
        return prefix+'; '.join(clauses)+'.'
    if code.startswith(('if ','if(','else if','end else if','else begin','end else begin')):
        if '!rst_n' in code or 'if(rst)' in code: return 'Nhánh reset: các dòng trong nhánh đưa control/buffer về giá trị khởi tạo; ưu tiên trước xử lý giao dịch.'
        if 'start' in code and ('!busy' in code or code.endswith('if (start) begin')): return 'Nhận giao dịch mới khi có start và khối đang rảnh; chốt operand/metadata trước khi xử lý nhiều cycle.'
        if 'ws_rd_valid' in code or 'param_rd_valid' in code: return 'Chỉ nhận dữ liệu khi SRAM báo valid; các dòng trong nhánh sẽ chốt word và tiến FSM.'
        if 'done' in code: return 'Chờ module con báo hoàn tất rồi mới dùng kết quả và chuyển bước.'
        if '$fatal' in code: return 'Kiểm tra điều kiện lỗi file LUT ghi trong code; nếu vi phạm thì dừng simulation ngay.'
        if code in ['else begin','end else begin']: return 'Nhánh còn lại khi điều kiện phía trên không đúng; các thao tác sau chỉ áp dụng trong nhánh này.'
        return 'Kiểm tra điều kiện '+code.removeprefix('end ').removesuffix('begin').strip()+'. Chỉ thực hiện nhóm câu lệnh tiếp theo khi điều kiện nhánh đúng.'
    if re.match(r'(?:[A-Za-z_]\w*|\d+\x27[bdh][0-9a-f]+|\d+)(?:\s*,\s*\w+)*\s*:',code):
        if ': ;' in code: return 'Nhánh '+code.split(':')[0]+' không cập nhật thêm; giữ default tổ hợp hoặc giữ register tùy process.'
        return 'Nhánh '+code.split(':')[0]+' của case; các dòng sau mô tả hành vi riêng của lựa chọn này.'
    if code.startswith('else '): return 'Nhánh thay thế khi điều kiện ngay trước không đúng; tiếp tục biểu thức/thao tác ghi trong code.'
    if code.startswith(('FMT_','P1_','P2_','P3_','DIV_','SQRT_','CNORM_','CQUANT_','FINISH','IDLE,','S_COMPOSE')) and '=' not in code:
        return 'Tiếp tục danh sách tên state/format của enum; thứ tự enum quyết định mã nội bộ nếu không gán tường minh.'
    if code.startswith(('||','&&','(', 'int\'','ranges_overlap','src_desc.','a_desc.','b_desc.','dst_desc.','out_desc.','mat_desc.','q_desc.','q_length','q_base','!','(host_')):
        return 'Tiếp tục điều kiện/biểu thức nhiều dòng phía trên: thêm ràng buộc đúng như code; chỉ khi toàn biểu thức hợp lệ mới chấp nhận giao dịch.'
    if code.endswith((',',');',';')):
        UNHANDLED.append((name,number,code))
        return 'Phần tiếp theo của khai báo hoặc biểu thức nhiều dòng ngay phía trên. Đọc liền với dòng trước và phần giải thích nhóm để giữ đúng thứ tự toán tử.'
    UNHANDLED.append((name,number,code))
    return 'Tiếp tục cấu trúc/biểu thức đang mở ở dòng trước; ngữ nghĩa thuộc cùng nhóm xử lý đã giải thích phía trên.'

def cell(s):
    return html.escape(s,quote=False).replace('|','&#124;').replace('\n',' ')

def group_logic_description(code):
    kinds=[]
    if 'always_ff' in code or re.search(r'always\s*@\s*\(.*edge',code):
        kinds.append('Có logic tuần tự: register/FSM chỉ cập nhật tại cạnh clock; nonblocking assignment đọc giá trị cũ ở vế phải rồi chốt đồng thời.')
    if 'always_comb' in code:
        kinds.append('Có logic tổ hợp: output/intermediate được tính từ input hiện tại; các giá trị mặc định đầu khối giúp tránh suy ra latch.')
    if re.search(r'^\s*assign\s',code,re.M):
        kinds.append('Có continuous assignment: biểu thức luôn lái tín hiệu đích, không cần start hoặc cạnh clock.')
    if re.search(r'\bfunction\s+automatic\b',code):
        kinds.append('Có function tổ hợp dùng lại tại nơi gọi; function không giữ trạng thái qua các chu kỳ.')
    if re.search(r'^\s*(?:\w+\s+)?u_\w+\s*\(',code,re.M) or re.search(r'\)\s+u_\w+\s*\(',code):
        kinds.append('Có instance module con; named-port ở nhóm này xác định chính xác đường control/data giữa hai cấp hierarchy.')
    if not kinds:
        if re.search(r'^\s*(?:input|output|logic|reg|wire|parameter|localparam|typedef|module|package)\b',code,re.M):
            kinds.append('Nhóm này định nghĩa giao diện, độ rộng, kiểu hoặc tín hiệu trung gian. Nó tạo cấu trúc để các nhóm xử lý sau sử dụng, chưa tự biểu diễn một bước runtime riêng.')
        else:
            kinds.append('Các câu lệnh thuộc cùng một nhánh/pha xử lý và phải được đọc liền nhau; tách riêng từng dòng sẽ làm mất quan hệ điều kiện và dữ liệu.')
    return ' '.join(kinds)

def group_signal_description(code):
    # Chỉ tìm identifier trong code thực. Nếu quét cả comment, các từ mô tả
    # như "sign" hoặc "q" có thể bị nhầm thành tín hiệu của block.
    cleaned=re.sub(r'/\*.*?\*/','',code,flags=re.S)
    cleaned=re.sub(r'//.*','',cleaned)
    found=[]
    for match in re.finditer(r'\b[A-Za-z_]\w*\b',cleaned):
        name=match.group()
        if name in SIGNALS and name not in found and name not in ['clk','rst_n','i']:
            found.append(name)
    if not found:
        return ''
    chosen=found[:6]
    text='; '.join(f'`{name}`: {SIGNALS[name]}' for name in chosen)
    if len(found)>len(chosen): text+=f'; và {len(found)-len(chosen)} tín hiệu phụ khác trong đoạn code.'
    else: text+='.'
    return text

def render_block(name, meta):
    p=SRC/name; content=read_source(p); lines=content.splitlines()
    text=[f'# {name} — {meta["title"]}', '', '[Về mục lục](README.md) · [Về tổng quan](../README.md)', '',
          f'**Trạng thái:** {meta["status"]}.', '',
          f'**Source:** [{name}](<{p.as_posix()}>). **Số dòng:** {len(lines)}. **SHA-256:** `{hashlib.sha256(p.read_bytes()).hexdigest()}`.', '',
          '## Khối này làm gì?', '', prose(meta['overview']), '',
          '## Sơ đồ kiến trúc tổng quan', '', '```mermaid', DIAGRAMS[name], '```', '',
          LEGEND + (' ' + CAPTIONS[name] if name in CAPTIONS else ''), '',
          '## Cách hoạt động chi tiết', '', prose(meta['flow']), '', prose(DETAILS[name]), '',
          '## Các nhóm logic trong source', '',
          'Source được chia theo chức năng. Mỗi nhóm giữ nguyên phạm vi dòng để đối chiếu, nhưng phần giải thích tập trung vào quan hệ giữa các câu lệnh thay vì lặp lại từng dấu ngoặc, khai báo hoặc phép gán.', '']
    rows=0
    for start,end,title,desc in meta['sections']:
        end=min(end,len(lines))
        source='\n'.join(lines[start-1:end])
        key=(name,start)
        text.extend(['',f'### [Dòng {start}–{end}: {title}](<{p.as_posix()}:{start}>)','',
                     f'<!-- source-range:{start}:{end} -->','```systemverilog',source,'```','',
                     '**Mục đích.** '+prose(desc),'',
                     '**Cách phần code hoạt động.** '+group_logic_description(source),''])
        signals=group_signal_description(source)
        if signals:
            text.extend(['**Tín hiệu và dữ liệu chính.** '+prose(signals),''])
        if key in GROUP_NOTES:
            text.extend(['**Điểm cần đọc kỹ.** '+prose(GROUP_NOTES[key]),''])
        if key in SECTION_DIAGRAMS:
            text.extend(['#### Sơ đồ khối phần cứng của nhóm','', '```mermaid',SECTION_DIAGRAMS[key],'```',''])
        rows+=end-start+1
    (BLOCKDIR/(name+'.md')).write_text('\n'.join(text)+'\n',encoding='utf-8')
    return rows,len(meta['sections'])

def render_lut(name):
    p=SRC/name; lines=read_source(p).splitlines(); active=name!='sigContent.mif'
    title='ROM sigmoid hằng trong RTL' if name.endswith('.svh') else ('Bản hex của ROM sigmoid mới' if active else 'Dữ liệu LUT sigmoid lịch sử')
    text=[f'# {name} — {title}','','[Về mục lục](README.md) · [Về tổng quan](../README.md)','',
          f'**Source:** [{name}](<{p.as_posix()}>). **SHA-256:** `{hashlib.sha256(p.read_bytes()).hexdigest()}`.','',
          '## Cách sử dụng','',
          ('Cùng 257 mẫu tại x=−8+i/16, raw=RNE(0x8000/(1+exp(−x))). Raw lưu 16 bit và có scale 2^−15. Công thức exp chỉ dùng lúc tạo bảng. ROM mới không dùng sigContent.mif. Mỗi dòng dữ liệu bên dưới được giải thích bằng index, tọa độ x và giá trị gate thực.' if active else 'File lịch sử có 1024 dòng binary 16 bit, không có header MIF dạng WIDTH/DEPTH/CONTENT. Tên đuôi .mif không làm nó trở thành file Intel MIF có header. Top mới không đọc file này. Bảng dưới giải mã raw từng dòng; không tự gán x hoặc F_t vì riêng data file không chứa address mapping/scale.'), '',
          '| Dòng | Code/dữ liệu gốc | Giải thích |','|---:|---|---|']
    for i,line in enumerate(lines,1):
        s=line.strip()
        if name.endswith('.svh'):
            m=re.match(r"(\d+): sigmoid_sample = 16'h([0-9a-fA-F]+);",s)
            if m:
                idx=int(m[1]); value=int(m[2],16)
                desc=f'Địa chỉ {idx}: x={-8+idx/16:g}; trả raw=0x{value:04X} ({value}), gate={value/32768:.8f}.'
            elif s.startswith('default'): desc='Địa chỉ ngoài 0x000…0x100 trả mẫu fallback của function; FSM sigmoid hợp lệ giới hạn chỉ số trong miền bảng.'
            else: desc=explain(line,name,i,False)
        elif active:
            value=int(s,16); idx=i-1
            desc=f'Mẫu {idx}: x={-8+idx/16:g}; hex {s} là raw unsigned 0x{value:04X} ({value}), tương đương gate {value/32768:.8f}. Simulation đối chiếu với function ROM trước khi load.'
        else:
            value=int(s,2)
            desc=f'Entry lịch sử {i-1}: binary16bit, raw unsigned={value}. Không nằm trong đường sigmoid v2; cần consumer lịch sử để diễn giải scale/tọa độ.'
        text.append(f'| [{i}](<{p.as_posix()}:{i}>) | <code>{cell(line)}</code> | {cell(prose(desc))} |')
    (BLOCKDIR/(name+'.md')).write_text('\n'.join(text)+'\n',encoding='utf-8')
    return len(lines)

def main():
    manifest=[]; index=['# Mục lục giải thích từng file','','[Về tài liệu tổng quan](../README.md)','','Mỗi trang gồm vai trò, sơ đồ kiến trúc tổng quan, phần giải thích hoạt động và source được gom theo nhóm logic. Hình cạnh các nhóm code cũng mô tả khối phần cứng và kết nối, không mô tả FSM, timing hay pipeline CPU. Package được trình bày như quan hệ định nghĩa RTL; legacy/helper có sơ đồ độc lập và không thuộc hierarchy NPU hiện tại.','','| File | Vai trò | Trạng thái | Nhóm logic | Số dòng |','|---|---|---|---:|---:|']
    sources=sorted(p.name for p in SRC.iterdir() if p.suffix.lower() in ['.sv','.v'])
    assert set(sources)==set(BLOCKS), (set(sources)-set(BLOCKS),set(BLOCKS)-set(sources))
    for name,meta in BLOCKS.items():
        rows,groups=render_block(name,meta); p=SRC/name
        index.append(f'| [{name}]({name}.md) | {meta["title"]} | {meta["status"]} | {groups} | {rows} |')
        manifest.append(dict(file=name,path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),lines=rows,groups=groups,document='blocks/'+name+'.md'))
    for name in ['sigmoid_lut.svh','sigmoid_257.mem','sigContent.mif']:
        rows=render_lut(name); p=SRC/name
        index.append(f'| [{name}]({name}.md) | LUT — giải thích mỗi entry | '+('Legacy' if name=='sigContent.mif' else 'Đang dùng / bản đối chiếu simulation')+f' | — | {rows} |')
        manifest.append(dict(file=name,path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),lines=rows,document='blocks/'+name+'.md'))
    index+=['','## Các file không phải source đang chạy','','`norm.sv.bak` và `norm_dispatch.sv.bak` là backup; không đưa vào danh sách active source và không dùng để suy luận datapath. README của source là tài liệu cấu hình, đã được đối chiếu trong trang tổng quan. Testbench/generator thuộc verification, không phải block trong NPU.','']
    (BLOCKDIR/'README.md').write_text('\n'.join(index),encoding='utf-8')
    (OUT/'source_manifest.json').write_text(json.dumps({'snapshot_date':'2026-09-29','files':manifest},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (ROOT/'review/npu_explanation/unhandled.json').write_text(json.dumps(UNHANDLED,ensure_ascii=False,indent=2),encoding='utf-8')
    overview_page=OUT/'README.md'
    if overview_page.exists():
        overview_text,count=re.subn(r'```mermaid\n.*?\n```',lambda _: '```mermaid\n'+OVERVIEW+'\n```',overview_page.read_text(encoding='utf-8'),flags=re.S)
        assert count==1, 'Expected one root architecture overview'
        overview_page.write_text(overview_text,encoding='utf-8')
    print(json.dumps({'files':len(manifest),'source_lines':sum(f['lines'] for f in manifest),'fallback_lines':len(UNHANDLED)},ensure_ascii=False))

if __name__=='__main__': main()
