const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { chromium } = require('C:/Users/khanh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = path.resolve(__dirname, '../..');
const docs = path.join(root, 'research/npu_explained');
const out = path.join(__dirname, 'diagram_qa');
const files = [path.join(docs, 'README.md'), ...fs.readdirSync(path.join(docs, 'blocks')).filter(n => n.endsWith('.md')).map(n => path.join(docs, 'blocks', n))];
const diagrams = [];
for (const file of files) {
  let ordinal = 0;
  for (const match of fs.readFileSync(file, 'utf8').matchAll(/```mermaid\r?\n([\s\S]*?)\r?\n```/g)) {
    diagrams.push({ file: path.relative(docs, file).replaceAll('\\', '/'), ordinal: ordinal++, code: match[1] });
  }
}

(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 }, deviceScaleFactor: 1 });
  await page.setContent('<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;background:white;font-family:Arial,sans-serif}#diagram{display:inline-block;padding:20px}svg{max-width:none!important}</style></head><body><div id="diagram"></div></body></html>');
  await page.addScriptTag({ path: path.join(out, 'mermaid.min.js') });
  await page.evaluate(() => mermaid.initialize({ startOnLoad: false, securityLevel: 'strict', theme: 'neutral', fontFamily: 'Arial, sans-serif', flowchart: { htmlLabels: true, useMaxWidth: false, nodeSpacing: 28, rankSpacing: 35, curve: 'linear' }, themeVariables: { fontSize: '16px' } }));
  const results = [];
  for (let i = 0; i < diagrams.length; i++) {
    const d = diagrams[i];
    const key = String(i).padStart(2, '0') + '-' + path.basename(d.file, '.md') + '-' + d.ordinal;
    try {
      const result = await page.evaluate(async ({ code, key }) => {
        await mermaid.parse(code);
        const rendered = await mermaid.render('g' + key.replaceAll(/[^a-zA-Z0-9]/g, ''), code);
        document.getElementById('diagram').innerHTML = rendered.svg;
        const svg = document.querySelector('#diagram svg');
        const b = svg.viewBox.baseVal;
        svg.style.width = Math.ceil(b.width) + 'px';
        svg.style.height = Math.ceil(b.height) + 'px';
        return { svg: rendered.svg, width: Math.ceil(b.width), height: Math.ceil(b.height), nodes: svg.querySelectorAll('.node').length };
      }, { code: d.code, key });
      fs.writeFileSync(path.join(out, key + '.svg'), result.svg);
      await page.locator('#diagram').screenshot({ path: path.join(out, key + '.png'), timeout: 15000 });
      results.push({ file: d.file, ordinal: d.ordinal, key, source_sha256: crypto.createHash('sha256').update(d.code.replaceAll('\r\n', '\n')).digest('hex'), width: result.width, height: result.height, nodes: result.nodes, status: 'rendered' });
    } catch (error) {
      results.push({ file: d.file, ordinal: d.ordinal, key, status: 'failed', error: String(error) });
    }
  }
  await browser.close();
  fs.writeFileSync(path.join(out, 'render_validation.json'), JSON.stringify({ mermaid_version: '11.12.0', diagrams: results }, null, 2));
  console.log(JSON.stringify({ total: results.length, rendered: results.filter(r => r.status === 'rendered').length, failures: results.filter(r => r.status === 'failed'), largest: [...results].filter(r => r.width).sort((a,b) => b.width - a.width).slice(0,5) }));
  process.exitCode = results.some(r => r.status === 'failed') ? 1 : 0;
})().catch(e => { console.error(e); process.exitCode = 1; });
