"""RTL-grounded architecture views; arrows are connections, never time steps."""
import re

LEGEND = ('MUX dùng hình thang rộng ở phía nhiều ngõ vào và thu hẹp về ngõ ra; '
          'decoder/demux dùng hình thang ngược lại, mở rộng về phía nhiều ngõ ra. '
          'Hình chữ nhật có các vạch ngang biểu diễn '
          'bộ nhớ hoặc bank descriptor. Các hình chữ nhật thường là datapath, thanh ghi đơn '
          'hoặc giao diện. Nét liền là đường dữ liệu, nét đứt là điều khiển/cấu hình. '
          'Mũi tên hồi tiếp biểu diễn kết nối phần cứng. '
          'Sơ đồ không biểu diễn thứ tự chu kỳ, trạng thái FSM hoặc các tầng pipeline CPU.')

OVERVIEW = '''flowchart TB
    HOST["Host 32 bit"]
    subgraph NPU["NPU — matmulfree.sv"]
        IF["Host interface<br/>Address decoder + control/status"]
        subgraph CTRL["Điều khiển và cấu hình"]
            PC["PC.sv<br/>Program counter 9 bit"]
            IM["ins_mem.sv<br/>Instruction memory 512 × 13 bit"]
            SCH["Scheduler single-issue<br/>Opcode decode + điều phối engine"]
            DESC["descriptor_file.sv<br/>8 workspace × 32 bit<br/>8 matrix × 96 bit"]
            SCALE["Runtime q metadata + effective_mat<br/>scale_compose.sv + div 64/64<br/>Scale tĩnh hoặc ghép scale động"]
        end
        subgraph ENG["Các engine tính toán"]
            ROW["Row-wise vector engine<br/>rowwise_dispatch + rowwise_op<br/>ADD / SUB / MUL / REC / RELU<br/>sigmoid: ROM + nội suy"]
            NORM["NORM + QUANT engine<br/>norm_dispatch + norm<br/>isqrt_u64 + div 64/32<br/>S16 → scratch S24/F16 → S8"]
            TM["Ternary matmul engine<br/>ternary_mul · 32 lane chọn dấu/zero<br/>acc_mul + accumulator S18<br/>postscale + bias → S16/S32"]
        end
        REQMUX["Workspace request mux<br/>Chọn request/write theo active_unit"]
        RSPDEC["Workspace response demux<br/>Phân phối read data/valid tới active engine"]
        WS["Workspace SRAM 8 KiB<br/>regfile.sv: register<br/>sram_256_wrapper ADDR_W=8<br/>256 × 256 bit"]
        PM["Parameter SRAM 32 KiB<br/>mem_mapping.sv<br/>sram_256_wrapper ADDR_W=10<br/>1024 × 256 bit · weight + bias"]
        IF <-->|"Nạp/đọc chương trình, descriptor, control/status"| CTRL
        IF <-->|"Host 32 bit"| WS
        IF <-->|"Host 32 bit"| PM
        PC -->|"Address"| IM
        IM -->|"Instruction"| SCH
        SCH -.->|"clear / advance"| PC
        SCH -.->|"Descriptor IDs"| DESC
        DESC -.->|"Tensor metadata"| ENG
        DESC -.->|"Matrix descriptor"| SCALE
        SCH -.->|"start / opcode"| ENG
        ENG -.->|"done / error / overflow"| SCH
        SCH -.->|"active_unit"| REQMUX
        SCH -.->|"active_unit"| RSPDEC
        SCH -.->|"Compose control"| SCALE
        SCALE -.->|"done / error"| SCH
        IF -.->|"scratch base / epsilon / delta"| NORM
        NORM -.->|"quant_d"| SCALE
        SCALE -.->|"effective_mat + M/r"| TM
        ROW -->|"Request / write data"| REQMUX
        NORM -->|"Request / write data"| REQMUX
        TM -->|"Request / write data"| REQMUX
        REQMUX -->|"Address / enable / write data"| WS
        WS -->|"256-bit read data / valid"| RSPDEC
        RSPDEC -->|"Vector data"| ROW
        RSPDEC -->|"X / scratch / q"| NORM
        RSPDEC -->|"q / output"| TM
        TM -.->|"Read request"| PM
        PM -->|"256 bit + valid"| TM
    end
    HOST <-->|"Address / data / handshake"| IF'''

DIAGRAMS = {
    'matmulfree.sv': OVERVIEW,
    'npu_pkg.sv': '''flowchart TB
    subgraph PKG["npu_pkg — định nghĩa dùng khi elaboration, không phải instance phần cứng"]
        SIZE["Hằng số độ rộng / dung lượng<br/>SRAM 256 bit · K_MAX=512"]
        TYPE["Kiểu tensor + descriptor<br/>ws_desc_t 32 bit · mat_desc_t 96 bit"]
        ARITH["Hàm số học tổ hợp<br/>RNE / scale_shift / saturation"]
        CHECK["Hàm kiểm tra descriptor<br/>ws_words / ws_valid / ranges_overlap"]
    end
    TOP["Top + descriptor file + SRAM wrappers"]
    ENGINE["Row-wise / NORM / ternary engines"]
    SIZE -.->|"Kích thước RTL"| TOP
    SIZE -.-> ENGINE
    TYPE -.->|"Kiểu cổng và metadata"| TOP
    TYPE -.-> ENGINE
    ARITH -.->|"Logic triển khai tại nơi gọi"| ENGINE
    CHECK -.->|"Logic kiểm tra tại nơi gọi"| ENGINE''',
    'norm.sv': '''flowchart TB
    WS["Workspace SRAM qua mux top<br/>X S16 · scratch S32 · q S8"]
    CFG["Base X/z/q · K · epsilon · delta · start"]
    subgraph CORE["norm — RMSNorm + QUANT"]
        CTRL["Điều khiển + kiểm tra vùng<br/>Bộ đếm phần tử / tạo địa chỉ"]
        READ["Read buffer 256 bit"]
        LANE["Two-lane selector"]
        SQ["Hai bộ bình phương<br/>Bộ cộng tổng U40"]
        COEF["Khối mean-square / hệ số<br/>div 64/32 dùng chung nội bộ<br/>isqrt_u64 + RNE hệ số"]
        Z["Hai nhánh nhân M_norm<br/>RNE + clamp S24/F16"]
        MAX["Abs + max tracker<br/>D = max(absmax, delta)"]
        Q["Hai nhánh nhân M_quant<br/>RNE + clamp S8"]
        PACK["Output packer 256 bit<br/>Scratch S32 hoặc q S8"]
    end
    META["quant_d · norm M/r · quant M/r"]
    STATUS["busy / done / overflow / format_error"]
    CFG -.-> CTRL
    CFG -.-> COEF
    CFG -.-> MAX
    CTRL -.->|"Read/write request"| WS
    WS -->|"Read data / valid"| READ
    READ --> LANE
    CTRL -.->|"Lane / format select"| LANE
    LANE -->|"X"| SQ
    SQ -->|"sum_sq"| COEF
    LANE -->|"X"| Z
    COEF -.->|"norm M/r"| Z
    Z --> MAX
    MAX -->|"D"| COEF
    LANE -->|"Scratch z"| Q
    COEF -.->|"quant M/r"| Q
    Z --> PACK
    Q --> PACK
    PACK -->|"Write data"| WS
    COEF --> META
    MAX --> META
    CTRL -.-> STATUS''',
    'ternary_mul.sv': '''flowchart TB
    CFG["q / output / matrix descriptors + start"]
    WS["Workspace port<br/>256-bit read/write"]
    PM["Parameter read port<br/>256-bit weight / bias"]
    subgraph CORE["ternary_mul"]
        CTRL["Descriptor checks + controller<br/>Row/chunk counters + address generators"]
        QB["Activation buffer<br/>32 × S8"]
        WB["Weight buffer 256 bit"]
        WSEL["32-weight slice selector"]
        PE["32 ternary lanes<br/>Chọn +q / 0 / −q · mask ngoài K"]
        RED["acc_mul<br/>Cây cộng tổ hợp 32 term S9"]
        ACC["Bộ cộng tích lũy + accumulator S18"]
        BIAS["Bias S32 buffer"]
        BSEL["Bias / zero selector"]
        POST["postscale<br/>Nhân M · RNE r · cộng bias · saturation"]
        OUT["Output packer 256 bit<br/>S16 hoặc S32"]
    end
    CFG -.-> CTRL
    CFG -.->|"M/r, format"| POST
    CTRL -.->|"Read/write request"| WS
    CTRL -.->|"Read request"| PM
    WS --> QB
    PM --> WB
    PM --> BIAS
    CTRL -.->|"no_bias"| BSEL
    QB --> PE
    WB --> WSEL
    CTRL -.->|"chunk offset"| WSEL
    WSEL --> PE
    CTRL -.->|"K / chunk"| PE
    PE --> RED
    RED --> ACC
    ACC --> POST
    BIAS --> BSEL
    BSEL --> POST
    POST --> OUT
    OUT -->|"Write data"| WS
    CTRL -.-> STATUS["busy / done / format_error"]
    POST -.-> OV["overflow"]''',
    'rowwise_op.sv': '''flowchart TB
    IN["A / B / old state words 256 bit<br/>Format + fractional bits + valid_elems"]
    subgraph CORE["rowwise_op"]
        CTRL["Opcode controller + element index<br/>Input / format checks"]
        BUF["Operand buffers"]
        LANE["Lane selectors"]
        AS["Cộng/trừ và ReLU logic"]
        OMUX["Multiplier operand mux"]
        MUL["Hai bộ nhân unsigned 16 × 16<br/>Khôi phục dấu · dùng chung MUL và REC"]
        REC["REC sum S33<br/>RNE 15 + saturation S16"]
        SCALE["Đổi scale + RNE<br/>Saturation S16 / U16"]
        SIG["sigmoid instance<br/>ROM 257 mẫu + nội suy"]
        RES["Result selector"]
        RBUF["Result buffer 256 bit"]
    end
    IN --> BUF
    IN -.-> CTRL
    OP["start / select"] -.-> CTRL
    BUF --> LANE
    CTRL -.->|"Chọn lane / opcode"| LANE
    CTRL -.-> OMUX
    LANE --> AS
    LANE --> OMUX
    LANE --> SIG
    OMUX --> MUL
    AS --> SCALE
    MUL -->|"MUL products"| SCALE
    MUL -->|"Hai tích REC"| REC
    SCALE --> RES
    REC --> RES
    SIG --> RES
    CTRL -.->|"Chọn kết quả / vị trí ghi"| RES
    RES --> RBUF
    RBUF --> OUT["result_word 256 bit"]
    CTRL -.-> STATUS["busy / done / overflow / format_error"]''',
    'rowwise_dispatch.sv': '''flowchart TB
    CFG["start / opcode / A, B, dst descriptors"]
    WS["Workspace read/write port 256 bit"]
    subgraph DISPATCH["rowwise_dispatch"]
        CHECK["Descriptor checker<br/>Format / scale / length / overlap"]
        CTRL["Controller + word counter<br/>valid_elems"]
        ADDR["Workspace address selector<br/>A / B / old dst / output dst"]
        BUF["A / B / old-destination buffers<br/>3 × 256 bit"]
        ALU["rowwise_op<br/>Vector arithmetic + sigmoid"]
        WRITE["Output write connection<br/>alu_result + dst address"]
        STATUS["Completion / error / overflow aggregation"]
    end
    CFG -.-> CHECK
    CFG -.-> CTRL
    CHECK -.-> CTRL
    CTRL -.->|"Select + enable"| ADDR
    ADDR -.->|"Read/write address"| WS
    WS -->|"Read data / valid"| BUF
    CTRL -.->|"Buffer load selects"| BUF
    BUF --> ALU
    CTRL -.->|"start / op / format / tail"| ALU
    ALU -.->|"done / error / overflow"| CTRL
    ALU --> WRITE
    WRITE -->|"Write data"| WS
    CTRL -.-> STATUS''',
    'scale_compose.sv': '''flowchart TB
    IN["factor_m U24 · quant_d U24 · factor_r U6"]
    subgraph SC["scale_compose"]
        PROD["M × D multiplier<br/>numerator_base U48"]
        CTRL["Coefficient controller<br/>Candidate-r counter + validity checks"]
        SHIFT["Numerator / denominator shift network<br/>Base denominator 127 × 65536"]
        DIV["div instance<br/>Unsigned 64 / 64"]
        ROUND["RNE quotient<br/>Remainder compare + increment"]
        CHECK["U24 range / zero / overflow checks"]
        OUT["Result coefficient storage<br/>M U24 + r U6"]
    end
    IN --> PROD
    IN -.-> CTRL
    START["start"] -.-> CTRL
    PROD --> SHIFT
    CTRL -.->|"candidate − factor_r"| SHIFT
    SHIFT --> DIV
    SHIFT -.->|"Shift overflow"| CHECK
    DIV --> ROUND
    SHIFT -->|"Denominator"| ROUND
    ROUND --> OUT
    ROUND --> CHECK
    CHECK -.-> CTRL
    CTRL -.->|"start"| DIV
    DIV -.->|"done / div_zero"| CTRL
    CTRL -.->|"r / output enable"| OUT
    OUT --> RESULT["result_m / result_r"]
    CTRL -.-> STATUS["busy / done / format_error"]''',
    'sigmoid.sv': '''flowchart TB
    X["x_raw S16 + frac_bits"]
    subgraph SIG["sigmoid"]
        COORD["Coordinate conversion + boundary clamp<br/>Index 9 bit · fraction 24 bit"]
        CTRL["Controller + index/fraction storage"]
        ADDR["ROM address selector<br/>index hoặc bounded index+1"]
        ROM["Một ROM lookup dùng chung<br/>257 × 16 bit · sigmoid_lut.svh"]
        SAMPLES["Sample storage y0 / y1"]
        INTERP["Nội suy tổ hợp<br/>y0 + (y1 − y0) × fraction<br/>RNE 24 bit"]
        OUT["Output storage U16/F15"]
    end
    X --> COORD
    COORD --> CTRL
    START["start"] -.-> CTRL
    CTRL -.-> ADDR
    ADDR --> ROM
    ROM --> SAMPLES
    CTRL -.->|"Sample load selects"| SAMPLES
    SAMPLES --> INTERP
    CTRL -->|"fraction"| INTERP
    INTERP --> OUT
    CTRL -.->|"Output enable"| OUT
    OUT --> Y["y_raw U16/F15"]
    CTRL -.-> STATUS["busy / done"]''',
    'sram_256_wrapper.sv': '''flowchart TB
    C["Compute port<br/>256-bit data + read/write address"]
    H["Host port<br/>32-bit data + word/lane address"]
    subgraph SRAM["sram_256_wrapper — memory implementation boundary"]
        WM["Write arbiter + data/mask selector<br/>Một đường ghi · mask 8 × 32 bit"]
        MEM["Memory array<br/>2^ADDR_W × 256 bit<br/>Không reset nội dung"]
        RD["Compute read address / pending storage<br/>Read data + valid output storage"]
        HR["Host word / lane read selector<br/>Đọc tổ hợp 32 bit"]
    end
    C -->|"Write data / address / enable"| WM
    H -->|"Write data / lane mask"| WM
    WM --> MEM
    C -.->|"Read address / enable"| RD
    RD -.->|"Array address"| MEM
    MEM -->|"Word 256 bit"| RD
    RD -->|"rd_data / rd_valid"| C
    H -.->|"Read address"| HR
    MEM --> HR
    HR -->|"host_rdata"| H''',
    'descriptor_file.sv': '''flowchart TB
    H["Host 32-bit read/write<br/>ID · matrix select · word select"]
    subgraph DF["descriptor_file"]
        WD["Host write decoder<br/>Workspace enable / matrix slice enable"]
        W["Workspace descriptor bank<br/>8 × 32 bit"]
        M["Matrix descriptor bank<br/>8 × 96 bit"]
        RM["Host read selector<br/>Workspace word / matrix 32-bit slice"]
        WR["Ba cổng đọc descriptor tổ hợp"]
        MR["Một cổng đọc descriptor tổ hợp"]
    end
    H --> WD
    WD --> W
    WD --> M
    W --> RM
    M --> RM
    H -.->|"Read selects"| RM
    RM -->|"host_rdata"| H
    IDS["ws_id0 / ws_id1 / ws_id2"] -.-> WR
    MID["mat_id"] -.-> MR
    W --> WR
    M --> MR
    WR --> WO["src0 / src1 / dst descriptors"]
    MR --> MO["Matrix descriptor 96 bit"]''',
    'div.sv': '''flowchart TB
    N["Numerator NUM_W bit"]
    D["Denominator DEN_W bit"]
    subgraph DIV["div — unsigned iterative divider"]
        CTRL["Start / completion controller<br/>Bit counter + zero-divisor detector"]
        WORK["Working storage<br/>q_work · rem_work · den_reg"]
        ALU["Shift + compare/subtract<br/>Một datapath số học dùng lặp"]
        MUX["Arithmetic feedback / zero-divisor selector"]
        OUT["Quotient / remainder output storage"]
    end
    N --> WORK
    D --> WORK
    D -.-> CTRL
    START["start"] -.-> CTRL
    WORK --> ALU
    ALU --> MUX
    WORK -->|"Zero-divisor bypass data"| MUX
    MUX -->|"Feedback q_next / remainder"| WORK
    MUX --> OUT
    CTRL -.->|"Load / update enables"| WORK
    CTRL -.->|"Output select / enable"| OUT
    OUT --> Q["quotient / remainder"]
    CTRL -.-> STATUS["busy / done / div_zero"]''',
    'acc_mul.sv': '''flowchart LR
    IN["term array<br/>32 × signed S9 ở ternary core"]
    subgraph RED["acc_mul — logic tổ hợp"]
        EXT["Sign extension + zero padding<br/>LEAVES = power-of-two input count"]
        TREE["Mạng cộng nhị phân cân bằng<br/>32 input: 31 bộ cộng / 5 mức logic<br/>ACC_W = 18"]
    end
    IN --> EXT
    EXT --> TREE
    TREE --> OUT["sum / partial S18"]''',
    'postscale.sv': '''flowchart TB
    A["acc S18"] --> MUL["Multiplier<br/>S18 × U24 → S42"]
    M["scale_m U24"] --> MUL
    MUL --> RNE["Sign extension + RNE shift S64"]
    R["scale_r U6"] -.-> RNE
    RNE --> ADD["Bias adder S64"]
    B["bias S32"] --> ADD
    ADD --> S16["Saturation S16"]
    ADD --> S32["Saturation S32"]
    ADD --> DET["S16/S32 range detectors"]
    DET --> OV["Overflow selector"]
    F["output_s32"] -.-> OV
    S16 --> Y16["y_s16"]
    S32 --> Y32["y_s32"]
    OV --> O["overflow"]''',
    'norm_dispatch.sv': '''flowchart TB
    D["src / dst descriptors"]
    C["start · scratch base · epsilon · delta"]
    subgraph WRAP["norm_dispatch"]
        CHECK["Descriptor checker<br/>Bounds · S16/S8 · equal length"]
        GATE["Start gate + rejection pulse storage"]
        CORE["norm core<br/>RMSNorm + QUANT"]
        STATUS["Completion/error combiner<br/>Core status + rejected"]
    end
    D -.-> CHECK
    D -.->|"Base / K"| CORE
    C -.-> GATE
    C -.->|"scratch / epsilon / delta"| CORE
    CHECK -.-> GATE
    GATE -.->|"Validated start"| CORE
    CORE -.->|"core_busy"| GATE
    CORE <-->|"256-bit data / request / valid"| WS["Workspace port"]
    CORE --> META["D + norm M/r + quant M/r"]
    CORE -.-> STATUS
    GATE -.->|"rejected"| STATUS
    STATUS -.-> OUT["busy / done / overflow / format_error"]''',
    'regfile.sv': '''flowchart LR
    C["Compute workspace port<br/>Data 256 bit · address 8 bit"]
    H["Host/debug port<br/>Data 32 bit · word-index 11 bit"]
    subgraph WRAP["regfile.sv — module register"]
        subgraph SRAM["sram_256_wrapper · ADDR_W=8"]
            PORT["Masked write / compute read / host lane select"]
            MEM["Workspace memory array<br/>256 × 256 bit = 8 KiB"]
            PORT <--> MEM
        end
    end
    C <-->|"Read/write + valid"| PORT
    H <-->|"32-bit lane access"| PORT''',
    'mem_mapping.sv': '''flowchart LR
    C["Ternary compute read port<br/>Data 256 bit · address 10 bit<br/>Compute write tied off in matmulfree"]
    H["Host port<br/>Data 32 bit · word-index 13 bit"]
    subgraph WRAP["mem_mapping"]
        subgraph SRAM["sram_256_wrapper · ADDR_W=10"]
            PORT["Masked write / compute read / host lane select"]
            MEM["Parameter memory array<br/>1024 × 256 bit = 32 KiB"]
            PORT <--> MEM
        end
    end
    C -.->|"Read request"| PORT
    PORT -->|"Read data / valid"| C
    H <-->|"32-bit lane access"| PORT''',
    'PC.sv': '''flowchart TB
    CTRL["clear / advance"] -.-> MUX["Next-PC selector<br/>Zero / increment / hold"]
    ZERO["Constant 0"] --> MUX
    INC["Incrementer +1<br/>9 bit"] --> MUX
    MUX --> REG["PC storage 9 bit"]
    REG --> INC
    REG -->|"Hold feedback"| MUX
    CLK["clk / rst_n"] -.-> REG
    REG --> OUT["pc_out → instruction memory address"]''',
    'ins_mem.sv': '''flowchart TB
    H["Host instruction write<br/>host_addr 9 bit · host_instr 13 bit"]
    subgraph IM["ins_mem"]
        WRITE["Synchronous write port"]
        MEM["Instruction memory array<br/>512 × 13 bit"]
        READ["Program read selector<br/>Combinational"]
        HR["Host read selector<br/>Combinational"]
    end
    H --> WRITE
    WE["clk / host_we"] -.-> WRITE
    WRITE --> MEM
    MEM --> READ
    MEM --> HR
    PC["addr / PC 9 bit"] -.-> READ
    HA["host_addr 9 bit"] -.-> HR
    READ --> I["instr 13 bit → scheduler"]
    HR --> R["host_rinstr 13 bit"]''',
    'matmul_wrap.sv': '''flowchart LR
    CLK["CLOCK_50"] -.-> CORE["matmulfree<br/>NPU core"]
    SW["SW[0] / rst_n"] -.-> CORE
    HOST["Host 32-bit interface"] <--> CORE
    CORE -.-> LED["LEDG[0]=ready<br/>LEDG[1]=overflow<br/>LEDG[2]=error"]
    CORE -.-> DBG["Local signals<br/>running · pc_debug · instr_debug"]''',
    'addsub.sv': '''flowchart LR
    A["a S16"] --> EXT["Sign-extension network<br/>A/B → S17"]
    B["b S16"] --> EXT
    EXT --> ALU["Combinational adder/subtractor S17"]
    SUB["sub"] -.-> ALU
    ALU --> W["wide S17"]
    ALU --> SAT["S16 saturator"]
    ALU --> XOR["Overflow detector<br/>wide[16] XOR wide[15]"]
    SAT --> R["result S16"]
    XOR --> O["overflow"]''',
    'mul.sv': '''flowchart TB
    A["a S16"] --> MUL["Signed multiplier<br/>S16 × S17 → S33"]
    B["b 16 bit"] --> EXT["Sign/zero-extension selector"]
    U["b_unsigned"] -.-> EXT
    EXT --> MUL
    MUL --> P["product output<br/>Low 32 bits"]
    MUL --> RNE["Sign-extend S64 + RNE shifter"]
    SHIFT["rshift"] -.-> RNE
    RNE --> SAT["S16 saturator + range checker"]
    B --> GATE["Gate range detector<br/>Raw value above 0x8000"]
    U -.-> GATE
    SAT --> R["result S16"]
    SAT -.-> OV["Overflow OR logic"]
    GATE -.-> OV
    OV --> O["overflow"]''',
    'ctrl_unit.sv': '''flowchart TB
    I["instr 13 bit"] --> SEL["Opcode slice<br/>instr[12:9]"]
    SEL --> DEC["Combinational opcode decoder<br/>Legacy control mapping"]
    DEC -.-> REG["reg_wr_en / reg_rd_en"]
    DEC -.-> ALU["alu_op 3 bit"]
    DEC -.-> UNS["unsupported"]
    ZERO["Constant-zero connections"] -.-> MEM["mem_wren / mem_rden_0 / mem_rden_1 / wb_sel"]''',
    'hazard_detect.sv': '''flowchart LR
    M["multicycle_busy"] -.-> OR["OR gate"]
    B["memory_busy"] -.-> OR
    OR -.-> INV["Inverter"]
    INV -.-> EN["pc_enable / fd_enable / de_enable"]
    OR -.-> F["flush_younger"]
    ONE["Constant 1"] -.-> OLD["em_enable / mw_enable"]''',
    'exp.sv': '''flowchart LR
    A["a[15:0]<br/>Input không được sử dụng"]
    ZERO["Constant-zero connection<br/>16'h0000"] --> OUT["result[15:0]"]''',
    'mem_burst.v': '''flowchart TB
    CLIENT["Upstream burst interface<br/>Request / address / length / data"]
    DDR["External FPGA memory controller<br/>app command / write data / read response"]
    subgraph ADAPTER["mem_burst — legacy burst adapter"]
        CTRL["Burst controller<br/>Read/write arbitration + calibration gating"]
        ADDR["Address generator + command storage<br/>app_addr / app_cmd / app_en"]
        COUNT["Separate address / data counters<br/>Read and write completion comparators"]
        WR["Write-data connection + handshake gating<br/>app_wdf_data / end / wren"]
        RD["Read-data / valid direct connections"]
    end
    CLIENT -.->|"Burst requests + length"| CTRL
    CLIENT -->|"Base address"| ADDR
    CLIENT -->|"Write data"| WR
    CTRL -.-> ADDR
    CTRL -.-> WR
    ADDR -->|"Command channel"| DDR
    WR -->|"Write-data channel"| DDR
    DDR -->|"Read-data channel"| RD
    RD --> CLIENT
    DDR -.->|"ready / valid"| COUNT
    CLIENT -.->|"Burst length"| COUNT
    COUNT -.-> CTRL
    DDR -.->|"init_calib_complete"| CTRL
    CTRL -.->|"finish / write-data request"| CLIENT''',
}

# The four historical storage modules are shown in isolation, never chained
# into a CPU pipeline or included in the active NPU hierarchy.
for name, payload in {
    'fd_reg.sv': 'Instruction 13 bit + PC 9 bit',
    'de_reg.sv': 'Instruction + PC + hai operand 256 bit + control',
    'em_reg.sv': 'Instruction + PC + result/operand 256 bit + control',
    'mw_reg.sv': 'Instruction + PC + hai result 256 bit + control',
}.items():
    DIAGRAMS[name] = f'''flowchart LR
    IN["Input payload<br/>{payload}"] --> BANK["Bank thanh ghi legacy độc lập<br/>Load enable + reset/flush clear"]
    EN["enable"] -.-> BANK
    RESET["clk / rst_n / flush"] -.-> BANK
    BANK --> OUT["Output payload cùng cấu trúc"]'''

CAPTIONS = {
    'npu_pkg.sv': ('Đây là sơ đồ quan hệ định nghĩa RTL: package không tạo một instance phần cứng riêng. '
                   'Các hàm tổ hợp được triển khai tại từng nơi gọi, không hàm ý một bộ số học dùng chung.'),
    'mem_mapping.sv': ('Sơ đồ đặt wrapper trong kết nối hiện tại của matmulfree: compute chỉ đọc. '
                       'Cổng ghi compute vẫn có trong module nhưng bị nối hằng 0 tại top.'),
}
for name in ('fd_reg.sv', 'de_reg.sv', 'em_reg.sv', 'mw_reg.sv', 'ctrl_unit.sv',
             'hazard_detect.sv', 'exp.sv', 'mem_burst.v', 'addsub.sv', 'mul.sv'):
    CAPTIONS[name] = 'Sơ đồ riêng của module legacy/helper; module này không được instantiate trong hierarchy matmulfree hiện tại.'

SECTION_DIAGRAMS = {
    ('matmulfree.sv', 325): '''flowchart TB
    PROG["Program block<br/>PC + instruction memory"]
    DESC["Descriptor file"]
    subgraph CTRL["Điều khiển cấp top trong matmulfree"]
        DECODE["Instruction storage + opcode decode"]
        SCH["Single-issue scheduler"]
        STATUS["Completion/error aggregation<br/>running / ready / sticky error / overflow"]
        QMETA["Runtime q metadata bank<br/>D / base / length / valid"]
        ESEL["Static/dynamic coefficient selector"]
        EFF["Effective matrix descriptor storage"]
    end
    ENGINE["Row-wise / NORM / ternary engines"]
    COMP["scale_compose"]
    PROG --> DECODE
    DECODE -.-> SCH
    DECODE -.->|"IDs"| DESC
    DESC -.-> ESEL
    DESC -.->|"q base/length validation"| SCH
    SCH -.->|"clear / advance"| PROG
    SCH -.->|"start / active_unit"| ENGINE
    ENGINE -.->|"done / error / overflow"| STATUS
    STATUS -.-> SCH
    ENGINE -->|"NORM quant_d"| QMETA
    WR["Workspace write address / host descriptor write"] -.->|"Invalidate"| QMETA
    QMETA -->|"D"| COMP
    QMETA -.->|"Valid / extent"| SCH
    ESEL --> EFF
    EFF -->|"Descriptor M/r"| COMP
    SCH -.->|"Compose start"| COMP
    COMP -.->|"done / error"| SCH
    COMP -->|"Composed M/r"| ESEL
    EFF -.->|"Matrix config"| ENGINE''',
    ('npu_pkg.sv', 59): '''flowchart TB
    X["x signed S64"] --> MAG["Sign / magnitude combinational logic"]
    R["shift U6"] -.-> SH["Unsigned right shifter"]
    MAG --> SH
    MAG --> BITS["Guard / sticky bit extraction"]
    R -.-> BITS
    SH --> INC["Magnitude incrementer"]
    SH -->|"Quotient LSB"| ROUND["RNE decision logic<br/>guard AND sticky-or-LSB"]
    BITS --> ROUND
    ROUND -.-> INC
    INC --> SIGN["Sign restoration + shift-zero bypass selector"]
    MAG -.->|"Sign"| SIGN
    X -->|"Unshifted bypass"| SIGN
    R -.-> SIGN
    SIGN --> OUT["Rounded signed S64<br/>Combinational logic at each caller"]''',
    ('norm.sv', 1): '''flowchart TB
    IN["radicand U64"] --> REG["Working storage<br/>op / res / one"]
    REG --> ALU["Compare / add / subtract network<br/>op compared with res + one"]
    REG --> SHIFT["Right-shift network<br/>res by 1 · one by 2"]
    ALU --> MUX["Working-value selectors"]
    SHIFT --> MUX
    MUX -->|"Arithmetic feedback"| REG
    START["start"] -.-> CTRL["Controller + 32-step counter"]
    CTRL -.->|"Load / update"| REG
    CTRL -.-> MUX
    MUX --> ROOT["Root output storage U32"]
    CTRL -.->|"Output enable"| ROOT
    ROOT --> OUT["root"]
    CTRL -.-> STATUS["busy / done"]''',
    ('norm.sv', 362): '''flowchart TB
    WS["Workspace read port 256 bit"] --> BUF["Read buffer + two S16 lane selectors"]
    CTRL["Word/lane counters + length mask<br/>Read request controller"] -.-> WS
    CTRL -.-> BUF
    BUF --> SQ0["Signed square multiplier 0<br/>S16 × S16"]
    BUF --> SQ1["Signed square multiplier 1<br/>S16 × S16"]
    SQ0 --> MASK["Tail mask + pair sum U40"]
    SQ1 --> MASK
    CTRL -.-> MASK
    MASK --> ACC["U40 sum accumulator<br/>Adder + sum_sq storage"]
    ACC --> COEF["Mean-square / coefficient block"]''',
    ('norm.sv', 428): '''flowchart TB
    X["Read buffer<br/>Two X values S16"] --> MUL["Two norm multipliers<br/>X × norm_m"]
    COEF["norm_m U24 / norm_r U6"] --> MUL
    MUL --> ROUND["Two RNE / S24 saturation paths"]
    COEF -.-> ROUND
    ROUND --> PACK["Sign-extension to S32<br/>256-bit scratch pack buffer"]
    ROUND --> MAX["Absolute-value + max comparator<br/>absmax storage"]
    PACK --> WS["Workspace scratch write port"]
    MAX --> D["D selector / quantization coefficient block"]
    CTRL["Address / lane / pack counters + write control"] -.-> PACK
    CTRL -.-> WS
    ROUND -.-> OV["Overflow aggregation"]''',
    ('norm.sv', 491): '''flowchart TB
    WS["Workspace scratch read port<br/>256 bit = 8 S32 slots"] --> BUF["Read buffer + two S24 lane selectors"]
    BUF --> MUL["Two quantization multipliers<br/>z × quant_m"]
    COEF["quant_m U24 / quant_r U6"] --> MUL
    MUL --> ROUND["Two RNE + S8 saturation paths"]
    COEF -.-> ROUND
    ROUND --> PACK["256-bit output pack buffer<br/>32 q values S8"]
    PACK --> OUT["Workspace q write port"]
    CTRL["Read/write controller<br/>Address / lane / pack counters"] -.-> WS
    CTRL -.-> BUF
    CTRL -.-> PACK
    CTRL -.-> OUT''',
    ('ternary_mul.sv', 60): '''flowchart TB
    Q["q_word<br/>32 activations S8"] --> SIGN["32 sign-extension / negation paths<br/>+q and −q in S9"]
    W["w_word 256 bit"] --> SEL["Weight slice selector<br/>32 weights × 2 bit"]
    CFG["K / input chunk index"] -.-> SEL
    SEL --> DEC["32 weight decoders + reserved-code detector"]
    SIGN --> PE["32 ternary selectors<br/>+q / zero / −q + tail mask"]
    DEC -.-> PE
    CFG -.-> PE
    CFG -.->|"Useful-lane mask"| DEC
    PE --> TREE["acc_mul<br/>32-term combinational adder tree"]
    TREE --> ACC["S18 accumulation adder + storage"]
    ACC --> POST["postscale input"]
    DEC -.-> ERR["Reserved-weight error<br/>Only for useful lanes inside K"]''',
    ('rowwise_op.sv', 58): '''flowchart TB
    MULIN["Two pairs of MUL lane operands"] --> MUX["Operand selection + magnitude/sign logic<br/>MUL or REC"]
    RECIN["Old state H · candidate C · gate F"] --> MUX
    RECIN --> COMP["Gate complement subtractor<br/>0x8000 − F"]
    COMP --> MUX
    OP["Opcode / valid lanes"] -.-> MUX
    MUX --> M0["Shared unsigned multiplier 0<br/>16 × 16"]
    MUX --> M1["Shared unsigned multiplier 1<br/>16 × 16"]
    M0 --> SIGN["Product sign-correction logic"]
    M1 --> SIGN
    SIGN --> MS["MUL rescale / RNE / saturation paths"]
    SIGN --> SUM["REC adder S33<br/>Two products of one state element"]
    SUM --> RS["REC RNE 15 + saturation S16"]
    MS --> OUT["Result selector / buffer"]
    RS --> OUT''',
    ('rowwise_dispatch.sv', 114): '''flowchart TB
    D["Latched descriptors + opcode"] -.-> CTRL["Dispatcher controller<br/>word_index / word_count / valid_elems"]
    D -.-> ADDR["Workspace address selector<br/>A / B / old dst / output dst"]
    CTRL -.-> ADDR
    ADDR -.-> WS["Workspace SRAM interface"]
    WS -->|"Read data / valid"| BUF["A / B / old-state word buffers"]
    CTRL -.->|"Load selects"| BUF
    BUF --> ALU["rowwise_op"]
    CTRL -.->|"start / format / opcode"| ALU
    ALU -->|"Result word"| WS
    ALU -.->|"done / error / overflow"| CTRL
    CTRL -.->|"Write enable"| WS
    CTRL -.-> STATUS["busy / done / overflow / format_error"]''',
    ('scale_compose.sv', 79): '''flowchart TB
    BASE["numerator_base U48 + base_r"] --> SHIFT["U64 numerator / denominator shift network"]
    CAND["Candidate-r counter U6"] -.-> SHIFT
    SHIFT --> DIV["div 64/64"]
    DIV --> ROUND["RNE quotient adder<br/>Remainder / denominator comparator"]
    SHIFT -->|"Denominator"| ROUND
    ROUND --> FIT["Coefficient range detectors<br/>M exceeds U24 / M is zero"]
    SHIFT -.->|"Shift overflow"| CTRL["Coefficient controller"]
    FIT -.-> CTRL
    DIV -.->|"done / div_zero"| CTRL
    CTRL -.->|"Load / decrement"| CAND
    CTRL -.->|"start"| DIV
    ROUND --> OUT["Result M/r storage"]
    CAND --> OUT
    CTRL -.->|"Output enable"| OUT
    CTRL -.-> STATUS["done / format_error"]''',
    ('sigmoid.sv', 59): '''flowchart TB
    X["x_raw / frac_bits"] --> COORD["Coordinate conversion + clamp"]
    COORD --> IDX["Index/fraction storage"]
    IDX -.-> ADDR["Bounded index / index+1 address selector"]
    CTRL["Sample controller"] -.-> ADDR
    ADDR --> ROM["One shared ROM lookup<br/>257 samples × 16 bit"]
    ROM --> SAMPLE["y0 / y1 sample storage"]
    CTRL -.-> SAMPLE
    SAMPLE --> SUB["Difference subtractor<br/>y1 − y0"]
    SUB --> MUL["U16 × U24 interpolation multiplier"]
    IDX -->|"fraction"| MUL
    MUL --> ADD["S64 interpolation adder"]
    SAMPLE -->|"y0 shifted by 24"| ADD
    ADD --> RNE["RNE right-shift by 24"]
    RNE --> Y["U16/F15 output storage"]''',
    ('sram_256_wrapper.sv', 54): '''flowchart LR
    REQ["Compute read request<br/>rd_en / rd_addr"] -.-> ADDR["Read-address storage"]
    REQ -.-> VALID["Read-pending + valid storage"]
    ADDR -.-> MEM["Memory array read address"]
    MEM --> DATA["Read-data storage<br/>256 bit"]
    VALID -.->|"Capture enable"| DATA
    DATA --> OUT["Compute response<br/>rd_data / rd_valid"]
    VALID -.-> OUT
    RESET["clk / rst_n"] -.-> ADDR
    RESET -.-> VALID
    RESET -.-> DATA''',
    ('div.sv', 25): '''flowchart TB
    Q["q_work storage"] --> SHIFT["Shift / bit-append network"]
    R["rem_work storage"] --> SHIFT
    D["den_reg storage"] --> ALU["Compare/subtract network"]
    SHIFT -->|"Shifted remainder"| ALU
    ALU --> MUX["Remainder result mux"]
    SHIFT -->|"Unsubtracted remainder"| MUX
    ALU -.->|"Comparison result"| MUX
    ALU -.->|"New quotient bit"| QNEXT["Quotient shift + LSB connection"]
    Q --> QNEXT
    MUX -->|"Arithmetic feedback"| R
    QNEXT -->|"Arithmetic feedback"| Q
    CTRL["Divider controller / bit counter"] -.-> Q
    CTRL -.-> R''',
    ('acc_mul.sv', 12): '''flowchart TB
    IN["Input term array"] --> EXT["Signed extension to ACC_W<br/>Zero-pad unused leaves"]
    subgraph TREE["Combinational binary adder network — configuration with 32 leaves"]
        L["16 independent two-input adders"]
        MID["Reduction network<br/>8 + 4 + 2 two-input adders"]
        ROOT["Root two-input adder"]
        L --> MID
        MID --> ROOT
    end
    EXT --> L
    ROOT --> OUT["sum S18"]''',
    ('postscale.sv', 15): '''flowchart TB
    ACC["Accumulator S18"] --> MUL["Signed-by-unsigned multiplier<br/>42-bit product"]
    M["M U24"] --> MUL
    MUL --> ROUND["Sign extension + RNE shifter S64"]
    R["r U6"] -.-> ROUND
    ROUND --> ADD["Signed bias adder S64"]
    B["Bias S32 sign-extended"] --> ADD
    ADD --> S16["S16 range clamp"]
    ADD --> S32["S32 range clamp"]
    ADD --> DET["S16/S32 overflow comparators"]
    F["output_s32"] -.-> DET
    S16 --> Y16["y_s16"]
    S32 --> Y32["y_s32"]
    DET --> OV["overflow"]''',
    ('mem_burst.v', 133): '''flowchart TB
    CFG["Read/write burst length"] -.-> CMP["Burst-length comparators"]
    CMD["app_rdy / command acceptance"] -.-> AC["Read/write address counters"]
    DATA["app_rd_data_valid / wr_burst_data_req"] -.-> DC["Read/write data counters"]
    AC --> CMP
    DC --> CMP
    CMP -.-> CTRL["Burst completion controller"]
    CTRL -.->|"Clear / enable"| AC
    CTRL -.->|"Clear / enable"| DC
    CTRL -.-> ISSUE["Address / command / write-data control"]
    CTRL -.-> OUT["rd_burst_finish / wr_burst_finish / burst_finish"]''',
}

# Schematic symbols requested for the architecture guide. Data flows from the
# wide input side to the narrow output side of a MUX (trap-t in the TB layout).
# A decoder/demux is the inverse (trap-b): one decoded input fans out from its
# wide output side. Addressable arrays and descriptor banks use a rectangle
# divided by horizontal rules, matching conventional memory drawings.
def _typed_symbols(graph, mux_nodes=(), decoder_nodes=(), memory_nodes=()):
    def replace_node(source, node_id, shape, memory=False):
        pattern = re.compile(rf'(?<![A-Za-z0-9_]){re.escape(node_id)}\["([^"]*)"\]')
        def replacement(match):
            label = match.group(1)
            if memory:
                rows = label.split('<br/>')
                if len(rows) == 1:
                    rows.append('Addressable storage')
                label = '<hr/>'.join(rows)
            return f'{node_id}@{{ shape: {shape}, label: "{label}" }}'
        updated, count = pattern.subn(replacement, source, count=1)
        assert count == 1, f'Missing node declaration {node_id}'
        return updated
    for node_id in mux_nodes:
        graph = replace_node(graph, node_id, 'trap-t')
    for node_id in decoder_nodes:
        graph = replace_node(graph, node_id, 'trap-b')
    for node_id in memory_nodes:
        graph = replace_node(graph, node_id, 'rect', memory=True)
    return graph

MAIN_MUX_NODES = {
    'matmulfree.sv': ('REQMUX',),
    'norm.sv': ('LANE',),
    'ternary_mul.sv': ('WSEL', 'BSEL', 'PE'),
    'rowwise_op.sv': ('LANE', 'OMUX', 'RES'),
    'rowwise_dispatch.sv': ('ADDR',),
    'sigmoid.sv': ('ADDR',),
    'sram_256_wrapper.sv': ('WM', 'HR'),
    'descriptor_file.sv': ('RM',),
    'div.sv': ('MUX',),
    'postscale.sv': ('OV',),
    'PC.sv': ('MUX',),
    'ins_mem.sv': ('READ', 'HR'),
    'mul.sv': ('EXT',),
}
MAIN_DECODER_NODES = {
    'matmulfree.sv': ('RSPDEC',),
    'descriptor_file.sv': ('WD',),
    'ctrl_unit.sv': ('DEC',),
}
MAIN_MEMORY_NODES = {
    'matmulfree.sv': ('IM', 'DESC', 'WS', 'PM'),
    'norm.sv': ('WS',),
    'sigmoid.sv': ('ROM',),
    'sram_256_wrapper.sv': ('MEM',),
    'descriptor_file.sv': ('W', 'M'),
    'regfile.sv': ('MEM',),
    'mem_mapping.sv': ('MEM',),
    'ins_mem.sv': ('MEM',),
    'mem_burst.v': ('DDR',),
}
SECTION_MUX_NODES = {
    ('matmulfree.sv', 325): ('ESEL',),
    ('npu_pkg.sv', 59): ('SIGN',),
    ('norm.sv', 1): ('MUX',),
    ('norm.sv', 428): ('D',),
    ('norm.sv', 491): ('BUF',),
    ('ternary_mul.sv', 60): ('SEL', 'PE'),
    ('rowwise_op.sv', 58): ('MUX', 'OUT'),
    ('rowwise_dispatch.sv', 114): ('ADDR',),
    ('sigmoid.sv', 59): ('ADDR',),
    ('div.sv', 25): ('MUX',),
}
SECTION_DECODER_NODES = {
    ('ternary_mul.sv', 60): ('DEC',),
}
SECTION_MEMORY_NODES = {
    ('matmulfree.sv', 325): ('DESC', 'QMETA'),
    ('sigmoid.sv', 59): ('ROM',),
    ('sram_256_wrapper.sv', 54): ('MEM',),
}

OVERVIEW = _typed_symbols(OVERVIEW, MAIN_MUX_NODES['matmulfree.sv'], MAIN_DECODER_NODES['matmulfree.sv'], MAIN_MEMORY_NODES['matmulfree.sv'])
for _name in tuple(DIAGRAMS):
    DIAGRAMS[_name] = _typed_symbols(DIAGRAMS[_name], MAIN_MUX_NODES.get(_name, ()), MAIN_DECODER_NODES.get(_name, ()), MAIN_MEMORY_NODES.get(_name, ()))
for _key in tuple(SECTION_DIAGRAMS):
    SECTION_DIAGRAMS[_key] = _typed_symbols(SECTION_DIAGRAMS[_key], SECTION_MUX_NODES.get(_key, ()), SECTION_DECODER_NODES.get(_key, ()), SECTION_MEMORY_NODES.get(_key, ()))

EXPECTED_MUX_SYMBOLS = sum(map(len, MAIN_MUX_NODES.values())) + sum(map(len, SECTION_MUX_NODES.values())) + len(MAIN_MUX_NODES['matmulfree.sv'])
EXPECTED_DECODER_SYMBOLS = sum(map(len, MAIN_DECODER_NODES.values())) + sum(map(len, SECTION_DECODER_NODES.values())) + len(MAIN_DECODER_NODES['matmulfree.sv'])
EXPECTED_MEMORY_SYMBOLS = sum(map(len, MAIN_MEMORY_NODES.values())) + sum(map(len, SECTION_MEMORY_NODES.values())) + len(MAIN_MEMORY_NODES['matmulfree.sv'])

# Reserve space for group titles when long Vietnamese labels wrap.
_LAYOUT = '%%{init: {"flowchart": {"subGraphTitleMargin": {"top": 8, "bottom": 20}, "nodeSpacing": 28, "rankSpacing": 42, "curve": "linear"}}}%%'
def _with_layout(graph):
    first, rest = graph.split('\n', 1)
    return first + '\n' + _LAYOUT + '\n' + rest

OVERVIEW = _with_layout(OVERVIEW)
DIAGRAMS = {name: _with_layout(graph) for name, graph in DIAGRAMS.items()}
SECTION_DIAGRAMS = {key: _with_layout(graph) for key, graph in SECTION_DIAGRAMS.items()}
