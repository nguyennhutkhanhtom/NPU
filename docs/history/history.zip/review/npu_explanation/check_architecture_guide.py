"""Check architecture diagram coverage, generator synchronization and edit scope."""
from pathlib import Path
import hashlib
import json
import re
import zipfile
from architecture_diagrams import (
    DIAGRAMS,
    EXPECTED_DECODER_SYMBOLS,
    EXPECTED_MEMORY_SYMBOLS,
    EXPECTED_MUX_SYMBOLS,
    OVERVIEW,
    SECTION_DIAGRAMS,
)

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DOCS = ROOT / 'research/npu_explained'
PATTERN = re.compile(r'```mermaid\r?\n(.*?)\r?\n```', re.S)
errors = []
total = 0
mux_symbols = 0
decoder_symbols = 0
memory_symbols = 0
for path in DOCS.rglob('*.md'):
    text = path.read_text(encoding='utf-8')
    graphs = PATTERN.findall(text)
    total += len(graphs)
    mux_symbols += sum(graph.count('shape: trap-t') for graph in graphs)
    decoder_symbols += sum(graph.count('shape: trap-b') for graph in graphs)
    memory_symbols += sum(graph.count('shape: rect') for graph in graphs)
    for index, graph in enumerate(graphs):
        if not graph.startswith('flowchart '):
            errors.append(f'Non-block diagram: {path.name}:{index}')
        if re.search(r'\b(?:S_IDLE|S_FETCH|S_START|S_WAIT|S_HALT|REQ_A|WAIT_A|START_ALU|FINISH|READ0|READ1|FETCH|EXECUTE|WRITE_BACK)\b', graph):
            errors.append(f'FSM or pipeline stage in diagram: {path.name}:{index}')
        if re.search(r'\w\s*\{["\w]', '\n'.join(line for line in graph.splitlines() if not line.startswith('%%'))):
            errors.append(f'Algorithm decision diamond in diagram: {path.name}:{index}')
    if path.parent.name == 'blocks' and path.name[:-3] in DIAGRAMS:
        name = path.name[:-3]
        expected = [DIAGRAMS[name]] + [v for (n, _), v in sorted(SECTION_DIAGRAMS.items(), key=lambda item: item[0][1]) if n == name]
        if graphs != expected:
            errors.append(f'Generator mismatch: {name}')
    elif path == DOCS / 'README.md' and graphs != [OVERVIEW]:
        errors.append('Root overview differs from canonical diagram')

with zipfile.ZipFile(WORK / 'before_architecture_diagrams.zip') as before:
    code_pattern = re.compile(r'<!-- source-range:.*?```systemverilog\n.*?\n```', re.S)
    for name in before.namelist():
        if not name.startswith('research/npu_explained/'):
            continue
        old = before.read(name).decode('utf-8').replace('\r\n', '\n')
        new = (ROOT / name).read_text(encoding='utf-8')
        if code_pattern.findall(old) != code_pattern.findall(new):
            errors.append(f'Changed source excerpts: {name}')
        old_graphs, new_graphs = PATTERN.findall(old), PATTERN.findall(new)
        if len(old_graphs) != len(new_graphs) or any(a == b for a, b in zip(old_graphs, new_graphs)):
            errors.append(f'Missing or unchanged diagram: {name}')
        if name.endswith('source_manifest.json') and old != new:
            errors.append('Source manifest changed')

if total != 46:
    errors.append(f'Expected 46 diagrams, got {total}')
if mux_symbols != EXPECTED_MUX_SYMBOLS:
    errors.append(f'Expected {EXPECTED_MUX_SYMBOLS} trapezoid MUX symbols, got {mux_symbols}')
if decoder_symbols != EXPECTED_DECODER_SYMBOLS:
    errors.append(f'Expected {EXPECTED_DECODER_SYMBOLS} inverse-trapezoid decoder symbols, got {decoder_symbols}')
if memory_symbols != EXPECTED_MEMORY_SYMBOLS:
    errors.append(f'Expected {EXPECTED_MEMORY_SYMBOLS} striped memory symbols, got {memory_symbols}')
render = json.loads((WORK / 'diagram_qa/render_validation.json').read_text(encoding='utf-8'))
if len(render['diagrams']) != total or any(x['status'] != 'rendered' for x in render['diagrams']):
    errors.append('Render coverage is incomplete')
for item in render['diagrams']:
    graph = PATTERN.findall((DOCS / item['file']).read_text(encoding='utf-8'))[item['ordinal']]
    if hashlib.sha256(graph.encode('utf-8')).hexdigest() != item.get('source_sha256'):
        errors.append(f'Stale render: {item["file"]}:{item["ordinal"]}')
result = {'total_architecture_diagrams': total, 'block_diagrams': len(DIAGRAMS),
          'group_diagrams': len(SECTION_DIAGRAMS), 'root_overviews': 1,
          'trapezoid_mux_symbols': mux_symbols,
          'inverse_trapezoid_decoder_symbols': decoder_symbols,
          'striped_memory_symbols': memory_symbols,
          'rendered_diagrams': len(render['diagrams']), 'errors': errors,
          'scope': 'Architecture-only diagram structure, MUX/decoder direction and memory symbol conventions, source excerpt preservation, manifest preservation, canonical generator synchronization and Mermaid render coverage.'}
(WORK / 'architecture_validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(bool(errors))
