"""Authored walkthroughs; architecture diagrams live in architecture_diagrams."""
from architecture_diagrams import DIAGRAMS, SECTION_DIAGRAMS


DETAILS = {
    'matmulfree.sv': '''1. Khi idle, host nạp parameter, workspace, descriptor và instruction. `host_ready` chỉ xác nhận địa chỉ hợp lệ được chấp nhận; nó không kiểm tra nội dung model.
2. Start đưa PC về 0, xóa cờ của lần chạy trước và chuyển scheduler sang FETCH. Instruction được chốt vào `instr_q`, nên opcode và các descriptor ID ổn định suốt lệnh nhiều chu kỳ.
3. S_START chọn execution unit. NORM và rowwise đi thẳng tới WAIT. TMATMUL có thể phải chạy `scale_compose` trước nếu q mang scale động từ NORM.
4. `active_unit` điều khiển mux workspace. Chỉ rowwise, norm hoặc ternary được nối với SRAM ở một thời điểm.
5. Khi unit báo done, top gom overflow/error. Lệnh hợp lệ làm PC tăng; lỗi hoặc HALT đưa core về ready.
6. Cache `q_d/q_base/q_length/q_valid` buộc D đi cùng đúng tensor. Ghi đè q hoặc sửa descriptor làm cache mất hiệu lực.''',
    'npu_pkg.sv': '''1. Các parameter xác định biên thiết kế: word 256 bit, 32 ternary lane, hai vector lane và K tối đa 512. Một số module vẫn có literal theo cấu hình này, nên đổi package chưa đủ để tái cấu hình toàn chip.
2. Workspace descriptor mô tả địa chỉ, length, format và F_t. Matrix descriptor mô tả weight, bias, K, số hàng và postscale.
3. `rne_shift64` làm tròn trên magnitude rồi khôi phục dấu. Guard, sticky và LSB xử lý chính xác trường hợp nằm giữa hai số.
4. `sat_s16/sat_s32` clamp sau số học S64, tránh wrap-around khi lấy bit thấp.
5. `ws_words`, `ws_valid` và `ranges_overlap` là lớp kiểm tra memory được nhiều execution unit dùng chung.''',
    'norm.sv': '''1. P1 đọc từng word S16 và xử lý hai phần tử mỗi bước. Hai bình phương S32 được cộng vào `sum_sq` U40; lane padding ngoài K bị bỏ qua.
2. Hai phép chia tạo mean-square có 32 bit phần lẻ. Sau khi cộng epsilon đã quy đổi, `isqrt_u64` tạo RMS raw nhân 2^16.
3. Hệ số norm M/r xấp xỉ `2^32/R`. Input toàn zero dùng M bằng 0 để tránh chia zero.
4. P2 đọc X lần hai, tạo z S24/F16, ghi scratch S32 và tìm `absmax` của toàn vector.
5. D bằng max(absmax, delta). Divider tạo hệ số QUANT xấp xỉ 0x7F/D; D trở thành metadata scale của q.
6. P3 đọc scratch, lượng tử hóa z về S8 và pack 32 phần tử/word. Scratch không được overlap X hay q; q được phép trùng X vì X đã đọc xong.''',
    'ternary_mul.sv': '''1. Start chốt ba descriptor rồi kiểm tra format, K, số hàng, shift, bounds và overlap.
2. Mỗi chunk đọc 32 activation S8. Một word chứa 128 weight nên weight chỉ đọc lại mỗi bốn chunk; các chunk còn lại dùng buffer cũ.
3. Mỗi PE giải mã weight: 01 giữ q, 11 đổi dấu, 00 tạo zero. Mã 10 trong phần K hữu ích gây format error; tail ngoài K luôn bị mask.
4. `acc_mul` cộng 32 term thành partial. Accumulator S18 cộng partial của `ceil(K/32)` chunk để tạo một output.
5. Sau chunk cuối, core đọc bias hoặc dùng zero, chạy postscale, pack kết quả và ghi khi word đầy.
6. Các output row được xử lý lần lượt; 32 PE tăng tốc chiều K chứ không tạo 32 output đồng thời.''',
    'rowwise_op.sv': '''1. Start chốt word, F_t, unsigned flag và số phần tử hợp lệ, tách giao dịch nhiều chu kỳ khỏi thay đổi bên ngoài.
2. ADD/SUB tính trong S17 rồi đổi scale. MUL có F sản phẩm bằng tổng F của hai nguồn.
3. Hai multiplier xử lý hai lane MUL. Với REC, chúng xử lý H×F và C×(0x8000−F) của một lane.
4. REC cộng hai tích trong S33 rồi RNE một lần tại bit 15; làm tròn riêng từng tích sẽ sai ở các trường hợp nửa đơn vị.
5. SIG dùng một instance sigmoid nên chạy từng phần tử. RELU đưa số âm về zero trước khi rescale.
6. Buffer, cờ và index được cập nhật mỗi bước; hết `valid_elems` thì trả nguyên word và pulse done.''',
    'rowwise_dispatch.sv': '''1. Dispatcher validate descriptor trước lần đọc đầu: format, length, F15 của gate và overlap memory.
2. Mỗi word bắt đầu bằng REQ_A/WAIT_A. SIG và RELU dùng ngay A; phép hai nguồn tiếp tục đọc B.
3. REC đọc destination cũ thành H qua REQ_C/WAIT_C. Candidate nằm ở A, gate ở B.
4. START_ALU phát xung một chu kỳ; WAIT_ALU giữ input đến `alu_done`. Format error ngăn ghi word lỗi.
5. WRITE ghi một word 256 bit rồi tăng word index. `valid_elems` bảo đảm tail của word cuối không trở thành dữ liệu thật.''',
    'scale_compose.sv': '''1. `factor_m/factor_r` mô tả scale weight/output, còn D mô tả scale activation do NORM tạo. Tích M×D được giữ trong U48.
2. Mẫu cơ sở `0x007F_0000` bằng `0x7F×0x1_0000`. Candidate r quyết định dịch tử hay mẫu để biểu diễn hệ số thành M/2^r.
3. Khối thử từ r=47 để ưu tiên precision. Shift tràn U64 làm giảm candidate trước khi chạy divider.
4. Quotient được RNE bằng remainder. M quá lớn làm giảm r và thử lại; M bằng zero là underflow khi factor khác zero.
5. Tìm được M U24 thì trả result M/r; D bằng zero, r sai hoặc hết candidate gây format error.''',
    'sigmoid.sv': '''1. Input S16/F_t được đổi thành tọa độ `(16×x_real+0x80)` với 24 fractional bit; −8 ánh xạ index 0x000 và +8 ánh xạ 0x100.
2. Tọa độ ngoài bảng bị clamp. Index/fraction được chốt lúc start, nên thay input sau đó không ảnh hưởng giao dịch.
3. Một cổng ROM được dùng hai chu kỳ: READ0 lấy y0, READ1 lấy mẫu kế y1. Endpoint 0x100 dùng lại cùng mẫu.
4. INTERP tính y0 cộng phần chênh theo fraction rồi RNE 24 bit, trả U16/F15.
5. Synthesis dùng case table hằng. Simulation có thể dùng file ngoài nhưng kiểm tra đủ 257 giá trị và đúng từng mẫu.''',
    'sram_256_wrapper.sv': '''1. Compute đọc/ghi word 256 bit. Host dùng địa chỉ word 32 bit; ba bit thấp chọn lane và các bit cao chọn word.
2. Write mux ưu tiên host khi host write. Host data được nhân bản tám lane nhưng mask one-hot chỉ cập nhật lane được chọn.
3. Mảng memory không reset hoặc initialize. Reset chỉ xóa control read/output; host phải nạp dữ liệu cần thiết.
4. Compute read là request/response: chốt address và pending, sau đó trả data cùng `rd_valid`. Consumer phải chờ valid.
5. Host read hiện là tổ hợp; SRAM macro đồng bộ cần bridge. Assertion simulation bắt truy cập host và compute chồng nhau.''',
    'descriptor_file.sv': '''1. Có tám workspace descriptor và tám matrix descriptor. Reset xóa metadata nhưng không xóa nội dung SRAM.
2. Ba workspace ID đọc tổ hợp source0, source1 và destination cho instruction hiện tại.
3. Matrix ID đọc descriptor 96 bit. Host đọc/ghi matrix qua ba slice 32 bit thấp, giữa và cao.
4. Host write workspace thay toàn bộ descriptor; matrix write chỉ thay slice được chọn, nên phải nạp đủ ba word trước start.
5. File không validate nội dung; từng execution unit kiểm tra descriptor theo phép toán của nó.''',
    'div.sv': '''1. Divider là unsigned; phép signed phải xử lý dấu/magnitude ở caller. Start chỉ được nhận khi không busy.
2. `q_work` ban đầu chứa numerator. Mỗi chu kỳ, một bit được kéo sang `rem_shift`.
3. Nếu remainder đủ lớn, phần cứng trừ denominator và đặt quotient bit mới bằng 1; ngược lại bit mới bằng 0.
4. Sau NUM_W bước, quotient và remainder cuối được chốt cùng pulse done.
5. Chia zero kết thúc ngay với `div_zero=1`; quotient toàn 1 chỉ là quy ước phần cứng, không phải thương hợp lệ.''',
    'acc_mul.sv': '''1. Các term S9 được sign-extend lên S18, giữ đúng số âm và giá trị +128 sinh từ đổi dấu −128.
2. Mảng tree biểu diễn cây nhị phân; nếu số input không là lũy thừa hai, lá dư được pad zero.
3. Với 32 input, năm tầng cộng tạo một partial sum. Vòng for mô tả mạng logic, không phải 31 cycle tuần tự.
4. Module không có pipeline register, nên toàn bộ cây nằm trên combinational timing path.''',
    'postscale.sv': '''1. Accumulator S18 nhân M U24; M được zero-extend trước cast signed để bit cao không bị hiểu là dấu.
2. Tích S42 được mở rộng S64 và chia 2^r bằng RNE.
3. Bias S32 đã ở đơn vị output nên được cộng sau rescale. Cộng trước scale sẽ đổi ý nghĩa bias.
4. Hai output clamp S16/S32 được tính song song; `output_s32` chọn miền báo overflow và đường pack.
5. Đây là logic tổ hợp; start/done và thời điểm dùng kết quả thuộc FSM ternary_mul.''',
    'norm_dispatch.sv': '''1. Wrapper kiểm tra source/destination nằm trong workspace, source S16, destination S8 và length bằng nhau.
2. Descriptor sai không được start norm. `rejected` tạo pulse done/error để scheduler không chờ vô hạn.
3. Descriptor hợp lệ được đổi thành base/K; scratch, epsilon và delta đến từ control register top.
4. Norm core kiểm tra overlap chi tiết rồi trả output, D và hai cặp M/r.''',
    'regfile.sv': '''1. Đây là wrapper workspace; tên module `register` được giữ để tương thích và không phải register file pipeline của thesis.
2. Compute address 8 bit chọn 256 word 256 bit. Host address thêm ba bit để chọn tám lane 32 bit.
3. Port được nối thẳng vào `sram_256_wrapper`; wrapper không thêm storage, latency hoặc arbitration.
4. Timing read, mask write và quy tắc không overlap do implementation chung quyết định.''',
    'mem_mapping.sv': '''1. Đây là wrapper parameter SRAM 32 KiB: compute address 10 bit chọn 1024 word, host thêm ba bit lane.
2. Trong top, compute write bị buộc zero nên ternary core chỉ đọc; host nạp weight/bias khi idle.
3. Tín hiệu nối trực tiếp vào wrapper chung; module không còn mapping FIFO/vector kiểu thesis.
4. Adapter SRAM macro phải giữ read-valid contract mà ternary core đang chờ.''',
    'PC.sv': '''1. Reset active-low asynchronous đưa PC về zero ngay khi `rst_n=0`.
2. Clear được xét ở cạnh clock và ưu tiên hơn advance; top dùng clear khi start chương trình.
3. Advance tăng PC sau khi instruction hoàn tất. Không có control thì flip-flop giữ giá trị.
4. Phép cộng 9 bit có thể wrap, nhưng top chặn advance tại PC 0x1FF (511).''',
    'ins_mem.sv': '''1. Memory chứa 512 instruction 13 bit, không reset hay initialize nên host phải nạp chương trình và HALT.
2. Fetch read là tổ hợp theo PC; scheduler chốt instruction vào `instr_q`.
3. Host có read tổ hợp để kiểm tra và write synchronous tại cạnh clock.
4. Hai đường read của behavioral model cần được xem lại khi ánh xạ sang ROM/SRAM macro ASIC.''',
    'matmul_wrap.sv': '''1. Wrapper chỉ nối pin board với core, không thêm datapath hay instruction.
2. CLOCK_50 cấp trực tiếp cho core; SW[0] là reset active-low.
3. Host bus đi thẳng vào matmulfree nên giữ nguyên memory map và quy tắc chỉ ghi khi idle.
4. LED báo ready, overflow và error; running/PC/instruction debug chỉ tồn tại nội bộ.''',
    'addsub.sv': '''1. A và B được sign-extend S16 lên S17 trước cộng/trừ để giữ carry và dấu thật.
2. `sub` chọn cộng B hoặc cộng đối của B; `wide` giữ kết quả chưa clamp.
3. Hai bit cao khác nhau nghĩa kết quả S17 không vừa S16, nên overflow lên 1.
4. `sat_s16` clamp về miền S16. Helper không biết F_t; rowwise_op hiện xử lý thêm việc đổi scale.''',
    'mul.sv': '''1. A luôn là S16. B được sign-extend nếu signed hoặc zero-extend nếu là gate U16.
2. Tích S33 giữ trường hợp S16×0x8000; `product` chỉ xuất 32 bit thấp vì interface helper cũ.
3. Đường result mở rộng lên S64, RNE theo rshift rồi clamp S16.
4. Gate trên raw 0x8000 bị báo overflow vì ngoài miền 0…1 của U16/F15.
5. Helper không được top instantiate; rowwise_op có đường multiplier/scale hoàn chỉnh hơn.''',
    'fd_reg.sv': '''1. Reset hoặc flush xóa instruction và PC ở phía Decode.
2. Enable bằng 1 chốt instruction/PC từ Fetch sang output tại cùng cạnh clock.
3. Enable bằng 0 giữ output, tạo stall giữa Fetch và Decode.
4. Module thuộc pipeline legacy; scheduler v2 không instantiate nó.''',
    'de_reg.sv': '''1. Module giữ instruction, hai operand 256 bit, PC và control từ Decode sang Execute.
2. Reset/flush xóa data và enable control để instruction bị loại không tạo side effect.
3. Enable chốt toàn bộ payload đồng thời; enable bằng 0 giữ dữ liệu cũ.
4. Các assignment cùng dòng vẫn cập nhật đồng thời. Module không nằm trong hierarchy v2.''',
    'em_reg.sv': '''1. Module chốt ALU result, operand, instruction, PC và control từ Execute sang Memory.
2. Flush/reset đưa control read/write về zero để không phát transaction ngoài ý muốn.
3. Enable bằng 1 truyền payload; enable bằng 0 giữ giá trị.
4. Source hiện dùng payload 256 bit, nhưng top single-issue không dùng stage này.''',
    'mw_reg.sv': '''1. Module giữ memory output, ALU output và control từ Memory sang Write Back.
2. Reset/flush xóa write enable và payload để instruction bị flush không ghi kết quả.
3. Enable chốt mọi trường đồng thời; mux chọn nguồn write-back nằm ngoài module.
4. Đây là pipeline register legacy, không quyết định hành vi core hiện tại.''',
    'ctrl_unit.sv': '''1. Khối đặt control mặc định zero trước case để opcode không khớp không tạo latch/enable ngẫu nhiên.
2. ADD/SUB/MUL/SIG bật đọc/ghi register và chuyển opcode thấp sang `alu_op`.
3. NORM chọn alu_op 111; TMATMUL chỉ bật control register theo interface cũ.
4. LDV/STV/DIV/EXP đặt unsupported. Decoder không chứa REC/RELU/HALT đầy đủ của v2.
5. Matmulfree tự decode bằng scheduler, nên file này chỉ mô tả pipeline lịch sử.''',
    'hazard_detect.sv': '''1. `multicycle_busy` hoặc `memory_busy` đều chặn PC/FD/DE.
2. EM/MW vẫn enable để instruction già hơn thoát pipeline khi stage trẻ dừng.
3. Cùng điều kiện busy đặt `flush_younger`; module không so register ID và không forwarding.
4. V2 chờ từng instruction nên không dùng module này.''',
    'exp.sv': '''1. Input A được giữ để tương thích interface nhưng không tham gia tính toán.
2. Result luôn zero để simulation/synthesis có đầu ra xác định nếu module bị gọi nhầm.
3. Không có ROM, polynomial hay exponential datapath; scheduler từ chối opcode EXP.
4. Greedy argmax không cần softmax không có nghĩa mọi model đều không cần EXP ở operator khác.''',
    'mem_burst.v': '''1. Sau reset, FSM chỉ chạy khi controller báo calibration xong. IDLE ưu tiên read request trước write request.
2. Read có counter address và data riêng vì command/data response không nhất thiết cùng nhịp.
3. Write tách `app_rdy` cho command và `app_wdf_rdy` cho data; upstream nhận `wr_burst_data_req`.
4. State WAIT giữ giao dịch đến khi đủ beat, sau đó phát finish và về IDLE.
5. Đây là adapter FPGA cũ, không phải DDR PHY/controller và không nối vào core hiện tại; address/handshake phải xác nhận lại nếu tái sử dụng.''',
}


GROUP_NOTES = {
    ('npu_pkg.sv', 59): 'Điểm khó của nhóm này là RNE cho số âm. Code không dịch trực tiếp số âm rồi cộng guard; nó làm tròn magnitude unsigned trước, sau đó mới khôi phục dấu để kết quả đối xứng quanh zero.',
    ('norm.sv', 1): 'Mỗi vòng quyết định một bit của căn thông qua biến `one`, nhưng thuật toán biểu diễn bit thử dưới dạng lũy thừa của 4. Vì vậy `one` dịch hai bit mỗi vòng và cần đúng 32 vòng cho radicand U64.',
    ('norm.sv', 362): 'REQ và WAIT tách riêng để phù hợp read-valid của SRAM. P1_PROC chỉ sử dụng `read_buf` đã chốt; không đọc trực tiếp bus SRAM đang thay đổi.',
    ('norm.sv', 428): 'Lượt này vừa sinh scratch vừa đo biên độ. Nếu chỉ ghi z mà không tìm `absmax`, phần cứng sẽ phải đọc scratch thêm một lượt nữa chỉ để chọn scale QUANT.',
    ('norm.sv', 491): 'Một word scratch chứa 8 z S32, còn một word q chứa 32 phần tử S8. Vì vậy P3 tích lũy kết quả qua nhiều word scratch trước khi ghi đủ một word output.',
    ('ternary_mul.sv', 60): 'Đổi dấu phải diễn ra sau khi mở rộng S8 lên S9. Nếu đổi dấu ngay trong S8, trường hợp q = −128 (raw 0x80) và weight = −1 sẽ wrap thay vì cho +128 (S9 raw 0x080).',
    ('rowwise_op.sv', 58): 'REC dùng cả hai multiplier trong cùng một lane. Nó không xử lý hai state song song như MUL, vì hai tích của cùng state phải được cộng trước lần RNE duy nhất.',
    ('scale_compose.sv', 79): 'Giảm candidate r làm hệ số M nhỏ dần để vừa U24. Thuật toán không cắt các bit cao của M vì thao tác đó sẽ làm sai scale mà không báo lỗi.',
    ('sigmoid.sv', 59): 'Phép RNE áp dụng lên toàn tổng `y0×2^24 + difference×fraction`. Nhờ vậy trường hợp tie còn xét parity của y0; làm tròn riêng phần nội suy có thể lệch một LSB.',
    ('sram_256_wrapper.sv', 54): 'Tên gọi “hai chu kỳ” trong tài liệu là hợp đồng request/response nhìn từ client đồng bộ: request được chốt trước, sau đó data/valid mới được quan sát ở response. Không được dùng `rd_data` ngay tại chu kỳ phát `rd_en`.',
    ('div.sv', 25): 'Đây là một bước của restoring division. `q_work` vừa giữ các bit numerator chưa xử lý, vừa dần trở thành quotient khi mỗi bit mới được dịch vào từ phía thấp.',
    ('acc_mul.sv', 12): 'Vòng for thứ hai đi từ node cuối về node gốc để mỗi parent đọc hai child đã được gán. Khi synthesis, đây là cây dây/cổng song song chứ không phải một bộ cộng dùng lặp 31 lần.',
    ('postscale.sv', 15): 'Bias được định nghĩa theo đơn vị output nên phải cộng sau RNE postscale. Đưa bias vào trước phép nhân M sẽ làm bias bị scale lần nữa.',
}


