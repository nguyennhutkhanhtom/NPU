# pipelined_word_ram.sv — Memory technology và response pipeline

> **Chú giải snapshot:** source hash ở trang này đã khác RTL hiện tại.
> Đọc [full graph overview](../full_graph.md) và file source được liên kết bên dưới.
> Sơ đồ/code excerpts được giữ nguyên, chờ đợt cập nhật riêng.

[Tài liệu](../../README.md) → [Source guide](../README.md) → [Mục lục](README.md)

**Source:** [pipelined_word_ram.sv](<../../../Verilog%20Source%20code/pipelined_word_ram.sv>). **Số dòng:** 114. **SHA-256:** `0e82266f6da5f31bd2612e4696778f9560915020f6a5a3b498dfd4acd8b6e07a`.

## Khối này làm gì?

USE_QUARTUS_MEMORY chọn altsyncram cho toàn bank hoặc model SRAM portable chia tile. Hai backend có cùng throughput một read/write mỗi clock; read ba cạnh khi ROWS≤4096, bốn cạnh nếu lớn hơn; write commit cạnh thứ hai. Reset hủy enables/valid và queued write, giữ nội dung và payload. OLD_DATA collision theo request nhận cùng cạnh.

## Sơ đồ kiến trúc

```mermaid
flowchart TB
    REQ[Read and write requests] --> CAP[Registered addresses data enables]
    CAP --> IP[FPGA altsyncram whole bank]
    CAP --> MODEL[ASIC behavioral tiled SRAM model]
    IP --> RESPONSE[Registered response]
    MODEL --> RESPONSE
    RESPONSE --> FINAL[Optional extra edge for rows above 4096]
    FINAL --> DATA[Identical data valid contract]
    CAP --> VALID[Read and write validity pipeline]
```

## Cách hoạt động chi tiết

USE_QUARTUS_MEMORY chọn altsyncram cho toàn bank hoặc model SRAM portable chia tile. Hai backend có cùng throughput một read/write mỗi clock; read ba cạnh khi ROWS≤4096, bốn cạnh nếu lớn hơn; write commit cạnh thứ hai. Reset hủy enables/valid và queued write, giữ nội dung và payload. OLD_DATA collision theo request nhận cùng cạnh.

## Các nhóm logic trong source

### [Dòng 1–32: Interface and pipeline control](<../../../Verilog%20Source%20code/pipelined_word_ram.sv#L1>)

<!-- source-range:1:32 -->
```systemverilog
// Replaceable SRAM adapter: tile requests, leaf read, grouped response.
// Read latency is three edges (<=4 tiles), otherwise four. Throughput 1/cycle.
// Writes execute one edge after request capture; same-cycle collision is old-data.
module pipelined_word_ram #(
    parameter int WIDTH = 32,
    parameter int ROWS = 4096,
    parameter int ADDR_W = $clog2(ROWS),
    parameter bit USE_QUARTUS_MEMORY = 0
) (
    input logic clk, rst_n, rd_en, wr_en,
    input logic [ADDR_W - 1:0] rd_addr, wr_addr,
    input logic [WIDTH - 1:0] wr_data,
    output logic [WIDTH - 1:0] rd_data,
    output logic rd_valid, wr_valid
);
    localparam int TILES = (ROWS + 1023) / 1024;
    localparam int GROUPS = (TILES + 3) / 4;
    logic [WIDTH - 1:0] tile_data [0:TILES - 1];
    logic [TILES - 1:0] read_tile_q;
    logic [WIDTH - 1:0] group_data_q [0:GROUPS - 1];
    logic [3:0] read_valid_q;
    logic write_pending_q;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin read_valid_q <= 0; write_pending_q <= 0; wr_valid <= 0; end
        else begin
            read_valid_q <= {read_valid_q[2:0], rd_en};
            write_pending_q <= wr_en;
            wr_valid <= write_pending_q;
        end
    end
    genvar tile, group_id;
    generate
```

Valid phải đi cùng dữ liệu. wr_valid xuất hiện khi leaf write thực thi; storage/payload không reset.

### [Dòng 33–59: FPGA memory IP backend](<../../../Verilog%20Source%20code/pipelined_word_ram.sv#L33>)

<!-- source-range:33:59 -->
```systemverilog
    if (USE_QUARTUS_MEMORY) begin : g_ip
        logic [ADDR_W - 1:0] read_address_q, write_address_q;
        (* dont_merge *) logic [WIDTH - 1:0] write_data_q;
        logic [WIDTH - 1:0] raw_data, response_q;
        (* dont_merge *) logic read_enable_q, write_enable_q;
        always_ff @(posedge clk) begin
            read_address_q <= rd_addr; write_address_q <= wr_addr;
            write_data_q <= wr_data;
            if (rst_n && read_valid_q[1]) response_q <= raw_data;
        end
        always_ff @(posedge clk or negedge rst_n)
            if (!rst_n) begin read_enable_q <= 0; write_enable_q <= 0; end
            else begin read_enable_q <= rd_en; write_enable_q <= wr_en; end
        quartus_word_ram #(.WIDTH(WIDTH), .ROWS(ROWS), .ADDR_W(ADDR_W)) u_storage(
            .clk(clk), .rd_en(rst_n && read_enable_q), .wr_en(rst_n && write_enable_q),
            .rd_addr(read_address_q), .wr_addr(write_address_q), .wr_data(write_data_q),
            .rd_data(raw_data));
        if (GROUPS == 1) begin : g_short
            assign rd_data = response_q;
            assign rd_valid = read_valid_q[2];
        end else begin : g_long
            always_ff @(posedge clk)
                if (rst_n && read_valid_q[2]) rd_data <= response_q;
            assign rd_valid = read_valid_q[3];
        end
    end else begin : g_model
    for (tile = 0; tile < TILES; tile = tile + 1) begin : g_tile
```

Một altsyncram toàn bank, không tạo decoder/mux tile trong compute RTL. Request E1, raw read/write E2, response E3; bank lớn thêm E4. Queued write bị hủy khi reset trước E2.

### [Dòng 60–114: Portable ASIC behavior model](<../../../Verilog%20Source%20code/pipelined_word_ram.sv#L60>)

<!-- source-range:60:114 -->
```systemverilog
        localparam int TILE_ROWS = (ROWS - tile * 1024 < 1024) ? ROWS - tile * 1024 : 1024;
        (* dont_merge *) logic [9:0] read_address_q, write_address_q;
        logic [WIDTH - 1:0] write_data_q;
        logic read_enable_q, write_enable_q;
        always_ff @(posedge clk) begin
            // Unconditional payload capture avoids address feedback/enable muxes.
            read_address_q <= 10'(rd_addr);
            write_address_q <= 10'(wr_addr);
            write_data_q <= wr_data;
        end
        always_ff @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin read_enable_q <= 0; write_enable_q <= 0; read_tile_q[tile] <= 0; end
            else begin
                read_enable_q <= rd_en && (rd_addr >> 10) == tile;
                write_enable_q <= wr_en && (wr_addr >> 10) == tile;
                read_tile_q[tile] <= read_enable_q;
            end
        end
        sram_word_tile #(.WIDTH(WIDTH), .ROWS(TILE_ROWS)) u_tile(
            .clk(clk), .rd_en(rst_n && read_enable_q), .wr_en(rst_n && write_enable_q),
            .rd_addr(read_address_q), .wr_addr(write_address_q), .wr_data(write_data_q),
            .rd_data(tile_data[tile]));
    end
    for (group_id = 0; group_id < GROUPS; group_id = group_id + 1) begin : g_response
        logic [WIDTH - 1:0] selected;
        always_comb begin
            selected = 0;
            // Four static mux inputs per group; local bounded reduction.
            for (int member = 0; member < 4; member = member + 1)
                if (group_id * 4 + member < TILES)
                    selected = selected | (tile_data[group_id * 4 + member] &
                        {WIDTH{read_tile_q[group_id * 4 + member]}});
        end
        always_ff @(posedge clk)
            if (rst_n && read_valid_q[1]) group_data_q[group_id] <= selected;
    end
    if (GROUPS == 1) begin : g_single_response
        assign rd_data = group_data_q[0];
        assign rd_valid = read_valid_q[2];
    end else begin : g_final_response
        logic [WIDTH - 1:0] selected;
        wire [WIDTH - 1:0] response_mux [0:GROUPS];
        genvar response_group;
        assign response_mux[0] = '0;
        for (response_group = 0; response_group < GROUPS; response_group = response_group + 1) begin : g_mux
            assign response_mux[response_group + 1] = response_mux[response_group] | group_data_q[response_group];
        end
        assign selected = response_mux[GROUPS];
        always_ff @(posedge clk)
            if (rst_n && read_valid_q[2]) rd_data <= selected;
        assign rd_valid = read_valid_q[3];
    end
    end
    endgenerate
endmodule
```

Model chia tile 1024 word để giữ contract trước khi có macro ASIC. dont_merge chỉ trong model boundary; grouped response giữ cùng latency với IP.
