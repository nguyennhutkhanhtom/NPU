// One synchronous read port and one lane-masked write port.
// The controller arbitrates clients; RAM contents and data outputs are unreset.
module llm_bank_ram #(
    parameter int LANES = 32,
    parameter int WIDTH = 24,
    parameter int ROWS = 4096,
    parameter int ADDR_W = $clog2(ROWS)
) (
    input logic clk, rst_n, rd_en,
    input logic [ADDR_W - 1:0] rd_addr,
    output logic [LANES * WIDTH - 1:0] rd_data,
    output logic rd_valid,
    input logic [ADDR_W - 1:0] wr_addr,
    input logic [LANES - 1:0] wr_mask,
    input logic [LANES * WIDTH - 1:0] wr_data
);
    genvar lane;
    generate
    for (lane = 0; lane < LANES; lane = lane + 1) begin : g_bank
        banked_word_ram #(.WIDTH(WIDTH), .ROWS(ROWS), .ADDR_W(ADDR_W)) u_storage(
            .clk(clk), .rd_en(rd_en), .wr_en(rst_n && wr_mask[lane]),
            .rd_addr(rd_addr), .wr_addr(wr_addr), .wr_data(wr_data[lane * WIDTH +: WIDTH]),
            .rd_data(rd_data[lane * WIDTH +: WIDTH]));
    end
    endgenerate
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) rd_valid <= 0;
        else rd_valid <= rd_en;
    end
endmodule
