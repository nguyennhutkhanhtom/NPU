// Autonomous fixed-point NanoFable inference. The host loads parameters and
// prompt IDs; this controller owns prefill, attention, head and decode.
module llm_soc (
    input logic clk, rst_n, host_en, host_we,
    input logic [31:0] host_addr, host_wdata,
    output logic [31:0] host_rdata,
    output logic host_ready, running, ready, error, overflow_out,
    output logic [8:0] pc_debug,
    output logic [12:0] instr_debug
);
    import npu_pkg::*;
    import llm_pkg::*;
    typedef enum logic [4:0] {G_IDLE, G_EMBED, G_ANORM, G_Q, G_K, G_V,
        G_RQ, G_RK, G_CACHE, G_ATTENTION, G_O, G_AADD, G_MNORM, G_GATE,
        G_UP, G_SILU, G_GMUL, G_DOWN, G_MADD, G_NEXT, G_FNORM, G_HEAD,
        G_ADVANCE, G_DONE} graph_t;
    graph_t graph;
    typedef enum logic [6:0] {O_IDLE, O_P_REQ, O_P_WAIT, O_V_REQ, O_V_WAIT,
        O_K_REQ, O_K_WAIT, O_M_START, O_M_WAIT, O_WRITE, O_FINISH,
        E_SCALE, E_DATA, E_CALC, E_PACK,
        L_META, L_WEIGHT, L_INPUT, L_MAC, L_COEFF, L_ROUND, L_STORE,
        N_SQUARE, N_ACC, N_ROOT, N_ROOT_WAIT, N_DIV, N_DIV_WAIT,
        N_GAIN0, N_GAIN1, N_INPUT, N_RECIP, N_GAIN, N_PACK,
        R_TABLE0, R_TABLE1, R_INPUT, R_COS, R_SIN, R_PACK,
        C_INPUT, C_STORE,
        A_QUERY, A_KEY, A_DOT, A_SCALE, A_SCORE, A_NEXT_SCORE,
        A_EXP_READ, A_EXP_PREP, A_EXP_MUL, A_EXP_STORE,
        A_VALUE, A_WEIGHT, A_ACC, A_DIV, A_DIV_WAIT, A_LANE, A_PACK,
        B_INPUT0, B_INPUT1, B_CALC, B_PACK,
        S_INPUT, S_SIG, S_SIG_WAIT, S_MUL, S_PACK,
        H_SCALE, H_WEIGHT, H_INPUT, H_MAC, H_COEFF, H_ROUND, H_NOISE, H_SAMPLE, H_SELECT
    } op_t;
    op_t op, return_p, return_v, return_k, return_m, return_w;
    logic op_done, launch, core_running, op_fault_q;
    logic [1:0] layer_q, head_q;
    logic [6:0] position_q, time_q;
    logic [7:0] prompt_count_q, max_new_q, generated_q;
    logic [7:0] temperature_q, min_new_q;
    logic [31:0] seed_q, random_q;
    logic signed [32:0] noise_product_q;
    logic signed [63:0] sampled_score_q;
    logic [11:0] token_q, best_token_q, vocabulary_row_q;
    logic [11:0] prompt_memory [0:127], output_memory [0:127];
    logic [3:0] row_q, chunk_q;
    logic [4:0] lane_q;
    logic [2:0] source_q, destination_q;
    logic [9:0] matrix_row_q, matrix_rows_q;
    logic [3:0] matrix_chunks_q;
    logic [14:0] weight_row_q;
    logic [23:0] coefficient_q;
    logic [255:0] parameter_word_q, weights_q;
    logic [511:0] table_q;
    logic [767:0] vector_q, second_q, write_vector_q, query_q;
    logic [6:0] write_vector_addr_q;
    logic [31:0] write_vector_mask_q;
    logic signed [38:0] linear_acc_q;
    logic signed [63:0] scalar_product_q, scalar_round_q;
    logic [63:0] square_sum_q, root_input_q;
    logic [31:0] reciprocal_q;
    logic signed [55:0] rotation_cos_q [0:31];
    logic signed [55:0] attention_acc_q [0:31];
    logic signed [31:0] score_memory [0:127], max_score_q, best_score_q;
    logic [24:0] probability_memory [0:127], exp_hi_q, exp_lo_q, probability_q;
    logic [31:0] probability_sum_q;
    logic [32:0] exp_difference_q;
    logic [36:0] exp_interpolation_q;
    logic divide_negative_q;

    // Registered host transactions. Hold address/data until ready, then deassert
    // host_en for at least one clock before issuing another transaction.
    typedef enum logic [2:0] {H_IDLE, H_EXEC, H_READ, H_WAIT, H_DONE} host_t;
    host_t host_state;
    logic [31:0] host_address_q, host_data_q;
    logic host_write_q, host_parameter_q;
    logic [14:0] p_address_q;
    logic p_read, p_valid, p_host_valid;
    logic [255:0] p_data;
    logic [31:0] p_host_data;
    sram_256_wrapper #(.ADDR_W(15), .DEPTH(PARAM_ROWS)) u_parameters(
        .clk(clk), .rst_n(rst_n), .rd_en(p_read), .rd_addr(p_address_q),
        .rd_data(p_data), .rd_valid(p_valid), .wr_en(1'b0), .wr_addr('0), .wr_data('0),
        .host_en(host_en && !core_running && host_parameter_q &&
            ((host_state == H_EXEC && host_write_q) || host_state == H_READ || host_state == H_WAIT)),
        .host_we(host_write_q), .host_addr(host_address_q[19:2]),
        .host_wdata(host_data_q), .host_rdata(p_host_data), .host_rvalid(p_host_valid));
    assign p_read = op == O_P_REQ;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            host_state <= H_IDLE;
            host_ready <= 0;
            host_rdata <= 0;
            launch <= 0;
            prompt_count_q <= 0;
            max_new_q <= 96;
            temperature_q <= 166;
            min_new_q <= 64;
            seed_q <= 32'd1;
            host_parameter_q <= 0;
            host_write_q <= 0;
            host_address_q <= 0;
            host_data_q <= 0;
        end else begin
            launch <= 0;
            if (!host_en) begin host_state <= H_IDLE; host_ready <= 0; end
            else case (host_state)
                H_IDLE : begin
                    host_address_q <= host_addr;
                    host_data_q <= host_wdata;
                    host_write_q <= host_we;
                    host_parameter_q <= host_addr < 32'h000c0000 && host_addr[1:0] == 0;
                    host_state <= H_EXEC;
                end
                H_EXEC : begin
                    host_rdata <= 0;
                    if (host_address_q[1:0] != 0) host_state <= H_DONE;
                    else if (host_write_q) begin
                        if (!core_running) begin
                            if (host_address_q[31:9] == 23'h800)
                                prompt_memory[host_address_q[8:2]] <= host_data_q[11:0];
                            if (host_address_q[31:5] == 27'h0020000)
                                case (host_address_q[4:2])
                                    3'd1 : prompt_count_q <= host_data_q[7:0];
                                    3'd2 : max_new_q <= host_data_q[7:0];
                                    3'd3 : launch <= host_data_q[0];
                                    3'd4 : temperature_q <= host_data_q[7:0];
                                    3'd5 : seed_q <= host_data_q == 0 ? 32'd1 : host_data_q;
                                    3'd6 : min_new_q <= host_data_q[7:0];
                                    default : ;
                                endcase
                        end
                        host_state <= H_DONE;
                    end else if (host_parameter_q && !core_running) host_state <= H_READ;
                    else begin
                        if (host_address_q == 32'h00400000)
                            host_rdata <= {20'h0, generated_q, overflow_out, error, ready, running};
                        else if (host_address_q[31:9] == 23'h1000 && !core_running)
                            host_rdata <= {20'h0, output_memory[host_address_q[8:2]]};
                        host_state <= H_DONE;
                    end
                end
                H_READ : host_state <= H_WAIT;
                H_WAIT : if (p_host_valid) begin host_rdata <= p_host_data; host_state <= H_DONE; end
                H_DONE : host_ready <= 1;
                default : host_state <= H_IDLE;
            endcase
        end
    end

    logic v_read, v_valid;
    logic [6:0] v_address_q;
    logic [767:0] v_data;
    llm_bank_ram #(.ROWS(96), .ADDR_W(7)) u_vectors(
        .clk(clk), .rst_n(rst_n), .rd_en(v_read), .rd_addr(v_address_q),
        .rd_data(v_data), .rd_valid(v_valid), .wr_addr(write_vector_addr_q),
        .wr_mask(op == O_WRITE ? write_vector_mask_q : 32'h0), .wr_data(write_vector_q));
    assign v_read = op == O_V_REQ;
    logic k_read, k_valid;
    logic [11:0] k_address_q, k_write_address_q;
    logic [767:0] k_data;
    // Address = layer*1024 + position*8 + K/V*4 + head.
    llm_bank_ram u_cache(
        .clk(clk), .rst_n(rst_n), .rd_en(k_read), .rd_addr(k_address_q),
        .rd_data(k_data), .rd_valid(k_valid), .wr_addr(k_write_address_q),
        .wr_mask(op == C_STORE ? 32'hffffffff : 32'h0), .wr_data(vector_q));
    assign k_read = op == O_K_REQ;

    logic math_start, math_busy, math_done;
    logic signed [23:0] math_a_q [0:31];
    logic signed [31:0] math_b_q [0:31];
    logic signed [55:0] math_product [0:31];
    logic signed [60:0] math_sum;
    llm_math u_math(.clk(clk), .rst_n(rst_n), .start(math_start),
        .a(math_a_q), .b(math_b_q), .busy(math_busy), .done(math_done),
        .product(math_product), .sum(math_sum));
    assign math_start = op == O_M_START;
    logic root_busy, root_done;
    logic [31:0] root;
    isqrt_u64 u_root(.clk(clk), .rst_n(rst_n), .start(op == N_ROOT),
        .radicand(root_input_q), .busy(root_busy), .done(root_done), .root(root));
    logic div_busy, div_done, div_zero;
    logic [63:0] div_numerator_q, div_quotient;
    logic [31:0] div_denominator_q, div_remainder;
    logic [32:0] twice_remainder;
    logic divide_round_up;
    div #(.NUM_W(64), .DEN_W(32)) u_div(.clk(clk), .rst_n(rst_n),
        .start(op == N_DIV || op == A_DIV), .numerator(div_numerator_q),
        .denominator(div_denominator_q), .busy(div_busy), .done(div_done),
        .div_zero(div_zero), .quotient(div_quotient), .remainder(div_remainder));
    assign twice_remainder = {div_remainder, 1'b0};
    assign divide_round_up = twice_remainder > {1'b0, div_denominator_q} ||
        (twice_remainder == {1'b0, div_denominator_q} && div_quotient[0]);
    logic sig_busy, sig_done;
    logic signed [15:0] sig_x_q;
    logic [15:0] sig_y;
    logic [15:0] sigmoid_values_q [0:31];
    sigmoid u_sig(.clk(clk), .rst_n(rst_n), .start(op == S_SIG),
        .x_raw(sig_x_q), .frac_bits(5'd12), .busy(sig_busy), .done(sig_done), .y_raw(sig_y));
    assign core_running = graph != G_IDLE;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin running <= 0; ready <= 1; pc_debug <= 0; instr_debug <= 0; end
        else begin
            running <= core_running; ready <= !core_running;
            pc_debug <= {2'b0, position_q}; instr_debug <= {1'b0, graph, op};
        end
    end

    // Request helpers set registered addresses before the corresponding enable.
    task automatic read_parameter(input logic [14:0] address, input op_t next_op);
        p_address_q <= address; return_p <= next_op; op <= O_P_REQ;
    endtask
    task automatic read_vector(input logic [2:0] buffer_id, input logic [3:0] row_id,
                               input op_t next_op);
        v_address_q <= 7'(buffer_id * 12 + row_id); return_v <= next_op; op <= O_V_REQ;
    endtask
    task automatic read_cache(input logic [11:0] address, input op_t next_op);
        k_address_q <= address; return_k <= next_op; op <= O_K_REQ;
    endtask
    task automatic run_math(input op_t next_op);
        return_m <= next_op; op <= O_M_START;
    endtask
    task automatic write_vector(input logic [2:0] buffer_id, input logic [3:0] row_id,
                                input logic [31:0] mask, input op_t next_op);
        write_vector_addr_q <= 7'(buffer_id * 12 + row_id);
        write_vector_mask_q <= mask; return_w <= next_op; op <= O_WRITE;
    endtask
    function automatic logic [14:0] matrix_meta(input logic [1:0] layer_id, input logic [2:0] matrix_id);
        matrix_meta = 15'(MATRIX_META_BASE + layer_id * 7 + matrix_id);
    endfunction
    function automatic logic [14:0] gain_address(input graph_t phase, input logic [1:0] layer_id,
                                                input logic [3:0] row_id);
        if (phase == G_FNORM) gain_address = 15'(GAIN_BASE + 64 + row_id * 2);
        else gain_address = 15'(GAIN_BASE + layer_id * 16 + (phase == G_MNORM ? 8 : 0) + row_id * 2);
    endfunction

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            graph <= G_IDLE; layer_q <= 0; position_q <= 0; generated_q <= 0;
            token_q <= 0; error <= 0;
        end else begin
            if (graph == G_IDLE && launch) begin
                error <= 0; layer_q <= 0; position_q <= 0; generated_q <= 0;
                token_q <= prompt_memory[0];
                if (prompt_count_q == 0 || max_new_q == 0 ||
                    {1'b0, prompt_count_q} + {1'b0, max_new_q} > 128) error <= 1;
                else graph <= G_EMBED;
            end else if (op_fault_q && core_running && graph != G_DONE) begin graph <= G_DONE; error <= 1; end
            else if (op_done) begin
                case (graph)
                    G_EMBED : graph <= G_ANORM;
                    G_ANORM : graph <= G_Q;
                    G_Q : graph <= G_K;
                    G_K : graph <= G_V;
                    G_V : graph <= G_RQ;
                    G_RQ : graph <= G_RK;
                    G_RK : graph <= G_CACHE;
                    G_CACHE : graph <= G_ATTENTION;
                    G_ATTENTION : graph <= G_O;
                    G_O : graph <= G_AADD;
                    G_AADD : graph <= G_MNORM;
                    G_MNORM : graph <= G_GATE;
                    G_GATE : graph <= G_UP;
                    G_UP : graph <= G_SILU;
                    G_SILU : graph <= G_GMUL;
                    G_GMUL : graph <= G_DOWN;
                    G_DOWN : graph <= G_MADD;
                    G_MADD : graph <= G_NEXT;
                    G_FNORM : graph <= G_HEAD;
                    G_HEAD : graph <= G_ADVANCE;
                    default : ;
                endcase
            end else case (graph)
                G_NEXT : begin
                    if (layer_q != 3) begin layer_q <= layer_q + 1'b1; graph <= G_ANORM; end
                    else if ({1'b0, position_q} + 1 < prompt_count_q) begin
                        position_q <= position_q + 1'b1; token_q <= prompt_memory[position_q + 1'b1];
                        layer_q <= 0; graph <= G_EMBED;
                    end else graph <= G_FNORM;
                end
                G_ADVANCE : begin
                    output_memory[generated_q[6:0]] <= best_token_q;
                    generated_q <= generated_q + 1'b1;
                    if (generated_q + 1 >= max_new_q || best_token_q == 12'd1 || position_q == 127)
                        graph <= G_DONE;
                    else begin
                        token_q <= best_token_q; position_q <= position_q + 1'b1;
                        layer_q <= 0; graph <= G_EMBED;
                    end
                end
                G_DONE : graph <= G_IDLE;
                default : ;
            endcase
        end
    end

    // Independent lane registers keep constant slice boundaries visible to
    // synthesis. The FSM carries enables and addresses, while each lane owns
    // its arithmetic payload and its portion of the workspace write bus.
    genvar lane;
    generate
    for (lane = 0; lane < 32; lane = lane + 1) begin : g_simd
        always_ff @(posedge clk) begin
            if (rst_n) begin
                case (op)
                    E_DATA : begin
                        math_a_q[lane] <= 24'($signed(parameter_word_q[lane * 8 +: 8]));
                        math_b_q[lane] <= {8'h0, coefficient_q};
                    end
                    E_CALC : write_vector_q[lane * 24 +: 24] <=
                        llm_sat24(rne_shift64(llm_extend56(math_product[lane]), 6'd8));
                    L_INPUT : begin
                        math_a_q[lane] <= vector_q[lane * 24 +: 24];
                        case (weights_q[chunk_q[1:0] * 64 + lane * 2 +: 2])
                            2'b01 : math_b_q[lane] <= 1;
                            2'b11 : math_b_q[lane] <= -32'sd1;
                            default : math_b_q[lane] <= 0;
                        endcase
                    end
                    L_STORE : write_vector_q[lane * 24 +: 24] <= llm_sat24(scalar_round_q);
                    N_SQUARE : begin
                        math_a_q[lane] <= vector_q[lane * 24 +: 24];
                        math_b_q[lane] <= 32'($signed(vector_q[lane * 24 +: 24]));
                    end
                    N_INPUT : begin
                        math_a_q[lane] <= vector_q[lane * 24 +: 24]; math_b_q[lane] <= reciprocal_q;
                    end
                    N_RECIP : begin
                        math_a_q[lane] <= llm_sat24(rne_shift64(llm_extend56(math_product[lane]), 6'd16));
                        math_b_q[lane] <= 32'($signed(table_q[lane * 16 +: 16]));
                    end
                    N_GAIN : write_vector_q[lane * 24 +: 24] <=
                        llm_sat24(rne_shift64(llm_extend56(math_product[lane]), 6'd12));
                    R_INPUT : begin
                        math_a_q[lane] <= vector_q[lane * 24 +: 24];
                        math_b_q[lane] <= 32'($signed(table_q[(lane % 16) * 32 +: 16]));
                    end
                    R_COS : begin
                        rotation_cos_q[lane] <= math_product[lane];
                        math_a_q[lane] <= vector_q[((lane + 16) % 32) * 24 +: 24];
                        math_b_q[lane] <= lane < 16 ?
                            -$signed(32'($signed(table_q[(lane % 16) * 32 + 16 +: 16]))) :
                            32'($signed(table_q[(lane % 16) * 32 + 16 +: 16]));
                    end
                    R_SIN : write_vector_q[lane * 24 +: 24] <= llm_sat24(rne_shift64(
                        llm_extend56(rotation_cos_q[lane]) + llm_extend56(math_product[lane]), 6'd15));
                    A_KEY : begin
                        math_a_q[lane] <= query_q[lane * 24 +: 24];
                        math_b_q[lane] <= 32'($signed(second_q[lane * 24 +: 24]));
                    end
                    A_EXP_STORE : if (time_q == position_q) attention_acc_q[lane] <= 0;
                    A_WEIGHT : begin
                        math_a_q[lane] <= second_q[lane * 24 +: 24]; math_b_q[lane] <= {7'h0, probability_q};
                    end
                    A_ACC : attention_acc_q[lane] <= attention_acc_q[lane] + math_product[lane];
                    A_PACK : if (lane_q == 5'(lane)) write_vector_q[lane * 24 +: 24] <= llm_sat24(scalar_round_q);
                    B_INPUT1 : begin
                        if (graph == G_GMUL) begin
                            math_a_q[lane] <= second_q[lane * 24 +: 24];
                            math_b_q[lane] <= 32'($signed(vector_q[lane * 24 +: 24]));
                        end else write_vector_q[lane * 24 +: 24] <= llm_sat24(
                            64'($signed(second_q[lane * 24 +: 24])) + 64'($signed(vector_q[lane * 24 +: 24])));
                    end
                    B_CALC : write_vector_q[lane * 24 +: 24] <=
                        llm_sat24(rne_shift64(llm_extend56(math_product[lane]), 6'd16));
                    S_SIG_WAIT : if (sig_done && lane_q == 5'(lane)) sigmoid_values_q[lane] <= sig_y;
                    S_MUL : begin
                        math_a_q[lane] <= vector_q[lane * 24 +: 24];
                        math_b_q[lane] <= {16'h0, sigmoid_values_q[lane]};
                    end
                    S_PACK : write_vector_q[lane * 24 +: 24] <=
                        llm_sat24(rne_shift64(llm_extend56(math_product[lane]), 6'd15));
                    H_INPUT : begin
                        math_a_q[lane] <= vector_q[lane * 24 +: 24];
                        math_b_q[lane] <= 32'($signed(weights_q[lane * 8 +: 8]));
                    end
                    default : ;
                endcase
            end
        end
    end
    endgenerate

    // Payloads are assigned before their operation consumes them. Reset only
    // cancels the operation pipeline and clears architectural status.
    always_ff @(posedge clk) begin
        if (rst_n) begin
            op_done <= 0;
            if (launch && graph == G_IDLE) begin overflow_out <= 0; random_q <= seed_q; op_fault_q <= 0; end
            case (op)
                O_IDLE : if (core_running && !op_done) begin
                    row_q <= 0; chunk_q <= 0; head_q <= 0; time_q <= 0; lane_q <= 0;
                    source_q <= 1; destination_q <= 1; linear_acc_q <= 0;
                    case (graph)
                        G_EMBED : read_parameter(15'(EMB_SCALE_BASE + (token_q >> 3)), E_SCALE);
                        G_ANORM, G_MNORM, G_FNORM : begin
                            square_sum_q <= 0; read_vector(0, 0, N_SQUARE);
                        end
                        G_Q : begin destination_q <= 2; read_parameter(matrix_meta(layer_q, 0), L_META); end
                        G_K : begin destination_q <= 3; read_parameter(matrix_meta(layer_q, 1), L_META); end
                        G_V : begin destination_q <= 4; read_parameter(matrix_meta(layer_q, 2), L_META); end
                        G_O : begin source_q <= 5; read_parameter(matrix_meta(layer_q, 3), L_META); end
                        G_GATE : begin destination_q <= 6; read_parameter(matrix_meta(layer_q, 4), L_META); end
                        G_UP : begin destination_q <= 7; read_parameter(matrix_meta(layer_q, 5), L_META); end
                        G_DOWN : begin source_q <= 6; read_parameter(matrix_meta(layer_q, 6), L_META); end
                        G_RQ, G_RK : begin
                            source_q <= graph == G_RQ ? 3'd2 : 3'd3;
                            read_parameter(15'(ROPE_BASE + position_q * 2), R_TABLE0);
                        end
                        G_CACHE : read_vector(3, 0, C_INPUT);
                        G_ATTENTION : begin
                            max_score_q <= 32'sh80000000; probability_sum_q <= 0;
                            read_vector(2, 0, A_QUERY);
                        end
                        G_AADD, G_MADD : read_vector(0, 0, B_INPUT0);
                        G_GMUL : begin source_q <= 6; read_vector(6, 0, B_INPUT0); end
                        G_SILU : read_vector(6, 0, S_INPUT);
                        G_HEAD : begin
                            vocabulary_row_q <= 0; best_score_q <= 32'sh80000000; best_token_q <= 0;
                            read_parameter(15'(EMB_SCALE_BASE), H_SCALE);
                        end
                        default : ;
                    endcase
                end
                O_P_REQ : op <= O_P_WAIT;
                O_P_WAIT : if (p_valid) begin parameter_word_q <= p_data; op <= return_p; end
                O_V_REQ : op <= O_V_WAIT;
                O_V_WAIT : if (v_valid) begin vector_q <= v_data; op <= return_v; end
                O_K_REQ : op <= O_K_WAIT;
                O_K_WAIT : if (k_valid) begin second_q <= k_data; op <= return_k; end
                O_M_START : op <= O_M_WAIT;
                O_M_WAIT : if (math_done) op <= return_m;
                O_WRITE : op <= return_w;
                O_FINISH : begin op_done <= 1; op <= O_IDLE; end
                E_SCALE : begin
                    coefficient_q <= parameter_word_q[token_q[2:0] * 32 +: 24];
                    read_parameter({1'b0, token_q, 2'b00}, E_DATA);
                end
                E_DATA : begin
                    run_math(E_CALC);
                end
                E_CALC : begin
                    write_vector(0, row_q, 32'hffffffff, E_PACK);
                end
                E_PACK : if (row_q == 3) op <= O_FINISH;
                    else begin row_q <= row_q + 1'b1; read_parameter(15'(token_q * 4 + row_q + 1), E_DATA); end
                L_META : begin
                    weight_row_q <= parameter_word_q[14:0];
                    matrix_chunks_q <= parameter_word_q[23:20]; // K/32; validated K is 128 or 384.
                    matrix_rows_q <= parameter_word_q[34:25];
                    coefficient_q <= parameter_word_q[58:35]; matrix_row_q <= 0;
                    read_parameter(parameter_word_q[14:0], L_WEIGHT);
                    if (parameter_word_q[24:15] != (graph == G_DOWN ? 10'd384 : 10'd128) ||
                        parameter_word_q[34:25] != ((graph == G_GATE || graph == G_UP) ? 10'd384 : 10'd128) ||
                        parameter_word_q[58:35] == 0 || parameter_word_q[255:59] != 0 ||
                        parameter_word_q[14:0] < 16384 ||
                        16'(parameter_word_q[14:0]) +
                            ((graph == G_GATE || graph == G_UP || graph == G_DOWN) ? 16'd384 : 16'd128) > 23040) begin
                        op_fault_q <= 1; op <= O_FINISH;
                    end
                end
                L_WEIGHT : begin weights_q <= parameter_word_q; read_vector(source_q, chunk_q, L_INPUT); end
                L_INPUT : begin
                    run_math(L_MAC);
                end
                L_MAC : begin
                    linear_acc_q <= linear_acc_q + math_sum[38:0];
                    if (chunk_q + 1 >= matrix_chunks_q) op <= L_COEFF;
                    else begin
                        chunk_q <= chunk_q + 1'b1;
                        if (chunk_q[1:0] == 3) read_parameter(weight_row_q + 15'((chunk_q + 1) >> 2), L_WEIGHT);
                        else read_vector(source_q, chunk_q + 1'b1, L_INPUT);
                    end
                end
                L_COEFF : begin scalar_product_q <= linear_acc_q * $signed({1'b0, coefficient_q}); op <= L_ROUND; end
                L_ROUND : begin scalar_round_q <= rne_shift64(scalar_product_q, 6'd24); op <= L_STORE; end
                L_STORE : begin
                    if (scalar_round_q > 8388607 || scalar_round_q < -8388608) overflow_out <= 1;
                    write_vector(destination_q, matrix_row_q[8:5], 32'b1 << matrix_row_q[4:0], E_PACK);
                    // E_PACK is replaced here by the row-specific continuation.
                    return_w <= L_META; op <= O_WRITE;
                    if (matrix_row_q + 1 >= matrix_rows_q) return_w <= O_FINISH;
                    else begin
                        matrix_row_q <= matrix_row_q + 1'b1; chunk_q <= 0; linear_acc_q <= 0;
                        weight_row_q <= weight_row_q + 15'((matrix_chunks_q + 3) >> 2);
                        return_w <= L_WEIGHT;
                        p_address_q <= weight_row_q + 15'((matrix_chunks_q + 3) >> 2);
                        return_p <= L_WEIGHT; return_w <= O_P_REQ;
                    end
                end
                N_SQUARE : begin
                    run_math(N_ACC);
                end
                N_ACC : begin
                    square_sum_q <= square_sum_q + 64'(math_sum);
                    if (row_q == 3) begin
                        root_input_q <= ((square_sum_q + 64'(math_sum)) >> 7) + 64'd42950; op <= N_ROOT;
                    end else begin row_q <= row_q + 1'b1; read_vector(0, row_q + 1'b1, N_SQUARE); end
                end
                N_ROOT : op <= N_ROOT_WAIT;
                N_ROOT_WAIT : if (root_done) begin
                    div_numerator_q <= 64'h0000000100000000; div_denominator_q <= root; op <= N_DIV;
                end
                N_DIV : op <= N_DIV_WAIT;
                N_DIV_WAIT : if (div_done) begin
                    reciprocal_q <= div_quotient[31:0] + {31'h0, divide_round_up}; row_q <= 0;
                    read_parameter(gain_address(graph, layer_q, 0), N_GAIN0);
                end
                N_GAIN0 : begin table_q[255:0] <= parameter_word_q; read_parameter(p_address_q + 1'b1, N_GAIN1); end
                N_GAIN1 : begin table_q[511:256] <= parameter_word_q; read_vector(0, row_q, N_INPUT); end
                N_INPUT : begin
                    run_math(N_RECIP);
                end
                N_RECIP : begin
                    run_math(N_GAIN);
                end
                N_GAIN : begin
                    write_vector(1, row_q, 32'hffffffff, N_PACK);
                end
                N_PACK : if (row_q == 3) op <= O_FINISH;
                    else begin row_q <= row_q + 1'b1; read_parameter(gain_address(graph, layer_q, row_q + 1'b1), N_GAIN0); end
                R_TABLE0 : begin table_q[255:0] <= parameter_word_q; read_parameter(p_address_q + 1'b1, R_TABLE1); end
                R_TABLE1 : begin table_q[511:256] <= parameter_word_q; read_vector(source_q, row_q, R_INPUT); end
                R_INPUT : begin
                    run_math(R_COS);
                end
                R_COS : begin
                    run_math(R_SIN);
                end
                R_SIN : begin
                    write_vector(source_q, row_q, 32'hffffffff, R_PACK);
                end
                R_PACK : if (row_q == 3) op <= O_FINISH;
                    else begin row_q <= row_q + 1'b1; read_vector(source_q, row_q + 1'b1, R_INPUT); end
                C_INPUT : begin
                    k_write_address_q <= {layer_q, position_q, row_q[2:0]}; op <= C_STORE;
                end
                C_STORE : if (row_q == 7) op <= O_FINISH;
                    else begin
                        row_q <= row_q + 1'b1;
                        read_vector(row_q < 3 ? 3'd3 : 3'd4, 4'((row_q + 1) & 3), C_INPUT);
                    end
                A_QUERY : begin query_q <= vector_q; read_cache({layer_q, time_q, 1'b0, head_q}, A_KEY); end
                A_KEY : begin
                    run_math(A_DOT);
                end
                A_DOT : begin scalar_round_q <= rne_shift64(64'(math_sum), 6'd16); op <= A_SCALE; end
                A_SCALE : begin scalar_product_q <= scalar_round_q[38:0] * 25'sd11585; op <= A_SCORE; end
                A_SCORE : begin
                    scalar_round_q <= rne_shift64(scalar_product_q, 6'd16); op <= A_NEXT_SCORE;
                end
                A_NEXT_SCORE : begin
                    score_memory[time_q] <= sat_s32(scalar_round_q);
                    if (sat_s32(scalar_round_q) > max_score_q) max_score_q <= sat_s32(scalar_round_q);
                    if (time_q == position_q) begin time_q <= 0; op <= A_EXP_READ; end
                    else begin time_q <= time_q + 1'b1; read_cache({layer_q, 7'(time_q + 1'b1), 1'b0, head_q}, A_KEY); end
                end
                A_EXP_READ : begin
                    exp_difference_q <= 33'(max_score_q) - 33'(score_memory[time_q]); op <= A_EXP_PREP;
                end
                A_EXP_PREP : begin
                    if (exp_difference_q >= 33'd1048576) begin exp_hi_q <= 0; exp_lo_q <= 0; end
                    else begin
                        exp_hi_q <= llm_exp_sample({1'b0, exp_difference_q[19:12]});
                        exp_lo_q <= llm_exp_sample({1'b0, exp_difference_q[19:12]} + 1'b1);
                    end
                    op <= A_EXP_MUL;
                end
                A_EXP_MUL : begin
                    exp_interpolation_q <= (exp_hi_q - exp_lo_q) * exp_difference_q[11:0]; op <= A_EXP_STORE;
                end
                A_EXP_STORE : begin
                    probability_memory[time_q] <= exp_hi_q - 25'((exp_interpolation_q + 37'd2048) >> 12);
                    probability_sum_q <= probability_sum_q + exp_hi_q - 32'((exp_interpolation_q + 37'd2048) >> 12);
                    if (time_q == position_q) begin
                        time_q <= 0;
                        read_cache({layer_q, 7'd0, 1'b1, head_q}, A_VALUE);
                    end else begin time_q <= time_q + 1'b1; op <= A_EXP_READ; end
                end
                A_VALUE : begin probability_q <= probability_memory[time_q]; op <= A_WEIGHT; end
                A_WEIGHT : begin
                    run_math(A_ACC);
                end
                A_ACC : begin
                    if (time_q == position_q) begin lane_q <= 0; op <= A_LANE; end
                    else begin time_q <= time_q + 1'b1; read_cache({layer_q, 7'(time_q + 1'b1), 1'b1, head_q}, A_VALUE); end
                end
                A_LANE : begin
                    divide_negative_q <= attention_acc_q[lane_q][55];
                    div_numerator_q <= attention_acc_q[lane_q][55] ?
                        64'(-attention_acc_q[lane_q]) : 64'(attention_acc_q[lane_q]);
                    div_denominator_q <= probability_sum_q; op <= A_DIV;
                end
                A_DIV : op <= A_DIV_WAIT;
                A_DIV_WAIT : if (div_done) begin
                    scalar_round_q <= divide_negative_q ?
                        -$signed(div_quotient + {63'h0, divide_round_up}) :
                        $signed(div_quotient + {63'h0, divide_round_up}); op <= A_PACK;
                end
                A_PACK : begin
                    if (lane_q == 31) write_vector(5, {2'b0, head_q}, 32'hffffffff, A_QUERY);
                    else begin lane_q <= lane_q + 1'b1; op <= A_LANE; end
                    if (lane_q == 31) begin
                        if (head_q == 3) return_w <= O_FINISH;
                        else begin
                            head_q <= head_q + 1'b1; time_q <= 0;
                            max_score_q <= 32'sh80000000; probability_sum_q <= 0;
                            v_address_q <= 7'(2 * 12 + head_q + 1); return_v <= A_QUERY; return_w <= O_V_REQ;
                        end
                    end
                end
                B_INPUT0 : begin
                    second_q <= vector_q; read_vector(graph == G_GMUL ? 3'd7 : 3'd1, row_q, B_INPUT1);
                end
                B_INPUT1 : begin
                    if (graph == G_GMUL) begin
                        run_math(B_CALC);
                    end else begin
                        write_vector(0, row_q, 32'hffffffff, B_PACK);
                    end
                end
                B_CALC : begin
                    write_vector(6, row_q, 32'hffffffff, B_PACK);
                end
                B_PACK : if (row_q == (graph == G_GMUL ? 11 : 3)) op <= O_FINISH;
                    else begin row_q <= row_q + 1'b1; read_vector(graph == G_GMUL ? 3'd6 : 3'd0, row_q + 1'b1, B_INPUT0); end
                S_INPUT : begin lane_q <= 0; sig_x_q <= sat_s16(rne_shift64(64'($signed(vector_q[23:0])), 6'd4)); op <= S_SIG; end
                S_SIG : op <= S_SIG_WAIT;
                S_SIG_WAIT : if (sig_done) begin
                    if (lane_q == 31) op <= S_MUL;
                    else begin
                        lane_q <= lane_q + 1'b1;
                        sig_x_q <= sat_s16(rne_shift64(64'($signed(vector_q[(lane_q + 1) * 24 +: 24])), 6'd4));
                        op <= S_SIG;
                    end
                end
                S_MUL : begin
                    run_math(S_PACK);
                end
                S_PACK : begin
                    write_vector(6, row_q, 32'hffffffff, B_PACK);
                    if (row_q == 11) return_w <= O_FINISH;
                    else begin row_q <= row_q + 1'b1; v_address_q <= 7'(6 * 12 + row_q + 1); return_v <= S_INPUT; return_w <= O_V_REQ; end
                end
                H_SCALE : begin
                    coefficient_q <= parameter_word_q[vocabulary_row_q[2:0] * 32 +: 24];
                    read_parameter({1'b0, vocabulary_row_q, 2'b00}, H_WEIGHT);
                end
                H_WEIGHT : begin weights_q <= parameter_word_q; read_vector(1, chunk_q, H_INPUT); end
                H_INPUT : begin
                    run_math(H_MAC);
                end
                H_MAC : begin
                    linear_acc_q <= linear_acc_q + math_sum[38:0];
                    if (chunk_q == 3) op <= H_COEFF;
                    else begin chunk_q <= chunk_q + 1'b1; read_parameter(15'(vocabulary_row_q * 4 + chunk_q + 1), H_WEIGHT); end
                end
                H_COEFF : begin scalar_product_q <= linear_acc_q * $signed({1'b0, coefficient_q}); op <= H_ROUND; end
                H_ROUND : begin scalar_round_q <= rne_shift64(scalar_product_q, 6'd24); op <= H_NOISE; end
                H_NOISE : begin
                    // Gumbel-max selection is entirely on RTL. Temperature=0
                    // selects the largest logit, preserving stable lowest-ID ties.
                    noise_product_q <= llm_gumbel_sample(random_q[31:24]) * $signed({1'b0, temperature_q});
                    random_q <= llm_random_next(random_q); op <= H_SAMPLE;
                end
                H_SAMPLE : begin
                    sampled_score_q <= scalar_round_q + rne_shift64(64'(noise_product_q), 6'd8); op <= H_SELECT;
                end
                H_SELECT : begin
                    if (vocabulary_row_q != 0 && vocabulary_row_q != 2 &&
                        (vocabulary_row_q != 1 || generated_q >= min_new_q) &&
                        sat_s32(sampled_score_q) > best_score_q) begin
                        best_score_q <= sat_s32(sampled_score_q); best_token_q <= vocabulary_row_q;
                    end
                    if (vocabulary_row_q == 4095) op <= O_FINISH;
                    else begin
                        vocabulary_row_q <= vocabulary_row_q + 1'b1; chunk_q <= 0; linear_acc_q <= 0;
                        read_parameter(15'(EMB_SCALE_BASE + ((vocabulary_row_q + 1) >> 3)), H_SCALE);
                    end
                end
                default : ;
            endcase
        end else begin op <= O_IDLE; op_done <= 0; overflow_out <= 0; random_q <= 1; op_fault_q <= 0; end
    end
endmodule
